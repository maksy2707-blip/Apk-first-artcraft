use photocraft_doc::LayerContent;
use photocraft_doc::vector::LiveShape;
use serde_json::json;

use super::*;
use crate::canvas::{Drag, finish_gesture};

fn app() -> PhotocraftApp {
    let mut app = PhotocraftApp::new(photocraft_engine::Session::new(), Default::default());
    app.run("file.new", json!({"width": 400, "height": 300, "background": "white"})).unwrap();
    app.run("tools.setColors", json!({"foreground": "#ff0000", "background": "#0000ff"})).unwrap();
    app
}

fn press(app: &mut PhotocraftApp, tool: Tool, start: [f64; 2], end: [f64; 2]) {
    app.ui.tool = tool;
    let d = Drag::new(tool, start, vec![[start[0], start[1], 1.0], [end[0], end[1], 1.0]], egui::Modifiers::NONE, false);
    finish_gesture(app, d);
}

fn layers(app: &PhotocraftApp) -> usize {
    app.session.active().unwrap().doc.layers.len()
}

fn live(app: &PhotocraftApp) -> LiveShape {
    let st = app.session.active().unwrap();
    let l = st.doc.layer(st.active_layer.unwrap()).unwrap();
    let LayerContent::Shape(sh) = &l.content else { panic!("not a shape layer") };
    sh.live.clone().unwrap()
}

fn set(app: &mut PhotocraftApp, id: u64, fields: Value) {
    let d = app.ui.dialog_mut(id).unwrap();
    for (k, v) in fields.as_object().unwrap() {
        d.fields.insert(k.clone(), v.clone());
    }
}

fn only_dialog(app: &PhotocraftApp) -> u64 {
    assert_eq!(app.ui.dialogs.len(), 1, "a click opens one dialog");
    let d = &app.ui.dialogs[0];
    assert!(owns(&d.fields));
    d.id
}

#[test]
fn a_rectangle_click_opens_create_rectangle_and_ok_draws_it_at_the_click() {
    let mut app = app();
    let before = layers(&app);
    press(&mut app, Tool::Rectangle, [20.4, 30.2], [20.4, 30.2]);
    let id = only_dialog(&app);
    assert_eq!(crate::dialogs::title(&app.ui.dialogs[0]), "Create Rectangle");
    assert_eq!(layers(&app), before, "the click itself draws nothing");
    set(&mut app, id, json!({"width": 120, "height": 45.5, "radii": [4, 4, 4, 4]}));
    crate::dialogs::confirm(&mut app, id).unwrap();
    assert!(app.ui.dialogs.is_empty());
    assert_eq!(layers(&app), before + 1);
    assert_eq!(live(&app), LiveShape::Rect { rect: [20.0, 30.0, 120.0, 45.5], radii: [4.0; 4] });
    // The options bar's fill (foreground colour) is used, as for a drag.
    let st = app.session.active().unwrap();
    let LayerContent::Shape(sh) = &st.doc.layer(st.active_layer.unwrap()).unwrap().content else { panic!() };
    assert!(sh.fill.is_some());
}

#[test]
fn from_center_and_the_other_tools() {
    let mut app = app();
    press(&mut app, Tool::EllipseShape, [200.0, 150.0], [200.0, 150.0]);
    let id = only_dialog(&app);
    assert_eq!(crate::dialogs::title(&app.ui.dialogs[0]), "Create Ellipse");
    set(&mut app, id, json!({"width": 80, "height": 40, "fromCenter": true}));
    crate::dialogs::confirm(&mut app, id).unwrap();
    assert_eq!(live(&app), LiveShape::Ellipse { rect: [160.0, 130.0, 80.0, 40.0] });

    press(&mut app, Tool::Polygon, [10.0, 10.0], [10.0, 10.0]);
    let id = only_dialog(&app);
    set(&mut app, id, json!({"width": 50, "height": 60, "sides": 7, "starRatio": 50}));
    crate::dialogs::confirm(&mut app, id).unwrap();
    assert_eq!(live(&app), LiveShape::Polygon { rect: [10.0, 10.0, 50.0, 60.0], sides: 7, star_ratio: 0.5, corner_radius: 0.0 });

    press(&mut app, Tool::Triangle, [5.0, 6.0], [5.0, 6.0]);
    let id = only_dialog(&app);
    crate::dialogs::confirm(&mut app, id).unwrap();
    let LiveShape::Polygon { sides: 3, .. } = live(&app) else { panic!("a triangle") };
}

#[test]
fn drags_still_draw_and_tools_without_a_dialog_ignore_clicks() {
    let mut app = app();
    let before = layers(&app);
    press(&mut app, Tool::Rectangle, [10.0, 10.0], [60.0, 40.0]);
    assert!(app.ui.dialogs.is_empty(), "a drag draws without a dialog");
    assert_eq!(live(&app), LiveShape::Rect { rect: [10.0, 10.0, 50.0, 30.0], radii: [0.0; 4] });
    for tool in [Tool::Line, Tool::CustomShape] {
        press(&mut app, tool, [30.0, 30.0], [30.0, 30.0]);
        assert!(app.ui.dialogs.is_empty(), "{tool:?}");
    }
    assert_eq!(layers(&app), before + 1);
}

#[test]
fn click_dialogs_and_drags_keep_complete_stroke_defaults() {
    let style = crate::shape_stroke_ui::StrokeOptions {
        align: photocraft_doc::StrokeAlign::Outside,
        cap: photocraft_doc::LineCap::Square,
        join: photocraft_doc::LineJoin::Bevel,
        miter_limit: 7.0,
        dashes: vec![3.0, 1.0, 0.0, 2.0],
        dash_offset: -0.75,
        opacity: 0.6,
    };
    for tool in [Tool::Rectangle, Tool::EllipseShape, Tool::Triangle, Tool::Polygon] {
        for click in [false, true] {
            let mut app = app();
            app.ui.tool_options.stroke_width = 7.0;
            app.ui.tool_options.shape_stroke = style.clone();
            let history = app.session.active().unwrap().history.past_len();
            press(&mut app, tool, [20.0, 30.0], if click { [20.0, 30.0] } else { [120.0, 130.0] });
            if click {
                let id = only_dialog(&app);
                crate::dialogs::confirm(&mut app, id).unwrap();
            } else {
                assert!(app.ui.dialogs.is_empty());
            }
            let st = app.session.active().unwrap();
            let LayerContent::Shape(sh) = &st.doc.layer(st.active_layer.unwrap()).unwrap().content else { panic!("expected shape") };
            let stroke = sh.stroke.as_ref().unwrap();
            assert_eq!(crate::shape_stroke_ui::StrokeOptions::from(stroke), style, "{tool:?}, click={click}");
            assert_eq!(stroke.width, 7.0);
            assert_eq!(st.history.past_len(), history + 1);
        }
    }
}

#[test]
fn click_slop_scales_with_zoom() {
    let pts = |d: f64| vec![[10.0, 10.0, 1.0], [10.0 + d, 10.0, 1.0]];
    assert!(is_click([10.0, 10.0], &pts(2.0), 1.0));
    assert!(!is_click([10.0, 10.0], &pts(5.0), 1.0));
    assert!(!is_click([10.0, 10.0], &pts(2.0), 4.0), "2 document px at 400% is a drag");
    assert!(is_click([10.0, 10.0], &[], 0.0));
}

#[test]
fn radius_fields_are_named_for_their_corners() {
    use egui::accesskit::Role;
    use egui_kittest::Harness;
    use egui_kittest::kittest::{NodeT, Queryable};

    let mut app = app();
    let id = open(&mut app, Tool::Rectangle, [10.0, 20.0]).unwrap();
    let fields = app.ui.dialog_mut(id).unwrap().fields.clone();
    let mut h = Harness::builder().with_size(egui::vec2(520.0, 520.0)).build_ui_state(move |ui, fields| body(&app, ui, fields), fields);
    PhotocraftApp::setup_context(&h.ctx, crate::theme::ThemeKind::ALL[0]);
    h.run_steps(2);
    let labels: Vec<String> = h.query_all_by_role(Role::SpinButton).filter_map(|n| n.accesskit_node().label()).collect();
    // The visible rows are [top-left, top-right], [bottom-left, bottom-right]; the field for each
    // radius index must carry its own corner name (a permutation would still pass a set check).
    let corners: Vec<&str> = labels.iter().map(String::as_str).filter(|label| !matches!(*label, "Width:" | "Height:")).collect();
    assert_eq!(
        corners,
        vec!["Top Left Radius:", "Top Right Radius:", "Bottom Left Radius:", "Bottom Right Radius:"],
        "radius fields name their corner in layout order: {labels:?}"
    );
    assert!(!labels.iter().any(|label| label == "Radius:"), "the generic name would leave the corners indistinguishable");
}

/// #4205: the click slop is in screen points, so on a 2x (HiDPI) display at 100 % a 2 pt jitter
/// (4 device px = 4 document px) is still a click that opens Create Rectangle, not a tiny shape.
#[test]
fn a_click_with_jitter_opens_the_dialog_on_hidpi() {
    let mut app = app();
    app.ppp = 2.0;
    let i = app.session.active_index().unwrap();
    app.ui.views[i].zoom = 1.0;
    let before = layers(&app);
    press(&mut app, Tool::Rectangle, [20.0, 30.0], [24.0, 30.0]);
    only_dialog(&app);
    assert_eq!(layers(&app), before, "a jittery click draws nothing");
}

#[test]
fn cancel_draws_nothing_and_ok_remembers_the_size() {
    let mut app = app();
    let before = layers(&app);
    press(&mut app, Tool::Rectangle, [10.0, 10.0], [10.0, 10.0]);
    let id = only_dialog(&app);
    app.ui.close_dialog(id);
    assert_eq!(layers(&app), before);

    press(&mut app, Tool::Rectangle, [10.0, 10.0], [10.0, 10.0]);
    let id = only_dialog(&app);
    set(&mut app, id, json!({"width": 33, "height": 44, "fromCenter": true}));
    crate::dialogs::confirm(&mut app, id).unwrap();
    press(&mut app, Tool::Rectangle, [50.0, 50.0], [50.0, 50.0]);
    let f = &app.ui.dialogs[0].fields;
    assert_eq!((f["width"].as_f64(), f["height"].as_f64(), f["fromCenter"].as_bool()), (Some(33.0), Some(44.0), Some(true)));
    // Each tool remembers its own values.
    let id = only_dialog(&app);
    app.ui.close_dialog(id);
    press(&mut app, Tool::EllipseShape, [50.0, 50.0], [50.0, 50.0]);
    assert_eq!(app.ui.dialogs[0].fields["width"].as_f64(), Some(100.0));
}

#[test]
fn bad_values_are_errors_not_panics() {
    let mut app = app();
    for bad in [
        json!({"width": 0}),
        json!({"width": -5}),
        json!({"height": 1e12}),
        json!({"width": "wide"}),
        json!({"width": null}),
        json!({"__at": "here"}),
        json!({"__at": [1]}),
        json!({"__at": [1e308, 1e308], "fromCenter": true, "width": 300000, "height": 300000}),
        json!({"radii": "round"}),
        json!({"radii": [-1, 1e300, "x", null, 5]}),
    ] {
        let before = layers(&app);
        press(&mut app, Tool::Rectangle, [10.0, 10.0], [10.0, 10.0]);
        let id = only_dialog(&app);
        set(&mut app, id, bad.clone());
        let r = crate::dialogs::confirm(&mut app, id);
        if r.is_ok() {
            // Odd radii are clamped, not rejected.
            assert!(bad.get("radii").is_some(), "{bad} should be rejected");
            app.run("edit.undo", json!({})).unwrap();
        } else {
            assert!(app.ui.status_error);
        }
        assert!(app.ui.dialogs.is_empty());
        assert_eq!(layers(&app), before, "{bad}");
    }
    // Bad remembered values fall back to the defaults.
    app.session.prefs.edit(|p| p.dialogs.insert("shape.create.rectangle".into(), json!({"width": -1, "height": "x", "fromCenter": 3})));
    press(&mut app, Tool::Rectangle, [10.0, 10.0], [10.0, 10.0]);
    let f = &app.ui.dialogs[0].fields;
    assert_eq!((f["width"].as_f64(), f["height"].as_f64(), f["fromCenter"].as_bool()), (Some(100.0), Some(100.0), Some(false)));
}

#[test]
fn agents_click_set_and_confirm_over_the_control_channel() {
    let mut app = app();
    let ctx = egui::Context::default();
    let call = |app: &mut PhotocraftApp, method: &str, params: Value| {
        let (req, _rx) = crate::control::ControlRequest::new(method, params);
        match crate::control::handle(app, &ctx, &req) {
            crate::control::Outcome::Done(v) => v,
            _ => panic!("deferred"),
        }
    };
    call(&mut app, "ui.pointer", json!({"tool": "rectangle", "events": [{"kind": "down", "x": 40, "y": 50}, {"kind": "up", "x": 40, "y": 50}]}));
    let id = only_dialog(&app);
    for (field, value) in [("width", json!(64)), ("height", json!(32))] {
        call(&mut app, "ui.dialog.set", json!({"dialog": id, "field": field, "value": value}));
    }
    let r = call(&mut app, "ui.dialog.confirm", json!({"dialog": id}));
    assert_eq!(r["ok"], json!(true), "{r}");
    assert_eq!(live(&app), LiveShape::Rect { rect: [40.0, 50.0, 64.0, 32.0], radii: [0.0; 4] });
}

#[test]
fn the_dialog_body_renders_for_every_tool_and_unit() {
    let mut app = app();
    for (tool, unit) in [(Tool::Rectangle, "pixels"), (Tool::EllipseShape, "mm"), (Tool::Polygon, "percent"), (Tool::Triangle, "inches")] {
        app.run("prefs.set", json!({"path": "unitsAndRulers.rulers", "value": unit})).unwrap();
        let id = open(&mut app, tool, [1.0, 2.0]).unwrap();
        let mut fields = app.ui.dialog_mut(id).unwrap().fields.clone();
        let ctx = egui::Context::default();
        ctx.run_ui(egui::RawInput::default(), |ui| body(&app, ui, &mut fields)).textures_delta.clear();
        app.ui.close_dialog(id);
    }
}

/// One frame of a dialog body with `events`: the texts it draws, each with its screen rect.
fn frame(ctx: &egui::Context, app: &PhotocraftApp, fields: &mut serde_json::Map<String, Value>, events: Vec<egui::Event>) -> Vec<(String, egui::Rect)> {
    let input = egui::RawInput { events, ..Default::default() };
    let mut out = ctx.run_ui(input, |ui| body(app, ui, fields));
    out.textures_delta.clear();
    let mut texts = Vec::new();
    for clip in &out.shapes {
        if let egui::Shape::Text(t) = &clip.shape {
            texts.push((t.galley.text().to_string(), t.galley.rect.translate(t.pos.to_vec2())));
        }
    }
    texts
}

/// A click of `button` at `pos`, as frames: move there, press, release.
fn click(ctx: &egui::Context, app: &PhotocraftApp, f: &mut serde_json::Map<String, Value>, pos: egui::Pos2, button: egui::PointerButton) {
    let press = |pressed| egui::Event::PointerButton { pos, button, pressed, modifiers: egui::Modifiers::NONE };
    frame(ctx, app, f, vec![egui::Event::PointerMoved(pos)]);
    frame(ctx, app, f, vec![press(true)]);
    frame(ctx, app, f, vec![press(false)]);
}

/// Each of Width and Height: its value and unit, and the value's screen rect.
fn sides(texts: &[(String, egui::Rect)]) -> Vec<(String, String, egui::Rect)> {
    ["Width:", "Height:"]
        .iter()
        .filter_map(|l| texts.iter().position(|(t, _)| t == l))
        .filter_map(|i| {
            let (v, r) = texts.get(i + 1)?.clone();
            Some((v, texts.get(i + 2)?.0.clone(), r))
        })
        .collect()
}

/// #7786: right-clicking Width or Height offers the length units (no Percent, as in Photoshop's
/// Create Rectangle) and switches only that field; the sizes stay in pixels and the unit isn't
/// remembered, so the next dialog follows the ruler unit again.
#[test]
fn right_click_picks_the_unit_of_that_field_only_and_it_is_not_remembered() {
    let mut app = app();
    press(&mut app, Tool::Rectangle, [10.0, 10.0], [10.0, 10.0]);
    let id = only_dialog(&app);
    let mut f = app.ui.dialog_mut(id).unwrap().fields.clone();
    let ctx = egui::Context::default();
    let shown = |s: &[(String, String, egui::Rect)]| s.iter().map(|(v, u, _)| (v.clone(), u.clone())).collect::<Vec<_>>();
    let px = ("100".to_string(), "px".to_string());
    let texts = frame(&ctx, &app, &mut f, vec![]);
    let s = sides(&texts);
    assert_eq!(shown(&s), [px.clone(), px.clone()], "shown in the ruler unit, pixels");
    // Right-click Width: its menu lists the lengths and no Percent.
    click(&ctx, &app, &mut f, s[0].2.center(), egui::PointerButton::Secondary);
    let menu = frame(&ctx, &app, &mut f, vec![]);
    let has = |label: &str| menu.iter().any(|(t, _)| t.ends_with(label));
    assert!(["Pixels", "Inches", "Centimeters", "Millimeters", "Points", "Picas"].iter().all(|l| has(l)), "{menu:?}");
    assert!(!has("Percent"), "Photoshop's menu here has no Percent");
    let mm_item = menu.iter().find(|(t, _)| t == "Millimeters").unwrap().1.center();
    click(&ctx, &app, &mut f, mm_item, egui::PointerButton::Primary);
    // Only Width changes: 100 px at the document's 72 ppi is 35.28 mm; the size stays in pixels.
    let s = sides(&frame(&ctx, &app, &mut f, vec![]));
    assert_eq!(shown(&s), [("35.28".to_string(), "mm".to_string()), px.clone()]);
    assert_eq!((f["widthUnit"].as_str(), f.get("heightUnit")), (Some("mm"), None));
    assert_eq!(f["width"].as_f64(), Some(100.0), "the size stays in pixels");
    // Height has its own menu, with its own unit checked: Inches switches Height alone.
    click(&ctx, &app, &mut f, s[1].2.center(), egui::PointerButton::Secondary);
    let menu = frame(&ctx, &app, &mut f, vec![]);
    assert!(menu.iter().any(|(t, _)| t == "✓ Pixels"), "{menu:?}");
    let in_item = menu.iter().find(|(t, _)| t == "Inches").unwrap().1.center();
    click(&ctx, &app, &mut f, in_item, egui::PointerButton::Primary);
    let s = sides(&frame(&ctx, &app, &mut f, vec![]));
    assert_eq!(shown(&s), [("35.28".to_string(), "mm".to_string()), ("1.389".to_string(), "in".to_string())]);
    // OK, then the rulers change: the next dialog shows the new ruler unit, not the pick.
    set(&mut app, id, json!({"widthUnit": "mm", "width": 50}));
    crate::dialogs::confirm(&mut app, id).unwrap();
    app.run("prefs.set", json!({"path": "unitsAndRulers.rulers", "value": "cm"})).unwrap();
    press(&mut app, Tool::Rectangle, [40.0, 40.0], [40.0, 40.0]);
    let id = only_dialog(&app);
    let mut f = app.ui.dialog_mut(id).unwrap().fields.clone();
    assert_eq!((f.get("widthUnit"), f["width"].as_f64()), (None, Some(50.0)), "the size is remembered, the unit isn't");
    let s = sides(&frame(&egui::Context::default(), &app, &mut f, vec![]));
    assert_eq!(shown(&s), [("1.76".to_string(), "cm".to_string()), ("3.53".to_string(), "cm".to_string())]);
}

/// CodeRabbit on #9456: in Path mode a click opens no Create dialog, whose OK would make a shape
/// layer; Path mode never draws one (a drag adds its outline to the work path).
#[test]
fn a_path_mode_click_opens_no_create_dialog() {
    for tool in [Tool::Rectangle, Tool::EllipseShape, Tool::Triangle, Tool::Polygon] {
        let mut app = app();
        app.ui.tool_options.shape_mode = "path".into();
        let before = layers(&app);
        press(&mut app, tool, [20.4, 30.2], [20.4, 30.2]);
        assert!(app.ui.dialogs.is_empty(), "{tool:?}: no Create dialog in Path mode");
        assert_eq!(layers(&app), before, "{tool:?}: and no layer");
    }
}

/// CodeRabbit on #9456: a Path-mode click that moved a little, still within the click slop, adds
/// nothing to the work path either. Its box would round to a 1 × 1 or 2 × 2 px outline.
#[test]
fn a_path_mode_click_that_moved_a_little_adds_no_subpath() {
    let work = |app: &PhotocraftApp| app.session.active().unwrap().doc.work_path.as_ref().map_or(0, |p| p.subpaths.len());
    for tool in [Tool::Rectangle, Tool::EllipseShape, Tool::Triangle, Tool::Polygon, Tool::Line] {
        for end in [[20.8, 30.8], [21.8, 31.9]] {
            let mut app = app();
            app.ui.tool_options.shape_mode = "path".into();
            let before = layers(&app);
            press(&mut app, tool, [20.2, 30.2], end);
            assert_eq!(work(&app), 0, "{tool:?} to {end:?}: no subpath");
            assert!(app.ui.dialogs.is_empty(), "{tool:?} to {end:?}: no Create dialog");
            assert_eq!(layers(&app), before, "{tool:?} to {end:?}: and no layer");
        }
    }
}
