//! Actions panel: record and replay command sequences.
//!
//! The list and the recording flag live on the engine session (`actions.record` / `stop` /
//! `play` / `list` / `get` / `delete` / `move` / `rename`), so the panel, the CLI and MCP share them. This module
//! keeps only which row is selected and which rows are expanded.

use egui::{Align2, Color32, Rect, Sense, Stroke, pos2, vec2};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use photocraft_engine::actions_cmds::{self, Action};

use crate::PhotocraftApp;
use crate::file_dialog::{FileDialogAnswer, FileDialogRequest};
use crate::icons;
use crate::theme::Tokens;

/// Which row is selected and which rows are expanded. The action list itself is
/// [`photocraft_engine::Session::actions`].
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct ActionsUi {
    pub selected: Option<usize>,
    pub selected_step: Option<usize>,
    pub expanded: Vec<bool>,
    /// Set folders shown collapsed (Photoshop's set disclosure triangles).
    pub collapsed_sets: Vec<String>,
    /// Photoshop's Button Mode: each action is a coloured button, and a click plays it.
    #[serde(default)]
    pub button_mode: bool,
    /// The set whose folder row was clicked last (or New Set made), while no action is selected:
    /// New Action records into it, as Photoshop's does into the selected set (#7535).
    #[serde(skip)]
    pub selected_set: Option<String>,
    #[serde(skip)]
    reveal_recording: Option<(usize, usize)>,
    /// The action whose name is being edited in place (double-click on its name).
    #[serde(skip)]
    renaming: Option<RenameAction>,
}

impl ActionsUi {
    /// Select an action (and one of its steps): it replaces a selected set, so a later deselect
    /// (Delete, a removed row) doesn't bring back a set the user moved away from.
    fn select(&mut self, action: usize, step: Option<usize>) {
        self.selected = Some(action);
        self.selected_step = step;
        self.selected_set = None;
    }
}

#[derive(Clone, Debug, PartialEq)]
struct RenameAction {
    index: usize,
    text: String,
    focused: bool,
}

pub(crate) fn label_of(id: &str) -> String {
    photocraft_engine::commands::find(id)
        .map(|c| c.label)
        .or_else(|| crate::menus::UI_COMMANDS.iter().find(|c| c.0 == id).map(|c| c.1))
        // Shell menu items recorded as steps, like Save a Copy (#4373).
        .or_else(|| crate::menu_catalog::CATALOG.iter().find(|c| c.3 == id).map(|c| c.1))
        .map(|label| label.trim_end_matches('…').to_string())
        .unwrap_or_else(|| id.to_string())
}

/// The selected action, else the first action of the selected set (Batch and Create Droplet start
/// on the panel's selection), else the first one.
pub fn selected_action(app: &PhotocraftApp) -> Option<&Action> {
    let list = &app.session.actions.list;
    let idx = app.ui.actions.selected.filter(|i| *i < list.len());
    idx.and_then(|i| list.get(i)).or_else(|| selected_set_actions(app).first().and_then(|i| list.get(*i))).or_else(|| list.first())
}

/// The Set and Action dropdowns of the Batch and Create Droplet dialogs, as in the reference
/// application: each action name once and each set once, in list order. A loaded library can hold
/// one name in two sets, so the dialog sends the set too and the command picks that set's action.
pub fn action_form_choices(app: &PhotocraftApp) -> (Vec<String>, Vec<String>) {
    let (mut names, mut sets) = (Vec::new(), Vec::new());
    for action in &app.session.actions.list {
        if !names.contains(&action.name) {
            names.push(action.name.clone());
        }
        if let Some(set) = action.set.as_ref().filter(|set| !sets.contains(*set)) {
            sets.push(set.clone());
        }
    }
    (names, sets)
}

/// The selected set folder, if no action is selected and the set still exists.
fn selected_set(app: &PhotocraftApp) -> Option<&str> {
    if app.ui.actions.selected.is_some_and(|i| i < app.session.actions.list.len()) {
        return None;
    }
    let set = app.ui.actions.selected_set.as_deref()?;
    photocraft_engine::actions_edit_cmds::set_names(&app.session).iter().any(|n| n == set).then_some(set)
}

/// The actions of the selected set, in list order (empty when no set is selected, or it is empty).
fn selected_set_actions(app: &PhotocraftApp) -> Vec<usize> {
    let Some(set) = selected_set(app) else { return Vec::new() };
    app.session.actions.list.iter().enumerate().filter(|(_, a)| a.set.as_deref() == Some(set)).map(|(i, _)| i).collect()
}

/// What Play plays: the selected action; with a set folder selected, every action of that set in
/// order, as Photoshop plays a selected set (nothing for an empty set); else the first action.
fn playback_targets(app: &PhotocraftApp) -> Vec<usize> {
    if selected_set(app).is_some() {
        return selected_set_actions(app);
    }
    playback_selection(app).into_iter().collect()
}

/// Play `targets` one after another, stopping at the first that fails or can't start. One that
/// pauses for a step dialog of its own hands the rest to that dialog, which plays them after its OK
/// (Cancel stops them all, as it stops one action), also from inside an action it calls: that one
/// continues into its callers first. A Stop with its dialog off ends the set. Returns the last result with `ran` counting the steps
/// of all of them plus `before` (steps the same Play ran before a pause), or `None` when there was nothing to play.
fn play_targets(app: &mut PhotocraftApp, targets: &[usize], before: u64) -> Result<Option<Value>, String> {
    // A new Play ends a Step by Step or Pause For playback that is waiting for its next step.
    playback::stop(app);
    let (mut last, mut ran) = (None, before);
    for (n, &i) in targets.iter().enumerate() {
        let name = app.session.actions.list.get(i).map(|a| a.name.clone());
        let mut v = app.run("actions.play", json!({"action": i}))?;
        ran = ran.saturating_add(v.get("ran").and_then(Value::as_u64).unwrap_or(0));
        let failed = v.get("failed").is_some_and(Value::is_object) || v.get("stopped").is_some_and(Value::is_object);
        let paused = v.get("paused").filter(|p| p.is_object()).and_then(waiting_dialog).cloned();
        if let Some(o) = v.as_object_mut() {
            o.insert("ran".into(), json!(ran));
        }
        last = Some(v);
        if let Some(dialog) = paused.filter(|_| !failed) {
            // As they are now, not by index: the list can be reordered while the dialog is open
            // (`actions.move`), and one deleted and made again under its name isn't the same action.
            let list = &app.session.actions.list;
            let rest: Vec<Action> = targets.get(n + 1..).unwrap_or_default().iter().filter_map(|i| list.get(*i).cloned()).collect();
            let token = paused_token(app, &dialog);
            if let Some(entry) = token.and_then(|t| app.paused_playbacks.paused.get_mut(&t))
                && name.as_deref() == Some(entry.outermost())
            {
                entry.then = rest;
                entry.ran = ran;
            }
            break;
        }
        if failed {
            break;
        }
    }
    Ok(last)
}

/// The dialog a paused playback waits at: a step dialog by id, Check Spelling, or Step by Step and
/// Pause For's wait before the next step.
fn waiting_dialog(paused: &Value) -> Option<&Value> {
    paused.get("dialog").filter(|d| d.is_u64() || matches!(d.as_str(), Some(crate::type_panels_ui::SPELLING | playback::PLAYBACK_TIMER)))
}

/// The token of the paused playback waiting at `dialog` (see [`waiting_dialog`]).
fn paused_token(app: &mut PhotocraftApp, dialog: &Value) -> Option<u64> {
    match dialog.as_u64() {
        Some(id) => app.ui.dialog_mut(id).and_then(|d| d.fields.get(RESUME)).and_then(Value::as_u64),
        None if dialog.as_str() == Some(playback::PLAYBACK_TIMER) => playback::waiting(app),
        None => app.ui.type_panels.spell.as_ref().and_then(|d| d.resume),
    }
}

/// Index of the playback target. Photoshop's Play button uses the first action when
/// the panel has actions but none of its rows is selected.
fn playback_selection(app: &PhotocraftApp) -> Option<usize> {
    let n = app.session.actions.list.len();
    if n == 0 { None } else { Some(app.ui.actions.selected.filter(|i| *i < n).unwrap_or(0)) }
}

/// Steps in the `[[id, params], …]` shape batch and droplets already accept, without the
/// steps switched off in the panel.
pub fn action_steps(action: &Action) -> Vec<Value> {
    action.enabled_steps().map(|(_, (id, p))| json!([id, p])).collect()
}

/// Named action bindings use the existing persisted shortcut overrides. Keeping the
/// name in the key means selecting or deleting another row cannot retarget F6.
pub(crate) const SHORTCUT_PREFIX: &str = actions_cmds::PLAY_SHORTCUT_PREFIX;

pub(crate) fn shortcut_id(name: &str) -> String {
    format!("{SHORTCUT_PREFIX}{name}")
}

pub(crate) fn assign_shortcut(app: &mut PhotocraftApp, name: &str, shortcut: &str) -> Result<Value, String> {
    let id = shortcut_id(name);
    let mut set = serde_json::Map::new();
    // A function key belongs to only one action. Ordinary menu bindings remain
    // intact and become available again when the action binding is removed.
    for (other, assigned) in &app.session.prefs().shortcuts {
        if other.starts_with(SHORTCUT_PREFIX) && other != &id && assigned == shortcut && !shortcut.is_empty() {
            set.insert(other.clone(), json!(""));
        }
    }
    set.insert(id, json!(shortcut));
    app.run("edit.keyboardShortcuts", json!({"set": set, "allowUnknown": true, "removeConflicts": false}))
}

/// Replay edits synchronously, with view steps handled by the shell in the same order.
/// Engine steps keep the headless action semantics (no dialogs or background jobs).
pub(crate) fn play(app: &mut PhotocraftApp, params: &Value) -> Result<Value, String> {
    // A new Play ends a Step by Step or Pause For playback that is waiting for its next step (none
    // waits while a playback runs its steps, so a Play Action step never ends its own).
    playback::stop(app);
    play_owned(app, params, None, &[])
}

/// How a step that called another action left its caller.
enum Called {
    /// The called action finished: the caller goes on.
    Done,
    Failed(Value),
    /// It waits at a dialog that now carries this caller as well.
    Paused(Value),
    /// A Stop with its dialog off ended it, and the caller with it.
    Stopped(Value),
    /// The step ran, and Step by Step or Pause For waits before the next one ([`playback::paced`]).
    Paced(Value),
}

/// Read the result of step `i` (`id`) of `caller`: a nested failure, a pause (the caller joins the
/// paused playback's [`PausedPlayback::callers`], so it continues after the called action) or a
/// silent stop end the caller there.
fn called(app: &mut PhotocraftApp, caller: &str, i: usize, id: &str, value: &Value, target: Option<photocraft_doc::DocId>) -> Called {
    if let Some(error) = actions_cmds::nested_failure(id, value).or_else(|| actions_cmds::save_target_closed(&app.session, id, target)) {
        // Keep the same child-result detail as headless Actions and Scripts.
        return Called::Failed(json!({"step": i, "id": id, "error": error, "result": value}));
    }
    if let Some(inner) = value.get("paused").filter(|p| p.is_object()) {
        if let Some(token) = waiting_dialog(inner).cloned().and_then(|dialog| paused_token(app, &dialog))
            && let Some(entry) = app.paused_playbacks.paused.get_mut(&token)
        {
            if entry.callers.len() >= MAX_CALLERS {
                return Called::Failed(json!({"step": i, "id": id, "error": format!("action nesting exceeds {MAX_CALLERS} levels")}));
            }
            entry.callers.push((caller.to_string(), i.saturating_add(1)));
        }
        return Called::Paused(inner.clone());
    }
    if matches!(id, "actions.play" | "actions.conditional")
        && let Some(stop) = value.get("stopped").filter(|s| s.is_object())
    {
        return Called::Stopped(json!({"step": i, "id": id, "stopped": stop}));
    }
    Called::Done
}

/// File `c` under the playback's ending, or count the step when it ran: whether the playback ends.
fn end_at(c: Called, ran: &mut u64, failed: &mut Option<Value>, paused: &mut Option<Value>, stopped: &mut Option<Value>) -> bool {
    match c {
        Called::Done => {
            *ran += 1;
            return false;
        }
        Called::Failed(f) => *failed = Some(f),
        Called::Paused(p) => *paused = Some(p),
        Called::Stopped(s) => *stopped = Some(s),
        Called::Paced(p) => {
            *ran += 1;
            *paused = Some(p);
        }
    }
    true
}

/// A resumed playback goes on in the action this one called (`inner`, see [`play_owned`]) inside
/// this one's playback frame, so its recursion checks still see this caller; the call was step
/// `from - 1`. `None` when there is nothing to replay.
fn replay_inner(app: &mut PhotocraftApp, caller: &str, from: usize, inner: &[(String, usize)]) -> Option<Called> {
    let ((name, child_from), rest) = inner.split_first()?;
    let step = from.saturating_sub(1);
    let target = app.session.active().map(|d| d.doc.id);
    Some(match play_owned(app, &json!({"action": name, "from": child_from}), None, rest) {
        Ok(value) => called(app, caller, step, "actions.play", &value, target),
        Err(error) => Called::Failed(json!({"step": step, "id": "actions.play", "error": error})),
    })
}

type Player = fn(&mut PhotocraftApp, &Value) -> Result<Value, String>;

/// The shell's player for a step that plays another action: Play Action, or a Conditional's branch.
fn nested_call(id: &str) -> Option<Player> {
    match id {
        "actions.play" => Some(play),
        "actions.conditional" => Some(conditional),
        _ => None,
    }
}

/// A Conditional step: test its condition as the engine does, then play the branch it picks
/// through [`play`] like a Play Action step, so the branch's steps keep their pacing, step dialogs
/// and Stop messages. The result is the engine command's, with the branch's `paused` or `stopped`.
/// Malformed params go to the engine command, which refuses them with its own error.
fn conditional(app: &mut PhotocraftApp, p: &Value) -> Result<Value, String> {
    let branch = |key: &str| match p.get(key) {
        None | Some(Value::Null) => Some(None),
        Some(Value::String(n)) => Some(Some(n.clone()).filter(|n| !n.trim().is_empty())),
        Some(_) => None,
    };
    let (Some(condition), Some(then), Some(otherwise)) = (p.get("if").and_then(Value::as_str), branch("then"), branch("else")) else {
        return app.session.execute("actions.conditional", p.clone()).map_err(|e| e.to_string());
    };
    let Ok(holds) = photocraft_engine::actions_edit_cmds::evaluate(&app.session, condition) else {
        return app.session.execute("actions.conditional", p.clone()).map_err(|e| e.to_string());
    };
    let played = if holds { then } else { otherwise };
    let mut out = json!({"if": condition, "holds": holds, "played": played});
    if let Some(name) = played {
        let r = play(app, &json!({"action": name}))?;
        for key in ["failed", "paused", "stopped"] {
            if let Some(v) = r.get(key) {
                out[key] = v.clone();
            }
        }
        out["ran"] = r.get("ran").cloned().unwrap_or(json!(0));
        out["action"] = json!(name);
    }
    Ok(out)
}

/// Step `i` of `action` is a Stop: with its dialog toggle on it shows its message and pauses
/// (Continue, when the step allows it, resumes after it); with the toggle off it ends the playback
/// without a word, as in the reference application.
fn stop_step(app: &mut PhotocraftApp, action: &Action, i: usize, p: &Value) -> Called {
    let id = photocraft_engine::atn_cmds::STOP_MESSAGE;
    if !action.dialogs.contains(&i) {
        return Called::Stopped(json!({"step": i, "id": id}));
    }
    let token = app.paused_playbacks.pause(action.name.clone(), i + 1, app.session.authorize);
    let allow = p.get("allowContinue").and_then(Value::as_bool).unwrap_or(false);
    if let Some(entry) = app.paused_playbacks.paused.get_mut(&token) {
        entry.allow_continue = allow;
    }
    let message = p.get("message").and_then(Value::as_str).unwrap_or_default();
    let fields = json!({STOP_DIALOG: true, "__label": "Message", "message": message, "allowContinue": allow, RESUME: token});
    let dialog = app.ui.open_dialog(crate::state::DialogKind::Command, fields.as_object().cloned().unwrap_or_default());
    Called::Paused(json!({"step": i, "id": id, "dialog": dialog}))
}

/// Let the engine handle programmatic playback and stateless items. Interactive Play opens
/// the settings editor and retains its command, document and receiver until confirmation.
fn pause_menu_item(app: &mut PhotocraftApp, action: &str, from: usize, id: &str, params: &Value) -> Result<Option<u64>, String> {
    use photocraft_engine::atn_cmds::{MENU_ITEM, menu_item_command, menu_item_needs_settings};

    if id != MENU_ITEM || !playback::is_interactive(app) {
        return Ok(None);
    }
    let command = menu_item_command(params).map_err(|error| error.to_string())?;
    if !menu_item_needs_settings(command) {
        return Ok(None);
    }
    let defaults = json!({});
    authorize_owned(app, command, &defaults, app.session.authorize, app.automation_input)?;
    app.session.precheck(command, &defaults).map_err(|error| error.to_string())?;
    let receiver = app.session.active().and_then(|st| st.active_layer);
    let doc = app.session.active().map(|st| st.doc.id);
    let dialog = open_step_editor(app, command)?;
    let token = app.paused_playbacks.pause(action.to_owned(), from, app.session.authorize);
    if let Some(d) = app.ui.dialog_mut(dialog) {
        d.fields.insert(RESUME.into(), json!(token));
    }
    if let Some(p) = app.paused_playbacks.paused.get_mut(&token) {
        p.menu_editor = Some((dialog, command.to_owned()));
        p.filter_receiver = Some(receiver);
        p.doc = doc;
    }
    Ok(Some(dialog))
}

/// Route playback and Record Again to the same settings editor used by the command.
fn open_step_editor(app: &mut PhotocraftApp, command: &str) -> Result<u64, String> {
    if crate::sizing::is_sizing(command) {
        crate::sizing::open(app, command).ok_or_else(|| tl!("No document.").into())
    } else if crate::filter_dialog::has_dialog(command) || crate::adjust_dialog::has_dialog(command) {
        Ok(crate::dialogs::open_command_dialog(app, command, &label_of(command)))
    } else {
        crate::filter_dialog::open(app, command).ok_or_else(|| tl!("The step has no command editor.").into())
    }
}

/// Open the recorded step's editor and retain the receiver for confirmation.
fn pause_recorded_step(app: &mut PhotocraftApp, action: &Action, i: usize, id: &str, p: &Value) -> Value {
    let label = label_of(id);
    let active_layer = app.session.active().and_then(|st| st.active_layer);
    let dialog = crate::dialogs::open_command_dialog(app, id, &label);
    let token = app.paused_playbacks.pause(action.name.clone(), i + 1, app.session.authorize);
    let mut receiver = None;
    if let Some(d) = app.ui.dialog_mut(dialog) {
        if let Some(o) = p.as_object() {
            // `__` keys are the dialog's own markers (`params_of` drops them), not step values.
            d.fields.extend(o.iter().filter(|(k, _)| !k.starts_with("__")).map(|(k, v)| (k.clone(), v.clone())));
        }
        d.fields.insert(RESUME.into(), json!(token));
        // Kept for every implicit step, also one opened on a document target: the dialog
        // may switch it to a layer-owned one, and `run_step_dialog` checks the receiver
        // for the target it confirms.
        if p.get("layer").is_none_or(Value::is_null) {
            receiver = Some(active_layer);
        }
    }
    if let Some(paused) = app.paused_playbacks.paused.get_mut(&token) {
        paused.filter_receiver = receiver;
    }
    json!({"step": i, "id": id, "dialog": dialog})
}

/// `suspended` is the recording a paused part of the same call took ([`PausedPlayback::record`]); it comes
/// back, with that named call journaled, only when the whole call ends. `inner` are the called
/// actions a resumed playback replays first, outermost first, each `(action, from)`: the first is
/// the one this action's step before `from` called ([`resume`]).
fn play_owned(app: &mut PhotocraftApp, params: &Value, suspended: Option<Value>, inner: &[(String, usize)]) -> Result<Value, String> {
    let (action, from) = match actions_cmds::playback_plan(&app.session, params) {
        Ok(plan) => plan,
        Err(e) => {
            actions_cmds::finish_pending_history(&mut app.session);
            restore_recording(app, suspended.as_ref());
            return Err(e.to_string());
        }
    };
    let recording = match actions_cmds::begin_playback(&mut app.session, &action) {
        Ok(r) => r,
        Err(e) => {
            actions_cmds::finish_pending_history(&mut app.session);
            restore_recording(app, suspended.as_ref());
            return Err(e.to_string());
        }
    };
    let owner = recording
        .map(|(_, idx)| {
            let into = app.session.actions.list.get(idx).map(|a| a.name.clone());
            json!({"index": idx, "into": into, "action": action.name, "from": from})
        })
        .or(suspended);
    let mut ran = 0u64;
    let interactive = playback::is_interactive(app);
    let (mut failed, mut paused, mut stopped) = (None, None, None);
    let ended = match replay_inner(app, &action.name, from, inner) {
        // The call was step `from - 1`: a paced Play waits after it as after any other step.
        Some(c) => end_at(playback::paced(app, &action, from.saturating_sub(1), "actions.play", ran, c), &mut ran, &mut failed, &mut paused, &mut stopped),
        None => false,
    };
    for (i, (id, p)) in action.enabled_steps().skip_while(|(i, _)| *i < from).filter(|_| !ended) {
        if !actions_cmds::consume_playback_step(&mut app.session) {
            failed = Some(json!({"step": i, "id": id, "error": format!("action playback exceeded the {}-step limit", actions_cmds::MAX_PLAYBACK_STEPS)}));
            break;
        }
        let resolved = match actions_cmds::playback_params(&app.session, id, p) {
            Ok(p) => p,
            Err(e) => {
                failed = Some(json!({"step": i, "id": id, "error": e.to_string()}));
                break;
            }
        };
        let p = &resolved;
        // The gate judges the step before its dialog opens: a denied step neither runs nor
        // pauses.
        if let Some(auth) = app.session.authorize
            && let Err(e) = auth(id, p)
        {
            failed = Some(json!({"step": i, "id": id, "error": e.to_string()}));
            break;
        }
        // A Stop shows its message or ends the playback (`stop_step`). Agents keep the headless
        // semantics of the engine command.
        if id == photocraft_engine::atn_cmds::STOP_MESSAGE && interactive {
            end_at(stop_step(app, &action, i, p), &mut ran, &mut failed, &mut paused, &mut stopped);
            break;
        }
        match pause_menu_item(app, &action.name, i + 1, id, p) {
            Ok(Some(dialog)) => {
                paused = Some(json!({"step": i, "id": id, "dialog": dialog}));
                break;
            }
            Err(error) => {
                failed = Some(json!({"step": i, "id": id, "error": error}));
                break;
            }
            Ok(None) => {}
        }
        // The dialog toggle: show the step's dialog with its recorded values and continue
        // from the next step when it is confirmed (`resume`). Agents play headlessly.
        if action.dialogs.contains(&i)
            && interactive
            && (crate::filter_dialog::has_dialog(id)
                || crate::adjust_dialog::has_dialog(id)
                || (id == crate::equalize_ui::COMMAND && crate::equalize_ui::asks(app)))
        {
            paused = Some(pause_recorded_step(app, &action, i, id, p));
            break;
        }
        // Check Spelling's dialog opens with Check All Layers as recorded; Done continues the action.
        // While the dialog is open (for another action or by hand), this step fails and the open
        // one keeps its place and ignored words.
        // A correction (`action` set) opens no dialog and runs below.
        if action.dialogs.contains(&i) && interactive && id == "edit.checkSpelling" && p.get("action").is_none() {
            if let Some(open) = app.ui.type_panels.spell.as_ref() {
                let error = if open.resume.is_some() { "Check Spelling is already open for another action" } else { "Check Spelling is already open" };
                failed = Some(json!({"step": i, "id": id, "error": error}));
                break;
            }
            if let Err(error) = crate::type_panels_ui::open_spelling(app, p.get("allLayers").and_then(Value::as_bool).unwrap_or(true)) {
                failed = Some(json!({"step": i, "id": id, "error": error}));
                break;
            }
            let token = app.paused_playbacks.pause(action.name.clone(), i + 1, app.session.authorize);
            if let Some(entry) = app.paused_playbacks.paused.get_mut(&token) {
                entry.doc = app.session.active().map(|d| d.doc.id);
            }
            if let Some(d) = app.ui.type_panels.spell.as_mut() {
                d.resume = Some(token);
            }
            paused = Some(json!({"step": i, "id": id, "dialog": crate::type_panels_ui::SPELLING}));
            break;
        }
        let target = app.session.active().map(|d| d.doc.id);
        let result = if let Some(call) = nested_call(id) {
            call(app, p)
        } else if actions_cmds::saves_smart_contents(&app.session, id) {
            app.session.execute(actions_cmds::SAVE_CONTENTS, json!({})).map_err(|e| e.to_string())
        } else if actions_cmds::shell_save_command(id) {
            // Write synchronously, so the next step doesn't meet a document locked by a
            // background save.
            let background = std::mem::replace(&mut app.background_jobs, false);
            let r = app.replay_save(id, p);
            app.background_jobs = background;
            r
        } else if actions_cmds::shell_view_command(id) {
            app.sync_views();
            app.run(id, p.clone())
        } else if id == "edit.paste" && p.get("as").is_some() {
            // An explicit vector paste needs the original OS source, not just an old pixel copy.
            app.run(id, p.clone())
        } else {
            app.session.execute(id, p.clone()).map_err(|e| e.to_string())
        };
        match result {
            // A called action that paused for a dialog continues here after it once confirmed.
            Ok(value) => {
                // Step by Step and Pause For: the canvas shows this step before the next one runs.
                let c = called(app, &action.name, i, id, &value, target);
                if end_at(playback::paced(app, &action, i, id, ran, c), &mut ran, &mut failed, &mut paused, &mut stopped) {
                    break;
                }
            }
            Err(error) => {
                failed = Some(json!({"step": i, "id": id, "error": error}));
                break;
            }
        }
    }
    let history = if failed.is_none() && paused.is_some() { actions_cmds::suspend_history(&mut app.session) } else { None };
    actions_cmds::finish_playback(&mut app.session, None, &action, from);
    match paused.as_ref().and_then(waiting_dialog).cloned() {
        // Paused for a dialog: the call goes on after it, so recording stays suspended.
        Some(dialog) if failed.is_none() => {
            let token = paused_token(app, &dialog);
            let entry = token.and_then(|t| app.paused_playbacks.paused.get_mut(&t));
            match entry {
                Some(p) => {
                    p.record = owner;
                    p.history = history;
                    // Innermost first: each frame of the paused call adds the action it played.
                    p.played.push(action.clone());
                }
                // No continuation to carry the recording: the call ends here.
                _ => {
                    drop(history);
                    restore_recording(app, owner.as_ref());
                }
            }
        }
        _ => {
            drop(history);
            restore_recording(app, owner.as_ref());
        }
    }
    Ok(match (failed, paused, stopped) {
        (Some(f), _, _) => json!({"action": action.name, "ran": ran, "failed": f}),
        (None, Some(p), _) => json!({"action": action.name, "ran": ran, "paused": p}),
        (None, None, Some(s)) => json!({"action": action.name, "ran": ran, "stopped": s}),
        (None, None, None) => json!({"action": action.name, "ran": ran}),
    })
}

/// Execute the actual menu command, not a synthetic keystroke. Fit is deferred
/// until canvas layout, so it uses the dimensions after all preceding action steps.
pub(crate) fn run_view(app: &mut PhotocraftApp, id: &str, params: Value) -> Result<Value, String> {
    app.sync_views();
    let i = app.session.active_index().ok_or("no document")?;
    let v = app.ui.views.get_mut(i).ok_or("no document view")?;
    v.fill_pending = false;
    match id {
        "view.fitOnScreen" => {
            v.fit_pending = true;
            v.request_zoom_animation(app.session.prefs().general.animated_zoom);
        }
        "view.zoomIn" => {
            v.fit_pending = false;
            v.zoom = crate::zoom_levels::step(v.zoom, 1, v.doc_size);
            v.request_zoom_animation(app.session.prefs().general.animated_zoom);
        }
        "view.zoomOut" => {
            v.fit_pending = false;
            v.zoom = crate::zoom_levels::step(v.zoom, -1, v.doc_size);
            v.request_zoom_animation(app.session.prefs().general.animated_zoom);
        }
        "view.actualPixels" => {
            v.fit_pending = false;
            v.zoom = 1.0;
            v.request_zoom_animation(app.session.prefs().general.animated_zoom);
        }
        _ => return Err(format!("unsupported view command: {id}")),
    }
    v.zoom_anchor = None;
    app.session.journal.push((id.into(), params));
    Ok(Value::Null)
}

/// The set New Action records into: the selected action's, else the selected set folder's.
fn new_action_set(app: &PhotocraftApp) -> Option<String> {
    match app.ui.actions.selected.and_then(|i| app.session.actions.list.get(i)) {
        Some(action) => action.set.clone(),
        None => app.ui.actions.selected_set.clone().filter(|set| photocraft_engine::actions_edit_cmds::set_names(&app.session).contains(set)),
    }
}

fn begin_recording(app: &mut PhotocraftApp, append: bool) {
    if app.session.actions.recording.is_some() {
        return;
    }
    // Recording appends to the selected action; with none (a set folder selected, say) it makes a
    // new action like New Action does, in the selected set.
    let params = match app.ui.actions.selected {
        Some(i) if append => json!({"action": i}),
        _ => new_action_set(app).map_or(json!({}), |set| json!({"set": set})),
    };
    let Ok(v) = app.run("actions.record", params) else { return };
    let Some(i) = v.get("index").and_then(Value::as_u64).and_then(|n| usize::try_from(n).ok()) else { return };
    app.ui.actions.select(i, None);
    if app.ui.actions.expanded.len() <= i {
        app.ui.actions.expanded.resize(i + 1, false);
    }
    app.ui.actions.expanded[i] = true;
    // Its set too, in case its folder is collapsed.
    if let Some(set) = app.session.actions.list.get(i).and_then(|a| a.set.as_ref()) {
        app.ui.actions.collapsed_sets.retain(|c| c != set);
    }
}

pub(crate) fn report_play(app: &mut PhotocraftApp, v: &Value) {
    if v.get("stopped").is_some_and(Value::is_object) {
        app.ui.status = tl!("Action playback stopped").to_string();
        app.ui.status_error = false;
        return;
    }
    if let Some(paused) = v.get("paused").filter(|p| p.is_object()) {
        if paused.get("dialog").and_then(Value::as_str) == Some(playback::PLAYBACK_TIMER) {
            // Step by Step or Pause For between two steps: the last report comes at the end.
            return;
        }
        let step = paused.get("step").and_then(Value::as_u64).unwrap_or(0);
        let template = "Step {step} is waiting for its dialog";
        app.ui.status = crate::i18n::fmt(tl!(template), &[("step", &(step + 1).to_string())]);
        app.ui.status_error = false;
        return;
    }
    let Some(failed) = v.get("failed").filter(|f| f.is_object()) else {
        let ran = v.get("ran").and_then(Value::as_u64).unwrap_or(0);
        app.ui.status = crate::i18n::trn(crate::i18n::current(), ran, "Played {n} step", "Played {n} steps");
        app.ui.status_error = false;
        return;
    };
    let step = failed.get("step").and_then(Value::as_u64).unwrap_or(0);
    let id = failed.get("id").and_then(Value::as_str).unwrap_or("");
    let error = failed.get("error").and_then(Value::as_str).unwrap_or("");
    let template = "Step {step} ({id}) failed: {error}";
    app.ui.status = crate::i18n::fmt(tl!(template), &[("step", &(step + 1).to_string()), ("id", id), ("error", error)]);
    app.ui.status_error = true;
}

fn visible_steps(app: &PhotocraftApp, action: usize) -> Vec<(String, Value)> {
    app.session.actions.list.get(action).into_iter().flat_map(|a| a.steps.iter()).chain(actions_cmds::pending_steps(&app.session, action)).cloned().collect()
}

/// "3 steps", or "2/3 steps" when some are switched off (Photoshop shows a red partial check).
fn step_count(steps: usize, disabled: usize) -> String {
    if disabled == 0 {
        crate::i18n::trn(crate::i18n::current(), steps as u64, "{n} step", "{n} steps")
    } else {
        let count = crate::i18n::trn(crate::i18n::current(), steps as u64, "{n} step", "{n} steps");
        format!("{}/{count}", steps.saturating_sub(disabled))
    }
}

fn button_fill(color: &str, t: &Tokens) -> Color32 {
    // Photoshop's Actions button colours. Empty uses the panel card so an uncoloured action stays readable.
    match color {
        "red" => Color32::from_rgb(196, 64, 64),
        "orange" => Color32::from_rgb(204, 120, 40),
        "yellow" => Color32::from_rgb(196, 176, 48),
        "green" => Color32::from_rgb(56, 140, 72),
        "blue" => Color32::from_rgb(48, 104, 176),
        "violet" => Color32::from_rgb(120, 72, 168),
        "gray" => t.text_dim,
        _ => t.card,
    }
}

fn button_label_color(color: &str, t: &Tokens) -> Color32 {
    if color.is_empty() { t.text } else { Color32::from_rgb(20, 20, 20) }
}

fn paint_check(ui: &egui::Ui, rect: Rect, on: bool, t: &Tokens) {
    let b = Rect::from_center_size(rect.center(), vec2(11.0, 11.0));
    ui.painter().rect_stroke(b, 2.0, Stroke::new(1.0, t.text_faint), egui::StrokeKind::Inside);
    if on {
        let pts = vec![pos2(b.left() + 2.5, b.center().y), pos2(b.left() + 4.5, b.bottom() - 3.0), pos2(b.right() - 2.5, b.top() + 2.5)];
        ui.painter().add(egui::Shape::line(pts, Stroke::new(1.5, t.text)));
    }
}

fn step_label(id: &str, params: &Value) -> String {
    if id == "actions.play" {
        let target = params.get("action").map(|v| v.as_str().map(str::to_owned).unwrap_or_else(|| v.to_string())).unwrap_or_default();
        format!("{}: {target}", label_of(id))
    } else if id == "layer.select" {
        let target = params
            .get("name")
            .and_then(Value::as_str)
            .or_else(|| params.get("layer").and_then(Value::as_str))
            .map(str::to_owned)
            .or_else(|| params.get("layer").and_then(Value::as_u64).map(|id| format!("ID {id}")));
        target.map_or_else(|| label_of(id), |target| format!("{} ({target})", label_of(id)))
    } else if id == "actions.conditional" {
        // "If hasLayers: FS8-Layers / FS8-No-Layers"
        let cond = params.get("if").and_then(Value::as_str).unwrap_or("?");
        let branch = |k: &str| params.get(k).and_then(Value::as_str).unwrap_or("–").to_string();
        format!("{}: {cond} → {} / {}", label_of(id), branch("then"), branch("else"))
    } else if id == photocraft_engine::atn_cmds::MENU_ITEM {
        photocraft_engine::atn_cmds::menu_item_command(params).map_or_else(|_| label_of(id), label_of)
    } else if id == photocraft_engine::atn_cmds::STOP_MESSAGE {
        format!("{}: {}", label_of(id), params.get("message").and_then(Value::as_str).unwrap_or_default())
    } else if id == photocraft_engine::atn_cmds::PHOTOSHOP_STEP {
        // A step from a .atn file PhotoCraft can't play yet: its Photoshop name, marked.
        let name = params.get("name").and_then(Value::as_str).filter(|n| !n.is_empty()).unwrap_or("?");
        crate::i18n::fmt(tl!("{name} (Photoshop)"), &[("name", name)])
    } else {
        label_of(id)
    }
}

/// Command params for a picked file: a real path keeps the journal small; browser files arrive
/// as bytes.
fn source(name: &str, bytes: &[u8]) -> Value {
    #[cfg(not(target_arch = "wasm32"))]
    if std::path::Path::new(name).is_absolute() && std::path::Path::new(name).is_file() {
        return json!({"path": name});
    }
    let _ = name;
    json!({"data": photocraft_engine::paint::tile::b64_encode(bytes)})
}

/// Load a `.atn` file's bytes into the Actions panel (the panel menu's Load Actions…).
pub fn load_bytes(app: &mut PhotocraftApp, name: &str, bytes: &[u8]) -> Result<Value, String> {
    load_source(app, name, source(name, bytes))
}

/// Import one set and reveal its first action, for both native paths and browser contents.
fn load_source(app: &mut PhotocraftApp, name: &str, params: Value) -> Result<Value, String> {
    let r = app.run("actions.load", params)?;
    let n = r["actions"].as_array().map_or(0, Vec::len) as u64;
    let unsupported = r["unsupported"].as_array().map_or(0, Vec::len);
    let shown = crate::file_open::display_name(name);
    let loaded =
        crate::i18n::fmt(&crate::i18n::trn(crate::i18n::current(), n, "Loaded {n} action from {file}", "Loaded {n} actions from {file}"), &[("file", &shown)]);
    app.ui.status_error = false;
    app.ui.status = if unsupported > 0 {
        let note = crate::i18n::trn(
            crate::i18n::current(),
            unsupported as u64,
            "{n} step has no PhotoCraft equivalent yet",
            "{n} steps have no PhotoCraft equivalent yet",
        );
        let template = "{message} ({note})";
        crate::i18n::fmt(tl!(template), &[("message", &loaded), ("note", &note)])
    } else {
        loaded
    };
    // Show what arrived: select the first loaded action, expanded.
    let list = &app.session.actions.list;
    if let Some(first) = r["actions"][0].as_str()
        && let Some(i) = list.iter().position(|a| a.name == first)
    {
        app.ui.actions.select(i, None);
        app.ui.actions.expanded.resize(list.len(), false);
        if let Some(e) = app.ui.actions.expanded.get_mut(i) {
            *e = true;
        }
    }
    app.ui.panels.history = true;
    Ok(r)
}

/// Load every chosen action file in order, retaining failures and unsupported-step warnings.
fn load_dialog(app: &mut PhotocraftApp) -> Result<Value, String> {
    let initial_dir = crate::file_dialog::last_used_dir(&app.ui.recent_files);
    app.ask_file(FileDialogRequest::Open { multiple: true, initial_dir, extensions: Some(vec!["atn".into()]) }, |app, answer| {
        let files: Vec<_> = match answer {
            FileDialogAnswer::Paths(paths) => paths.into_iter().map(|name| (name, None)).collect(),
            FileDialogAnswer::Contents(name, bytes) => vec![(name, Some(bytes))],
            FileDialogAnswer::ContentsMany(files) => files.into_iter().map(|(name, bytes)| (name, Some(bytes))).collect(),
            _ => return Err("the file dialog gave an unexpected answer".into()),
        };
        let count = files.len();
        if count == 0 {
            return Err(crate::file_dialog::CANCELLED.into());
        }
        let mut loaded = 0usize;
        // What the panel holds afterwards, per set name: `actions.load` replaces a set of the same
        // name, so a later file's set takes the earlier one's place (and its counts).
        let mut sets: Vec<(String, String, usize, usize)> = Vec::new(); // set, file, actions, unsupported
        let mut replaced = Vec::new();
        let mut errors = Vec::new();
        let mut last = Value::Null;
        for (name, bytes) in files {
            // Native paths go through the engine's size check before reading the file.
            let params = match bytes {
                Some(bytes) => source(&name, &bytes),
                None => json!({"path": name}),
            };
            match load_source(app, &name, params) {
                Ok(r) => {
                    loaded += 1;
                    let shown = crate::file_open::display_name(&name);
                    let set = r["set"].as_str().unwrap_or_default().to_string();
                    let n = r["actions"].as_array().map_or(0, Vec::len);
                    let unsupported = r["unsupported"].as_array().map_or(0, Vec::len);
                    if let Some(entry) = sets.iter_mut().find(|e| e.0 == set) {
                        replaced.push(crate::i18n::fmt(
                            tl!("{set} from {file} replaced the one from {earlier}"),
                            &[("file", &shown), ("earlier", &entry.1), ("set", &set)],
                        ));
                        *entry = (set, shown, n, unsupported);
                    } else {
                        sets.push((set, shown, n, unsupported));
                    }
                    last = r;
                }
                Err(e) => errors.push(format!("{}: {e}", crate::file_open::display_name(&name))),
            }
        }
        if count == 1 {
            return match errors.pop() {
                Some(e) => Err(e),
                None => Ok(last),
            };
        }
        let actions = sets.iter().fold(0usize, |sum, e| sum.saturating_add(e.2));
        let unsupported = sets.iter().fold(0usize, |sum, e| sum.saturating_add(e.3));
        let lang = crate::i18n::current();
        let files = crate::i18n::trn(lang, loaded as u64, "{n} action file loaded", "{n} action files loaded");
        let mut notes = vec![crate::i18n::trn(lang, actions as u64, "{n} action", "{n} actions")];
        if unsupported > 0 {
            notes.push(crate::i18n::trn(lang, unsupported as u64, "{n} step has no PhotoCraft equivalent yet", "{n} steps have no PhotoCraft equivalent yet"));
        }
        notes.extend(replaced);
        if !errors.is_empty() {
            let failed = crate::i18n::trn(lang, errors.len() as u64, "{n} file could not be loaded: {errors}", "{n} files could not be loaded: {errors}");
            notes.push(crate::i18n::fmt(&failed, &[("errors", &errors.join("; "))]));
        }
        let template = "{message} ({note})";
        let summary = crate::i18n::fmt(tl!(template), &[("message", &files), ("note", &notes.join("; "))]);
        if !errors.is_empty() {
            return Err(summary);
        }
        app.ui.status = summary;
        app.ui.status_error = false;
        Ok(json!({"files": loaded, "actions": actions, "unsupported": unsupported}))
    })
}

/// Save Actions…: the selected action's set (every action of it), else the selected set folder,
/// or every action when none came from a set, as a `.atn` file Photoshop loads.
fn save_dialog(app: &mut PhotocraftApp, set: Option<String>) -> Result<Value, String> {
    let selected_set = app.ui.actions.selected.is_none().then(|| app.ui.actions.selected_set.clone()).flatten();
    let selected_set = selected_set.filter(|set| photocraft_engine::actions_edit_cmds::set_names(&app.session).contains(set));
    let set = set.or(selected_set).or_else(|| selected_action(app).and_then(|a| a.set.clone()));
    let params = match &set {
        Some(set) => json!({"set": set, "skipUnsupported": true}),
        None => json!({"skipUnsupported": true}),
    };
    let r = app.run("actions.save", params)?;
    let bytes = r["data"].as_str().and_then(photocraft_engine::paint::tile::b64_decode).ok_or("the export returned no data")?;
    let n = r["actions"].as_array().map_or(0, Vec::len) as u64;
    let skipped = r["skipped"].as_array().map_or(0, Vec::len);
    // A set name can hold characters a file name can't (as in Keyboard Shortcuts' Save), or be a
    // Windows device name (`CON`); the file keeps the set's own name.
    let stem: String = r["set"]
        .as_str()
        .unwrap_or("Actions")
        .chars()
        .map(|c| if c.is_control() || matches!(c, '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') { '_' } else { c })
        .collect();
    // A file name holds at most 255 bytes: the stem gets what `.atn` leaves, cut at a character.
    let mut stem = photocraft_engine::file_cmds::portable_device_name(stem);
    let mut cut = 255 - ".atn".len();
    while !stem.is_char_boundary(cut.min(stem.len())) {
        cut -= 1;
    }
    stem.truncate(cut);
    let file = format!("{stem}.atn");
    app.pick_save(&file, move |app, path| {
        let write = app.services.write.as_mut().ok_or("no writer configured")?;
        write(&path, &bytes)?;
        let shown = crate::file_open::display_name(&path);
        let saved =
            crate::i18n::fmt(&crate::i18n::trn(crate::i18n::current(), n, "Saved {n} action to {file}", "Saved {n} actions to {file}"), &[("file", &shown)]);
        app.ui.status_error = false;
        app.ui.status = if skipped > 0 {
            let note = crate::i18n::trn(
                crate::i18n::current(),
                skipped as u64,
                "{n} step with no Photoshop equivalent left out",
                "{n} steps with no Photoshop equivalent left out",
            );
            let template = "{message} ({note})";
            crate::i18n::fmt(tl!(template), &[("message", &saved), ("note", &note)])
        } else {
            saved
        };
        Ok(json!({"path": path, "actions": n, "skipped": skipped}))
    })
}

const INSERT_STOP: &str = "__insertStop";

/// The field marking a New Set… dialog.
const NEW_SET: &str = "__actionsNewSet";

pub fn owns_new_set(fields: &serde_json::Map<String, Value>) -> bool {
    fields.contains_key(NEW_SET)
}

/// New Set…: name an empty set folder (Photoshop's default "Set N").
fn new_set_dialog(app: &mut PhotocraftApp) -> Result<Value, String> {
    let names = photocraft_engine::actions_edit_cmds::set_names(&app.session);
    let name = (1u32..).map(|n| format!("Set {n}")).find(|n| !names.contains(n)).unwrap_or_default();
    let fields = json!({NEW_SET: true, "__command": "actions.newSet", "__label": "New Set", "name": name});
    let id = app.ui.open_dialog(crate::state::DialogKind::Command, fields.as_object().cloned().unwrap_or_default());
    Ok(json!({"dialog": id}))
}

pub fn new_set_body(ui: &mut egui::Ui, fields: &mut serde_json::Map<String, Value>) {
    ui.horizontal(|ui| {
        let label = ui.label(tl!("Name:"));
        let mut name = fields.get("name").and_then(Value::as_str).unwrap_or_default().to_string();
        ui.add(egui::TextEdit::singleline(&mut name).desired_width(220.0)).labelled_by(label.id);
        fields.insert("name".into(), json!(name));
    });
}

/// Make the set and select it, so New Action records into it.
pub fn new_set_confirm(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>) -> Result<Value, String> {
    let r = app.run("actions.newSet", json!({"name": fields.get("name").cloned().unwrap_or(Value::Null)}))?;
    app.ui.actions.selected_set = r["set"].as_str().map(str::to_string);
    app.ui.actions.selected = None;
    app.ui.actions.selected_step = None;
    Ok(r)
}

pub fn owns_insert_stop(fields: &serde_json::Map<String, Value>) -> bool {
    fields.contains_key(INSERT_STOP)
}

/// Insert Stop…: a message step after the selected step (or at the end of the selected action).
fn insert_stop_dialog(app: &mut PhotocraftApp) -> Result<Value, String> {
    let action = app.ui.actions.selected.filter(|i| *i < app.session.actions.list.len()).ok_or_else(|| tl!("Select an action first").to_string())?;
    let len = app.session.actions.list[action].steps.len() + actions_cmds::pending_steps(&app.session, action).count();
    let at = app.ui.actions.selected_step.map_or(len, |s| (s + 1).min(len));
    let fields =
        json!({INSERT_STOP: true, "__command": "actions.insert", "__label": "Insert Stop", "action": action, "at": at, "message": "", "allowContinue": false});
    let id = app.ui.open_dialog(crate::state::DialogKind::Command, fields.as_object().cloned().unwrap_or_default());
    Ok(json!({"dialog": id}))
}

pub fn insert_stop_body(ui: &mut egui::Ui, fields: &mut serde_json::Map<String, Value>) {
    let message_label = ui.label(tl!("Message:"));
    let mut message = fields.get("message").and_then(Value::as_str).unwrap_or_default().to_string();
    ui.add(egui::TextEdit::multiline(&mut message).desired_rows(4).desired_width(320.0)).labelled_by(message_label.id);
    fields.insert("message".into(), json!(message));
    ui.add_space(6.0);
    let mut allow = fields.get("allowContinue").and_then(Value::as_bool).unwrap_or(false);
    ui.checkbox(&mut allow, tl!("Allow Continue"));
    fields.insert("allowContinue".into(), json!(allow));
}

pub fn insert_stop_confirm(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>) -> Result<Value, String> {
    let action = fields.get("action").and_then(Value::as_u64).ok_or("the dialog names no action")?;
    let params = json!({
        "action": action,
        "at": fields.get("at").cloned().unwrap_or(Value::Null),
        "id": photocraft_engine::atn_cmds::STOP_MESSAGE,
        "params": {"message": fields.get("message").cloned().unwrap_or(json!("")), "allowContinue": fields.get("allowContinue").cloned().unwrap_or(json!(false))},
    });
    let r = app.run("actions.insert", params)?;
    if let (Some(a), Some(step)) = (usize::try_from(action).ok(), r["step"].as_u64().and_then(|s| usize::try_from(s).ok())) {
        app.ui.actions.select(a, Some(step));
        app.ui.actions.expanded.resize(app.session.actions.list.len(), false);
        if let Some(e) = app.ui.actions.expanded.get_mut(a) {
            *e = true;
        }
    }
    Ok(r)
}

/// The field marking a Stop step's message (the dialog toggle on, played by a person).
const STOP_DIALOG: &str = "__actionStop";

pub fn owns_stop_message(fields: &serde_json::Map<String, Value>) -> bool {
    fields.contains_key(STOP_DIALOG)
}

pub fn stop_message_body(ui: &mut egui::Ui, fields: &serde_json::Map<String, Value>) {
    ui.set_min_width(300.0);
    ui.add(egui::Label::new(fields.get("message").and_then(Value::as_str).unwrap_or_default()).wrap());
}

/// Continue (the default) and Stop, or Stop alone when the step doesn't allow continuing.
/// `Some(true)` continues, `Some(false)` stops. ↩ answers the default button from the frame after
/// the dialog appeared, so the ↩ that started the playback doesn't answer it too; the mark lives in
/// the dialog's own fields and goes with it.
pub fn stop_message_buttons(ui: &mut egui::Ui, fields: &mut serde_json::Map<String, Value>, interactive: bool) -> Option<bool> {
    use crate::widgets::{ButtonRole, DialogButton, dialog_buttons};
    let allow = fields.get("allowContinue").and_then(Value::as_bool).unwrap_or(false);
    let shown_before = fields.insert(STOP_SEEN.into(), json!(true)).is_some();
    let clicked = if allow {
        dialog_buttons(ui, &[DialogButton::new(ButtonRole::Default, tl!("Continue"), 84.0), DialogButton::new(ButtonRole::Cancel, tl!("Stop"), 84.0)])
    } else {
        dialog_buttons(ui, &[DialogButton::new(ButtonRole::Default, tl!("Stop"), 84.0)])
    };
    match clicked {
        Some(ButtonRole::Default) => Some(allow),
        Some(_) => Some(false),
        None if interactive && shown_before && ui.input(|i| i.key_pressed(egui::Key::Enter)) => Some(allow),
        None => None,
    }
}

/// The private field [`stop_message_buttons`] marks a drawn Stop message with.
const STOP_SEEN: &str = "__actionStopSeen";

/// Continue (OK, ↩, automation): the action goes on after the Stop when the step allows it, as
/// recorded; otherwise it ends there like Stop.
pub fn stop_message_confirm(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>) -> Result<Value, String> {
    let allow = fields.get(RESUME).and_then(Value::as_u64).and_then(|t| app.paused_playbacks.paused.get(&t)).is_some_and(|p| p.allow_continue);
    if allow {
        resume(app, fields)?;
    } else {
        stopped(app, fields);
    }
    Ok(json!({"continued": allow}))
}

/// The key a paused playback leaves in its dialog's fields: the token of its [`PausedPlayback`].
pub const RESUME: &str = "__resumeAction";

/// Resume the recording a paused call suspended and journal that call, once.
fn restore_recording(app: &mut PhotocraftApp, owner: Option<&Value>) {
    let Some(owner) = owner else { return };
    let (Some(idx), Some(into), Some(name)) = (
        owner.get("index").and_then(Value::as_u64).and_then(|n| usize::try_from(n).ok()),
        owner.get("into").and_then(Value::as_str),
        owner.get("action").and_then(Value::as_str),
    ) else {
        return;
    };
    let from = owner.get("from").and_then(Value::as_u64).and_then(|n| usize::try_from(n).ok()).unwrap_or(0);
    // `suspended_guard` refuses what would move the recorded action, but another command may
    // still replace the list: the call goes to the action of that name, never to whatever now
    // sits at the old index, and is dropped if that action is gone.
    let list = &app.session.actions.list;
    let target = if list.get(idx).is_some_and(|a| a.name == into) { Some(idx) } else { list.iter().position(|a| a.name == into) };
    if let Some(idx) = target
        && app.session.actions.recording.is_none()
    {
        actions_cmds::restore_recording(&mut app.session, idx, name, from);
    }
}

/// Whether a paused playback holds a suspended recording.
fn suspended(app: &PhotocraftApp) -> bool {
    app.paused_playbacks.paused.values().any(|p| p.record.is_some())
}

/// While a step dialog holds a suspended recording, refuse what would lose its call: a new
/// recording (the restore would find recording taken) or deleting/moving actions (the recorded
/// action could go away or change place). The engine checks these against `recording`, which
/// is `None` then.
pub(crate) fn suspended_guard(app: &PhotocraftApp, id: &str) -> Result<(), String> {
    if matches!(id, "actions.record" | "actions.delete" | "actions.move" | "actions.duplicate" | "actions.recordAgain" | "actions.allowToolRecording")
        && suspended(app)
    {
        return Err(tl!("Confirm or cancel the open action step dialog first").into());
    }
    Ok(())
}

/// A step dialog's command failed: the action ends there.
pub fn abandoned(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>) {
    let paused = fields.get(RESUME).and_then(|t| app.paused_playbacks.take(t));
    let record = paused.and_then(|p| {
        drop(p.history);
        p.record
    });
    actions_cmds::finish_pending_history(&mut app.session);
    restore_recording(app, record.as_ref());
}

/// The automation gate a session installs ([`photocraft_engine::Session::authorize`]).
type Gate = fn(&str, &Value) -> photocraft_engine::Result<()>;

/// Deferred Actions dialogs retain their caller's gate and also honor current permissions.
fn authorize_owned(app: &PhotocraftApp, id: &str, params: &Value, gate: Option<Gate>, automated: bool) -> Result<(), String> {
    if let Some(gate) = gate {
        gate(id, params).map_err(|e| e.to_string())?;
    }
    if let Some(current) = app.session.authorize {
        current(id, params).map_err(|e| e.to_string())?;
    }
    if (automated || app.automation_input || app.session.authorize.is_some())
        && let Some(check) = app.services.automation_command.as_ref()
    {
        check(id, params)?;
    }
    Ok(())
}

/// A function-pointer dispatch gate cannot carry two different policies into nested jobs.
/// Changed gates and distinct simultaneous Session/service gates both end this continuation;
/// hosts that need both policies must supply one composed gate at both boundaries.
fn continuation_gate(captured: Option<Gate>, live: Option<Gate>) -> Result<Option<Gate>, String> {
    if captured.zip(live).is_some_and(|(before, now)| !std::ptr::fn_addr_eq(before, now)) {
        return Err("the authorization context changed or uses policies that cannot be combined for this paused action".into());
    }
    Ok(live.or(captured))
}

/// A playback paused at a step dialog: the action and step it continues from, and the gate it
/// was playing under (`None` for one a person started).
#[derive(Clone, Debug)]
pub(crate) struct PausedPlayback {
    action: String,
    from: usize,
    gate: Option<Gate>,
    /// The recording the paused call suspended: `{index, into, action, from}` (`into` is the
    /// name of the action being recorded). A step dialog only closes through
    /// `dialogs::confirm` (OK, `↩`, automation) or `dialogs::cancel` (Cancel, Esc, the close
    /// box, automation), which end the call through `resume`, `abandoned` or `stopped`, so the
    /// recording comes back exactly once.
    record: Option<Value>,
    history: Option<actions_cmds::ActionHistoryContinuation>,
    /// The actions still to play after this one, as they were when Play started a whole set.
    /// Actions have no id, so the whole action stands in for one: an action deleted and made again
    /// under the same name, or edited, while the dialog is open no longer matches.
    then: Vec<Action>,
    /// The steps that Play ran before this pause (earlier actions of the set, and this one's
    /// steps before the dialog), so the final count covers the whole Play.
    ran: u64,
    /// The document a pause at Check Spelling was playing on. That dialog doesn't block the
    /// document tabs, so Done ([`resume_spelling`]) continues only on this document.
    doc: Option<photocraft_doc::DocId>,
    /// An implicit filter/adjustment step resolves this active layer at the pause. The outer Option marks
    /// that binding even when there was no active layer; explicit-layer and other dialogs omit it.
    filter_receiver: Option<Option<photocraft_doc::LayerId>>,
    /// Descriptor-free menu playback owns this settings dialog and the concrete command it opened.
    menu_editor: Option<(u64, String)>,
    /// The actions that called this one through Play Action steps, nearest first, each with the
    /// step it continues from: confirming the dialog finishes `action`, then each of them in turn
    /// (at most [`MAX_CALLERS`]).
    callers: Vec<(String, usize)>,
    /// A Stop step's Allow Continue, kept here rather than in the dialog's fields, which automation
    /// may rewrite: without it, confirming the message only ends the playback.
    allow_continue: bool,
    /// Parked by Step by Step or Pause For after a step that ran (counted in `ran`), not at a dialog
    /// whose own step runs on confirm.
    timed: bool,
    /// The paused action and each of its callers as they were when it paused, innermost first.
    /// The continuation goes on by name, so an action edited, deleted or replaced by a new one of
    /// the same name meanwhile ends it there instead of playing the new action's tail ([`resume`]).
    played: Vec<Action>,
}

/// The longest caller chain a paused playback keeps; [`actions_cmds::playback_plan`] refuses deeper
/// nesting anyway.
const MAX_CALLERS: usize = 16;

impl PausedPlayback {
    /// The action the person (or agent) started: the last caller, else the paused action.
    fn outermost(&self) -> &str {
        self.callers.last().map_or(self.action.as_str(), |(name, _)| name.as_str())
    }
}

/// The paused playbacks, by the token their dialog carries. The dialog's fields hold only the
/// token; what plays next, and under which gate, is kept here.
#[derive(Debug, Default)]
pub(crate) struct PausedPlaybacks {
    last: u64,
    paused: std::collections::HashMap<u64, PausedPlayback>,
    /// The Step by Step or Pause For playback waiting for its next step ([`playback::tick`]).
    timer: Option<playback::Timer>,
}

impl PausedPlaybacks {
    /// Allocate an opaque token retaining the action, resume position and captured authorization gate.
    fn pause(&mut self, action: String, from: usize, gate: Option<Gate>) -> u64 {
        self.last = self.last.wrapping_add(1);
        self.paused.insert(
            self.last,
            PausedPlayback {
                action,
                from,
                gate,
                record: None,
                history: None,
                then: Vec::new(),
                ran: 0,
                doc: None,
                filter_receiver: None,
                menu_editor: None,
                callers: Vec::new(),
                allow_continue: false,
                timed: false,
                played: Vec::new(),
            },
        );
        self.last
    }

    /// Consume the continuation named by a numeric dialog token; malformed or expired tokens identify no playback.
    fn take(&mut self, token: &Value) -> Option<PausedPlayback> {
        token.as_u64().and_then(|token| self.paused.remove(&token))
    }
}

/// Whether a dialog command's `target` belongs to the document rather than to a layer: alpha
/// channels and Quick Mask do; masks and colour components still belong to a layer.
fn document_target(params: &Value) -> bool {
    params.get("target").is_some_and(|target| target.as_str() == Some("quickMask") || target.get("channel").and_then(Value::as_u64).is_some())
}

/// Before a preview or confirmation evaluates settings, check the actual editor and its permissions.
pub(crate) fn authorize_panel_preview(
    app: &PhotocraftApp,
    dialog: u64,
    fields: &serde_json::Map<String, Value>,
    command: &str,
    params: &Value,
) -> Result<(), String> {
    record_again::authorize_preview(app, dialog, command, params)?;
    if let Some((token, paused)) = app.paused_playbacks.paused.iter().find(|(_, p)| p.menu_editor.as_ref().is_some_and(|(id, _)| *id == dialog)) {
        if fields.get(RESUME).and_then(Value::as_u64) != Some(*token) {
            return Err("the menu item dialog changed".into());
        }
        check_menu_editor(app, paused, command, params)?;
        authorize_owned(app, command, params, paused.gate, paused.gate.is_some())?;
    }
    Ok(())
}

/// Check that preview and confirmation still target the command and receiver that opened the editor.
fn check_menu_editor(app: &PhotocraftApp, paused: &PausedPlayback, command: &str, params: &Value) -> Result<(), String> {
    if let Some((_, original)) = &paused.menu_editor
        && (original != command
            || app.session.active().map(|st| st.doc.id) != paused.doc
            || (!document_target(params) && paused.filter_receiver != Some(app.session.active().and_then(|st| st.active_layer))))
    {
        return Err("the menu item command or its document changed".into());
    }
    Ok(())
}

/// Admit the final dialog command before resuming history or starting a worker. The captured
/// policy judges the edited parameters; a current live gate still governs dispatch and nested
/// work. With no live gate, reinstall the captured gate for job admission and rendering.
pub(crate) fn run_step_dialog(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>, command: &str, params: Value) -> Result<Value, String> {
    let Some(token) = fields.get(RESUME) else { return app.run(command, params) };
    let token = token.as_u64().ok_or("this dialog doesn't belong to a paused action")?;
    let paused = app.paused_playbacks.paused.get(&token).ok_or("this dialog doesn't belong to a paused action")?;
    check_menu_editor(app, paused, command, &params)?;
    if let Some(receiver) = paused.filter_receiver
        && !document_target(&params)
        && app.session.active().and_then(|st| st.active_layer) != receiver
    {
        return Err("the paused command's receiver changed while its dialog was open".into());
    }
    let captured = paused.gate;
    let saved = app.session.authorize;
    let service = if app.automation_input { app.services.automation_authorize } else { None };
    for authorize in [captured, saved, service].into_iter().flatten() {
        authorize(command, &params).map_err(|e| e.to_string())?;
    }
    if app.automation_input
        && let Some(authorize) = app.services.automation_command.as_ref()
    {
        authorize(command, &params)?;
    }
    let gate = continuation_gate(captured, continuation_gate(saved, service)?)?;
    prepare_history(app, fields)?;
    app.session.authorize = gate;
    let result = app.run(command, params);
    app.session.authorize = saved;
    result
}

/// Bind the dialog's own edit to its suspended action before it runs or starts a worker.
pub(crate) fn prepare_history(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>) -> Result<(), String> {
    let Some(token) = fields.get(RESUME).and_then(Value::as_u64) else { return Ok(()) };
    let history = app.paused_playbacks.paused.get_mut(&token).ok_or("this dialog doesn't belong to a paused action")?.history.take();
    if let Some(history) = history
        && let Err(e) = history.resume(&mut app.session)
    {
        if let Some(paused) = app.paused_playbacks.paused.get_mut(&token) {
            paused.history = Some(history);
        }
        return Err(e.to_string());
    }
    Ok(())
}

/// Check Spelling owns each correction only while it runs; the open window owns a bound token.
pub(crate) fn spelling_change(app: &mut PhotocraftApp, params: Value) -> Result<Value, String> {
    let Some(token) = app.ui.type_panels.spell.as_ref().and_then(|dialog| dialog.resume) else {
        return app.run("edit.checkSpelling", params);
    };
    let paused = app.paused_playbacks.paused.get(&token).ok_or("this dialog doesn't belong to a paused action")?;
    if paused.doc.is_some_and(|doc| Some(doc) != app.session.active().map(|state| state.doc.id)) {
        return Err("the active document changed while Check Spelling was open".into());
    }
    let history = paused.history.clone();
    let fields = serde_json::Map::from_iter([(RESUME.to_string(), json!(token))]);
    let result = run_step_dialog(app, &fields, "edit.checkSpelling", params);
    // A rejected admission did not resume this continuation. Keep the original token intact.
    if app.paused_playbacks.paused.get(&token).is_some_and(|paused| paused.history.is_some()) {
        return result;
    }
    if let Some(history) = history {
        match history.suspend_after_edit(&mut app.session) {
            Ok(history) => {
                let paused = app.paused_playbacks.paused.get_mut(&token).ok_or("the spelling continuation ended during its correction")?;
                paused.history = Some(history);
            }
            Err(error) => {
                if let Some(paused) = app.paused_playbacks.paused.get_mut(&token) {
                    paused.history = Some(history);
                }
                return Err(error.to_string());
            }
        }
    }
    result
}

/// Check Spelling's Done for the action paused at its step: the action continues when the document
/// it was playing on is still the active one, and otherwise ends there with the reason in the
/// status bar. Returns `Ok` when nothing failed.
pub(crate) fn resume_spelling(app: &mut PhotocraftApp, token: u64) -> Result<(), String> {
    let fields = serde_json::Map::from_iter([(RESUME.to_string(), json!(token))]);
    let Some((from, doc)) = app.paused_playbacks.paused.get(&token).map(|p| (p.from, p.doc)) else {
        return resume(app, &fields);
    };
    if doc.is_none() || doc == app.session.active().map(|d| d.doc.id) {
        return resume(app, &fields);
    }
    abandoned(app, &fields);
    let error = "the active document changed while Check Spelling was open";
    report_play(app, &json!({"failed": {"step": from.saturating_sub(1), "id": "edit.checkSpelling", "error": error}}));
    Err(error.into())
}

/// A step dialog confirmed: continue the action after it (`dialogs::confirm` calls this).
///
/// The remaining steps run under the gate the playback paused with, however the dialog was
/// confirmed: a control request, synthetic Enter or OK, or a click.
pub fn resume(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>) -> Result<(), String> {
    let Some(token) = fields.get(RESUME) else { return Ok(()) };
    let Some(paused) = app.paused_playbacks.take(token) else {
        return Err("this dialog doesn't belong to a paused action".into());
    };
    let owner = paused.record.clone();
    if let Some(history) = &paused.history
        && let Err(e) = history.resume(&mut app.session)
    {
        restore_recording(app, owner.as_ref());
        let template = "Action playback failed: {error}";
        app.ui.status = crate::i18n::fmt(tl!(template), &[("error", &e.to_string())]);
        app.ui.status_error = true;
        return Err(e.to_string());
    }
    // The dialog's command may run as a background job; the next step needs its result.
    if let Some(doc) = app.session.active().map(|d| d.doc.id)
        && let Some(job) = app.session.job_on(doc)
        && let Err(e) = app.session.wait_job(job.id)
    {
        actions_cmds::finish_pending_history(&mut app.session);
        restore_recording(app, owner.as_ref());
        let template = "Action playback failed: {error}";
        app.ui.status = crate::i18n::fmt(tl!(template), &[("error", &e.to_string())]);
        app.ui.status_error = true;
        return Err(e.to_string());
    }
    let saved = app.session.authorize;
    let service = if app.automation_input { app.services.automation_authorize } else { None };
    let remaining = !paused.then.is_empty()
        || !paused.callers.is_empty()
        || app
            .session
            .actions
            .list
            .iter()
            .find(|action| action.name == paused.action)
            .is_some_and(|action| action.enabled_steps().any(|(i, _)| i >= paused.from));
    let gate =
        if remaining { continuation_gate(saved, service).and_then(|live| continuation_gate(paused.gate, live)) } else { Ok(saved.or(service).or(paused.gate)) };
    let gate = match gate {
        Ok(gate) => gate,
        Err(error) => {
            // The admitted dialog edit has completed; preserve it while rejecting the tail.
            actions_cmds::finish_pending_history(&mut app.session);
            restore_recording(app, owner.as_ref());
            app.ui.status = error.clone();
            app.ui.status_error = true;
            return Err(error);
        }
    };
    // The rest plays by name: refuse it when an action of the paused call changed meanwhile, so a
    // new action of the same name never plays from the old one's step. With nothing left to play,
    // the call simply ends. (Another document coming to the front fails `history.resume` above.)
    let list = &app.session.actions.list;
    if remaining && paused.played.iter().any(|a| list.iter().find(|b| b.name == a.name) != Some(a)) {
        let error = "the action changed while it was paused";
        actions_cmds::finish_pending_history(&mut app.session);
        restore_recording(app, owner.as_ref());
        let template = "Action playback failed: {error}";
        app.ui.status = crate::i18n::fmt(tl!(template), &[("error", error)]);
        app.ui.status_error = true;
        return Err(error.into());
    }
    // The paused action goes on, then each action that called it, inside its callers' frames:
    // replay starts at the outermost, which replays the inner ones first.
    let frames: Vec<(String, usize)> = paused.callers.iter().rev().cloned().chain(std::iter::once((paused.action.clone(), paused.from))).collect();
    let Some(((outer, outer_from), inner)) = frames.split_first() else {
        return Err("this dialog doesn't belong to a paused action".into());
    };
    let params = json!({"action": outer, "from": outer_from});
    // A dialog's own step runs on its confirm; a paced wait's step already ran and was counted.
    let own = u64::from(!paused.timed);
    app.session.authorize = gate;
    let mut played = play_owned(app, &params, owner, inner);
    // Paused again at a later dialog of the same call: that dialog carries the rest of the set.
    if let Ok(v) = &played
        && let Some(dialog) = v.get("paused").and_then(waiting_dialog)
        && let Some(token) = paused_token(app, dialog)
        && let Some(entry) = app.paused_playbacks.paused.get_mut(&token)
        && entry.outermost() == paused.outermost()
    {
        entry.then = paused.then.clone();
        entry.ran = paused.ran.saturating_add(own).saturating_add(v.get("ran").and_then(Value::as_u64).unwrap_or(0));
    }
    // The count covers the steps this Play ran before the pause, and the step the dialog ran.
    let ran = paused.ran.saturating_add(own).saturating_add(played.as_ref().ok().and_then(|v| v.get("ran")).and_then(Value::as_u64).unwrap_or(0));
    if let Ok(Some(o)) = played.as_mut().map(Value::as_object_mut)
        && o.contains_key("ran")
    {
        o.insert("ran".into(), json!(ran));
    }
    // The rest of a set Play started: under the same gate, and only if this action finished. An
    // action of it deleted, renamed, edited or replaced by a new one of the same name meanwhile
    // ends the set there.
    if let Ok(v) = &played
        && !paused.then.is_empty()
        && v.get("failed").is_none()
        && v.get("paused").is_none()
        && v.get("stopped").is_none()
    {
        let list = &app.session.actions.list;
        let rest: Vec<usize> = paused.then.iter().map_while(|then| list.iter().position(|a| a == then)).collect();
        match play_targets(app, &rest, ran) {
            Ok(Some(r)) => played = Ok(r),
            Ok(None) => {}
            Err(e) => played = Err(e),
        }
    }
    app.session.authorize = saved;
    match played {
        Ok(v) => {
            report_play(app, &v);
            Ok(())
        }
        Err(e) => {
            let template = "Action playback failed: {error}";
            app.ui.status = crate::i18n::fmt(tl!(template), &[("error", &e)]);
            app.ui.status_error = true;
            Err(e)
        }
    }
}

/// A step dialog cancelled: the action stops there, as in Photoshop.
pub fn stopped(app: &mut PhotocraftApp, fields: &serde_json::Map<String, Value>) {
    if fields.contains_key(RESUME) {
        abandoned(app, fields);
        app.ui.status = tl!("Action playback stopped").to_string();
        app.ui.status_error = false;
    }
}

/// The Actions entries of the panel group's menu ("…").
pub fn panel_menu(app: &mut PhotocraftApp, ui: &mut egui::Ui) {
    let mut act: Option<&str> = None;
    let recording = app.session.actions.recording.is_some();
    let any = !app.session.actions.list.is_empty();
    let selected = app.ui.actions.selected.is_some_and(|i| i < app.session.actions.list.len());
    let can_delete = selected && (!recording || app.ui.actions.selected_step.is_some());
    if ui.add_enabled(!recording, egui::Button::new(tl!("New Action…"))).clicked() {
        act = Some("new");
    }
    if ui.button(tl!("New Set…")).clicked() {
        act = Some("newSet");
    }
    let can_duplicate_set =
        !recording && app.ui.actions.selected_set.as_ref().is_some_and(|set| photocraft_engine::actions_edit_cmds::set_names(&app.session).contains(set));
    if ui.add_enabled(can_delete || can_duplicate_set, egui::Button::new(tl!("Duplicate"))).clicked() {
        act = Some("duplicate");
    }
    if ui.add_enabled(can_delete, egui::Button::new(tl!("Delete"))).clicked() {
        act = Some("delete");
    }
    if ui.add_enabled(any, egui::Button::new(tl!("Play"))).clicked() {
        act = Some("play");
    }
    if recording {
        if ui.button(tl!("Stop Recording")).clicked() {
            act = Some("stopRec");
        }
    } else if ui.button(tl!("Start Recording")).clicked() {
        act = Some("record");
    }
    if ui.add_enabled(selected && app.ui.actions.selected_step.is_some() && !recording, egui::Button::new(tl!("Record Again"))).clicked() {
        act = Some("recordAgain");
    }
    ui.separator();
    if ui.add_enabled(selected, egui::Button::new(tl!("Insert Menu Item…"))).clicked() {
        act = Some("insertMenu");
    }
    if ui.add_enabled(selected, egui::Button::new(tl!("Insert Stop…"))).clicked() {
        act = Some("stop");
    }
    let path_selected =
        app.ui.selected_path.as_deref().is_some_and(|name| photocraft_engine::actions_edit_cmds::selected_recording_path(&app.session, name).is_ok());
    if ui.add_enabled(selected && path_selected, egui::Button::new(tl!("Insert Path"))).clicked() {
        act = Some("insertPath");
    }
    ui.separator();
    // Enabled with nothing selected, as in the reference application; not while a paced Play waits.
    if ui.add_enabled(!playback::pending(app), egui::Button::new(tl!("Playback Options…"))).clicked() {
        act = Some("playbackOptions");
    }
    let mut tools = app.session.actions.record_tools;
    if crate::widgets::checkbox(ui, &mut tools, tl!("Allow Tool Recording")).changed() {
        act = Some("toolRecording");
    }
    ui.separator();
    if ui.button(tl!("Load Actions…")).clicked() {
        act = Some("load");
    }
    // A selected set folder saves even when empty, as Photoshop saves an empty set.
    let set_selected = app.ui.actions.selected_set.as_ref().is_some_and(|set| photocraft_engine::actions_edit_cmds::set_names(&app.session).contains(set));
    if ui.add_enabled(any || set_selected, egui::Button::new(tl!("Save Actions…"))).clicked() {
        act = Some("save");
    }
    let Some(a) = act else { return };
    ui.close();
    let r = match a {
        "new" => {
            begin_recording(app, false);
            Ok(Value::Null)
        }
        "record" => {
            begin_recording(app, true);
            Ok(Value::Null)
        }
        "stopRec" => app.run("actions.stop", json!({})),
        "play" => {
            let targets = playback_targets(app);
            play_targets(app, &targets, 0).map(|v| {
                if let Some(v) = &v {
                    report_play(app, v);
                }
                v.unwrap_or(Value::Null)
            })
        }
        "delete" => {
            delete_selection(app);
            Ok(Value::Null)
        }
        "duplicate" => duplicate_selection(app),
        "recordAgain" => record_again::open(app),
        "toolRecording" => app.run("actions.allowToolRecording", json!({"enabled": tools})),
        "insertPath" => app.run(
            "actions.insertPath",
            json!({"action": app.ui.actions.selected, "at": app.ui.actions.selected_step.map(|i| i.saturating_add(1)), "name": app.ui.selected_path}),
        ),
        "insertMenu" => menu_item::open(app),
        "load" => load_dialog(app),
        "newSet" => new_set_dialog(app),
        "stop" => insert_stop_dialog(app),
        "playbackOptions" => playback::open_dialog(app),
        _ => save_dialog(app, None),
    };
    if let Err(e) = r
        && e != "cancelled"
    {
        app.ui.status = e;
        app.ui.status_error = true;
    }
}

#[derive(Clone, Copy)]
struct DragRow {
    action: usize,
    step: Option<usize>,
}

/// Drops use an insertion line, converted to the final index expected by actions.move.
fn drag_row(ui: &egui::Ui, response: &egui::Response, row: DragRow, t: &Tokens) -> Option<(DragRow, usize)> {
    response.dnd_set_drag_payload(row);
    let source = response.dnd_hover_payload::<DragRow>()?;
    if source.step.is_some() != row.step.is_some() || (source.step.is_some() && source.action != row.action) {
        return None;
    }
    let after = ui.input(|i| i.pointer.hover_pos().is_some_and(|p| p.y >= response.rect.center().y));
    let index = row.step.unwrap_or(row.action);
    let from = source.step.unwrap_or(source.action);
    let slot = index.saturating_add(usize::from(after));
    let to = if from < slot { slot.saturating_sub(1) } else { slot };
    let y = if after { response.rect.bottom() } else { response.rect.top() };
    ui.painter().line_segment([pos2(response.rect.left() + 22.0, y), pos2(response.rect.right(), y)], Stroke::new(2.0, t.accent));
    response.dnd_release_payload::<DragRow>().map(|source| (*source, to))
}

fn move_row(app: &mut PhotocraftApp, source: DragRow, to: usize) {
    let mut params = json!({"action": source.action, "to": to});
    if let Some(step) = source.step {
        params["step"] = json!(step);
    }
    if app.run("actions.move", params).is_err() {
        return;
    }
    if source.step.is_some() {
        app.ui.actions.select(source.action, Some(to));
    } else {
        app.ui.actions.expanded.resize(app.session.actions.list.len(), false);
        if source.action < app.ui.actions.expanded.len() && to < app.ui.actions.expanded.len() {
            let expanded = app.ui.actions.expanded.remove(source.action);
            app.ui.actions.expanded.insert(to, expanded);
        }
        app.ui.actions.select(to, None);
        // Dropped among another set's actions: the action joins that set (the row above wins).
        let list = &app.session.actions.list;
        let neighbour = to.checked_sub(1).and_then(|j| list.get(j)).or_else(|| list.get(to + 1)).and_then(|a| a.set.clone());
        if list.get(to).is_some_and(|a| a.set != neighbour) {
            let _ = app.run("actions.assignSet", json!({"action": to, "set": neighbour}));
        }
    }
}

/// Keep the selection and disclosure rows on the new copy after the engine edits the list.
fn duplicate_selection(app: &mut PhotocraftApp) -> Result<Value, String> {
    if app.ui.actions.selected.is_none()
        && let Some(set) = app.ui.actions.selected_set.clone()
    {
        let count = app.session.actions.list.len();
        let result = app.run("actions.duplicate", json!({"set": set}))?;
        if let (Some(at), Some(added)) = (result["index"].as_u64(), result["actions"].as_u64())
            && let (Ok(at), Ok(added)) = (usize::try_from(at), usize::try_from(added))
            && at <= count
        {
            app.ui.actions.expanded.resize(count, false);
            app.ui.actions.expanded.splice(at..at, std::iter::repeat_n(false, added));
        }
        app.ui.actions.selected_set = result["set"].as_str().map(str::to_owned);
        app.ui.actions.selected = None;
        app.ui.actions.selected_step = None;
        return Ok(result);
    }
    let action = app.ui.actions.selected.ok_or_else(|| tl!("Select an action first").to_string())?;
    let step = app.ui.actions.selected_step;
    let count = app.session.actions.list.len();
    let expanded = app.ui.actions.expanded.get(action).copied().unwrap_or(false);
    let result = app.run("actions.duplicate", json!({"action": action, "step": step}))?;
    let index = result["index"].as_u64().and_then(|i| usize::try_from(i).ok()).ok_or("the copy has no action index")?;
    app.ui.actions.selected = Some(index);
    app.ui.actions.selected_step = result.get("step").and_then(Value::as_u64).and_then(|i| usize::try_from(i).ok());
    if step.is_none() {
        app.ui.actions.expanded.resize(count, false);
        if index <= app.ui.actions.expanded.len() {
            app.ui.actions.expanded.insert(index, expanded);
        }
    } else {
        app.ui.actions.expanded.resize(count, false);
        if let Some(expanded) = app.ui.actions.expanded.get_mut(index) {
            *expanded = true;
        }
    }
    Ok(result)
}

fn delete_selection(app: &mut PhotocraftApp) {
    let Some(action) = app.ui.actions.selected else { return };
    let step = app.ui.actions.selected_step;
    let mut params = json!({"action": action});
    if let Some(step) = step {
        params["step"] = json!(step);
    }
    if app.run("actions.delete", params).is_err() {
        return;
    }
    // Clear selection after deletion so a second click cannot delete a different
    // step or unexpectedly fall back to deleting the entire action.
    app.ui.actions.selected = None;
    app.ui.actions.selected_step = None;
    if step.is_none() && action < app.ui.actions.expanded.len() {
        app.ui.actions.expanded.remove(action);
    }
}

/// The in-place name field of the action being renamed. Enter, Tab or clicking elsewhere
/// returns the new name to commit; Escape cancels and keeps the old name.
fn rename_field(app: &mut PhotocraftApp, ui: &mut egui::Ui, index: usize, rect: Rect) -> Option<String> {
    let mut r = app.ui.actions.renaming.take().filter(|r| r.index == index)?;
    let id = egui::Id::unique(("action-rename-field", index));
    let te = ui.put(rect, egui::TextEdit::singleline(&mut r.text).id(id).font(egui::FontId::proportional(12.0))).accessible_name(tl!("Name"));
    if !r.focused {
        te.request_focus();
        // Like Photoshop, the whole name starts selected so typing replaces it.
        if let Some(mut state) = egui::TextEdit::load_state(ui.ctx(), id) {
            let all = egui::text::CCursorRange::two(egui::text::CCursor::new(0), egui::text::CCursor::new(r.text.chars().count()));
            state.cursor.set_char_range(Some(all));
            state.store(ui.ctx(), id);
        }
        r.focused = true;
        app.ui.actions.renaming = Some(r);
        return None;
    }
    let (enter, tab, esc) = ui.input(|i| (i.key_pressed(egui::Key::Enter), i.key_pressed(egui::Key::Tab), i.key_pressed(egui::Key::Escape)));
    if esc {
        None
    } else if enter || tab || te.lost_focus() || !te.has_focus() {
        Some(r.text)
    } else {
        app.ui.actions.renaming = Some(r);
        None
    }
}

fn rename_action(app: &mut PhotocraftApp, index: usize, name: String) {
    if let Err(e) = app.run("actions.rename", json!({"action": index, "name": name})) {
        let template = "Could not rename the action: {error}";
        app.ui.status = crate::i18n::fmt(tl!(template), &[("error", &e)]);
        app.ui.status_error = true;
    }
}

/// One action's row data for a frame.
struct Row {
    name: String,
    steps: Vec<(String, Value)>,
    disabled: std::collections::BTreeSet<usize>,
    dialogs: std::collections::BTreeSet<usize>,
    set: Option<String>,
    color: String,
}

/// The panel's order: actions outside any set first, then each set folder (in order of first
/// appearance) with its actions. Indices are into the engine's flat list.
fn display_order(rows: &[Row]) -> Vec<usize> {
    let mut order: Vec<usize> = rows.iter().enumerate().filter(|(_, r)| r.set.is_none()).map(|(i, _)| i).collect();
    let mut sets: Vec<&str> = Vec::new();
    for r in rows {
        if let Some(set) = r.set.as_deref()
            && !sets.contains(&set)
        {
            sets.push(set);
        }
    }
    for set in sets {
        order.extend(rows.iter().enumerate().filter(|(_, r)| r.set.as_deref() == Some(set)).map(|(i, _)| i));
    }
    order
}

struct SetHeaderResult {
    /// A click on the disclosure triangle (or an activation without a pointer): collapse or expand.
    toggled: bool,
    /// A click on the rest of the row (or an activation without a pointer): select the set.
    picked: bool,
    save: bool,
}

fn draw_set_header(ui: &mut egui::Ui, set: &str, count: u64, collapsed: bool, selected: bool, tokens: &Tokens) -> SetHeaderResult {
    let (rect, response) = ui.allocate_exact_size(vec2(ui.available_width(), 24.0), Sense::click());
    response.widget_info(|| egui::WidgetInfo::selected(egui::Role::Button, true, selected, set));
    if selected {
        ui.painter().rect_filled(rect, 0.0, tokens.row_selected);
    } else if response.hovered() {
        ui.painter().rect_filled(rect, 0.0, tokens.hover.gamma_multiply(0.5));
    }
    let triangle = Rect::from_center_size(pos2(rect.left() + 12.0, rect.center().y), vec2(8.0, 8.0));
    let points = if collapsed {
        vec![triangle.left_top(), triangle.right_center(), triangle.left_bottom()]
    } else {
        vec![triangle.left_top(), triangle.right_top(), triangle.center_bottom()]
    };
    ui.painter().add(egui::Shape::convex_polygon(points, tokens.text_dim, Stroke::NONE));
    icons::paint(
        ui,
        Rect::from_center_size(pos2(rect.left() + 30.0, rect.center().y), vec2(16.0, 16.0)),
        if collapsed { "folder" } else { "folder-open" },
        12.0,
        tokens.icon,
    );
    ui.painter().text(pos2(rect.left() + 44.0, rect.center().y), Align2::LEFT_CENTER, set, egui::FontId::proportional(12.0), tokens.text);
    let summary = crate::i18n::trn(crate::i18n::current(), count, "{n} action", "{n} actions");
    ui.painter().text(pos2(rect.right() - 8.0, rect.center().y), Align2::RIGHT_CENTER, summary, egui::FontId::proportional(11.0), tokens.text_faint);
    // As on an action row, a click in the triangle's column collapses or expands and one on the
    // rest of the row selects. An activation without a pointer (keyboard, accessibility) does
    // both, so the set can still be collapsed and expanded without a mouse.
    let pointer = response.interact_pointer_pos();
    let toggled = response.clicked() && pointer.is_none_or(|p| p.x < rect.left() + 20.0);
    let picked = response.clicked() && pointer.is_none_or(|p| p.x >= rect.left() + 20.0);
    let mut save = false;
    response.context_menu(|ui| {
        if ui.button(tl!("Save Set…")).clicked() {
            save = true;
            ui.close();
        }
    });
    SetHeaderResult { toggled, picked, save }
}

/// The sets New Set made that hold no action yet: empty folder rows after the rest. Returns the
/// set whose row was clicked (whether it toggles, whether it selects) and the set whose Save Set…
/// was chosen.
fn draw_empty_sets(app: &PhotocraftApp, ui: &mut egui::Ui, rows: &[Row], t: &Tokens) -> (Option<(String, bool, bool)>, Option<String>) {
    let (mut clicked, mut save) = (None, None);
    for set in app.session.actions.sets.iter().filter(|set| !rows.iter().any(|r| r.set.as_ref() == Some(*set))) {
        let selected = app.ui.actions.selected.is_none() && app.ui.actions.selected_set.as_ref() == Some(set);
        let collapsed = app.ui.actions.collapsed_sets.contains(set);
        let result = draw_set_header(ui, set, 0, collapsed, selected, t);
        if result.toggled || result.picked {
            clicked = Some((set.clone(), result.toggled, result.picked));
        }
        if result.save {
            save = Some(set.clone());
        }
    }
    (clicked, save)
}

fn action_context_menu(app: &mut PhotocraftApp, response: &egui::Response, index: usize, name: &str, swatch: &str) {
    egui::Popup::context_menu(response).close_behavior(egui::PopupCloseBehavior::CloseOnClickOutside).show(|ui| {
        ui.label(tl!("Keyboard Shortcuts"));
        let current = app.session.prefs().shortcuts.get(&shortcut_id(name)).cloned().unwrap_or_default();
        // Photoshop's Action Options: a function key, with Shift and Command (#7646).
        let (key, mut shift, mut command) = photocraft_engine::atn_cmds::parse_function_key(&current).unwrap_or((0, false, false));
        for number in std::iter::once(0).chain(1..=12) {
            let label = if number == 0 { tl!("None").to_string() } else { format!("F{number}") };
            if ui.selectable_label(key == number, label).clicked() {
                let chosen = if number == 0 { String::new() } else { photocraft_engine::atn_cmds::function_key_name(number, shift, command) };
                let _ = assign_shortcut(app, name, &chosen);
                ui.close();
            }
        }
        ui.add_enabled_ui(key > 0, |ui| {
            let command_label = if cfg!(target_os = "macos") { tl!("Command") } else { tl!("Ctrl") };
            let toggled = ui.checkbox(&mut shift, tl!("Shift")).changed() | ui.checkbox(&mut command, command_label).changed();
            if toggled {
                let _ = assign_shortcut(app, name, &photocraft_engine::atn_cmds::function_key_name(key, shift, command));
            }
        });
        ui.separator();
        ui.menu_button(tl!("Color"), |ui| {
            for (id, label) in [
                ("", tl!("None")),
                ("red", tl!("Red")),
                ("orange", tl!("Orange")),
                ("yellow", tl!("Yellow")),
                ("green", tl!("Green")),
                ("blue", tl!("Blue")),
                ("violet", tl!("Violet")),
                ("gray", tl!("Gray")),
            ] {
                if ui.selectable_label(swatch == id, label).clicked() {
                    let _ = app.run("actions.setColor", json!({"action": index, "color": id}));
                    ui.close();
                }
            }
        });
    });
}

pub fn panel(app: &mut PhotocraftApp, ui: &mut egui::Ui) {
    let t = Tokens::get(ui.ctx());
    let recording = app.session.actions.recording;
    let rows: Vec<Row> = app
        .session
        .actions
        .list
        .iter()
        .enumerate()
        .map(|(i, a)| Row {
            name: a.name.clone(),
            steps: visible_steps(app, i),
            disabled: a.disabled.clone(),
            dialogs: a.dialogs.clone(),
            set: a.set.clone(),
            color: a.color.clone(),
        })
        .collect();
    if app
        .ui
        .actions
        .selected
        .is_some_and(|i| i >= rows.len() || app.ui.actions.selected_step.is_some_and(|step| rows.get(i).is_none_or(|row| step >= row.steps.len())))
    {
        app.ui.actions.selected = None;
        app.ui.actions.selected_step = None;
    }
    if app.ui.actions.expanded.len() > rows.len() {
        app.ui.actions.expanded.truncate(rows.len());
    }
    if app.ui.actions.renaming.as_ref().is_some_and(|r| r.index >= rows.len()) {
        app.ui.actions.renaming = None;
    }
    let mut renamed = None;
    let mut toggled = None;
    let mut dialog_toggled = None;
    let mut set_toggled: Option<(String, bool, bool)> = None;
    let mut save_set: Option<String> = None;
    let max_h = (ui.available_height() - 38.0).max(0.0);
    let mut play_idx: Option<Vec<usize>> = None;
    let mut moved = None;
    let recording_row = recording.and_then(|(_, i)| rows.get(i).map(|r| (i, r.steps.len())));
    let reveal = recording_row.filter(|row| app.ui.actions.reveal_recording != Some(*row));
    app.ui.actions.reveal_recording = recording_row;
    if let Some((i, _)) = reveal {
        app.ui.actions.expanded.resize(rows.len(), false);
        if let Some(expanded) = app.ui.actions.expanded.get_mut(i) {
            *expanded = true;
        }
    }
    egui::ScrollArea::vertical().id_salt("actions-rows").max_height(max_h).min_scrolled_height(max_h).auto_shrink([false, false]).show(ui, |ui| {
        if rows.is_empty() {
            ui.label(egui::RichText::new(tl!("Record ● a sequence of edits, then play ▶ it on any document.")).color(t.text_faint).size(11.5));
        }
        scroll_actions_during_drag(ui);
        let mut shown_set: Option<&str> = None;
        for i in display_order(&rows) {
            let Row { name, steps, disabled, dialogs, set, color: swatch } = &rows[i];
            // A set folder row before the first of its actions; collapsed folders hide them.
            if let Some(set) = set.as_deref()
                && shown_set != Some(set)
            {
                shown_set = Some(set);
                let collapsed = app.ui.actions.collapsed_sets.iter().any(|c| c == set);
                let count = rows.iter().filter(|r| r.set.as_deref() == Some(set)).count() as u64;
                let selected = app.ui.actions.selected.is_none() && app.ui.actions.selected_set.as_deref() == Some(set);
                let result = draw_set_header(ui, set, count, collapsed, selected, &t);
                if result.toggled || result.picked {
                    set_toggled = Some((set.to_string(), result.toggled, result.picked));
                }
                if result.save {
                    save_set = Some(set.to_string());
                }
            }
            if set.as_deref().is_some_and(|set| app.ui.actions.collapsed_sets.iter().any(|c| c == set)) {
                continue;
            }
            let indent = if set.is_some() { 14.0 } else { 0.0 };
            let (rect, resp) = ui.allocate_exact_size(vec2(ui.available_width(), 26.0), Sense::click_and_drag());
            let x0 = rect.left() + indent;
            if reveal == Some((i, 0)) {
                ui.scroll_to_rect(rect, Some(egui::Align::BOTTOM));
            }
            let button_mode = app.ui.actions.button_mode;
            let sel = app.ui.actions.selected == Some(i) && app.ui.actions.selected_step.is_none();
            resp.widget_info(|| egui::WidgetInfo::selected(egui::Role::Button, true, sel, name));
            if button_mode {
                ui.painter().rect_filled(rect, 3.0, button_fill(swatch, &t));
            } else if sel {
                ui.painter().rect_filled(rect, 0.0, t.row_selected);
            } else if resp.hovered() {
                ui.painter().rect_filled(rect, 0.0, t.hover.gamma_multiply(0.5));
            }
            if let Some(change) = drag_row(ui, &resp, DragRow { action: i, step: None }, &t) {
                moved = Some(change);
            }
            let expanded = app.ui.actions.expanded.get(i).copied().unwrap_or(false) && !button_mode;
            if !button_mode {
                let tri = Rect::from_center_size(pos2(x0 + 12.0, rect.center().y), vec2(8.0, 8.0));
                let pts = if expanded {
                    vec![tri.left_top(), tri.right_top(), tri.center_bottom()]
                } else {
                    vec![tri.left_top(), tri.right_center(), tri.left_bottom()]
                };
                ui.painter().add(egui::Shape::convex_polygon(pts, t.text_dim, Stroke::NONE));
                crate::icons::paint(ui, Rect::from_center_size(pos2(x0 + 30.0, rect.center().y), vec2(16.0, 16.0)), "play", 11.0, t.icon);
            }
            let recording_this = recording.is_some_and(|(_, r)| r == i);
            let nsteps = steps.len();
            let name_x = if button_mode { x0 + 8.0 } else { x0 + 44.0 };
            let name_color = if button_mode { button_label_color(swatch, &t) } else { t.text };
            let name_rect = if app.ui.actions.renaming.as_ref().is_some_and(|r| r.index == i) {
                let field = Rect::from_min_max(pos2(x0 + 40.0, rect.top() + 3.0), pos2((rect.right() - 80.0).max(x0 + 120.0), rect.bottom() - 3.0));
                if let Some(text) = rename_field(app, ui, i, field) {
                    renamed = Some((i, text));
                }
                field
            } else {
                ui.painter().text(pos2(name_x, rect.center().y), Align2::LEFT_CENTER, name, egui::FontId::proportional(12.0), name_color)
            };
            if !button_mode {
                ui.painter().text(
                    pos2(rect.right() - 8.0, rect.center().y),
                    Align2::RIGHT_CENTER,
                    app.session
                        .prefs()
                        .shortcuts
                        .get(&shortcut_id(name))
                        .filter(|s| !s.is_empty())
                        .map_or_else(|| step_count(nsteps, disabled.len()), |key| format!("{key} · {}", step_count(nsteps, disabled.len()))),
                    egui::FontId::proportional(11.0),
                    t.text_faint,
                );
            }
            if recording_this {
                ui.painter().circle_filled(pos2(rect.right() - 64.0, rect.center().y), 4.0, Color32::from_rgb(230, 60, 60));
            }
            if resp.clicked() {
                app.ui.actions.select(i, None);
                if button_mode {
                    if !resp.double_clicked() {
                        play_idx = Some(vec![i]);
                    }
                } else if resp.interact_pointer_pos().is_some_and(|p| p.x < x0 + 20.0) {
                    if app.ui.actions.expanded.len() <= i {
                        app.ui.actions.expanded.resize(i + 1, false);
                    }
                    app.ui.actions.expanded[i] = !expanded;
                }
            }
            // Clicks inside stay open, so Shift and Command can both be ticked; every item that
            // finishes closes the menu itself.
            action_context_menu(app, &resp, i, name, swatch);
            if resp.double_clicked() && !button_mode {
                // Photoshop renames in place when the name itself is double-clicked.
                if resp.interact_pointer_pos().is_some_and(|p| name_rect.expand2(vec2(4.0, 13.0)).contains(p)) {
                    app.ui.actions.renaming = Some(RenameAction { index: i, text: name.clone(), focused: false });
                } else {
                    play_idx = Some(vec![i]);
                }
            }
            if expanded {
                let context = StepRowsContext { action: i, x0, steps, disabled, dialogs, reveal, tokens: &t };
                let events = draw_step_rows(app, ui, &context);
                moved = moved.or(events.moved);
                toggled = toggled.or(events.toggled);
                dialog_toggled = dialog_toggled.or(events.dialog_toggled);
            }
        }
        let (empty_toggled, empty_save) = draw_empty_sets(app, ui, &rows, &t);
        set_toggled = set_toggled.take().or(empty_toggled);
        save_set = save_set.take().or(empty_save);
    });
    if let Some((action, step)) = toggled {
        let _ = app.run("actions.toggle", json!({"action": action, "step": step}));
    }
    if let Some((action, step)) = dialog_toggled {
        let _ = app.run("actions.dialog", json!({"action": action, "step": step}));
    }
    if let Some((set, toggle, pick)) = set_toggled {
        // The rest of the folder row selects the set, for New Action and Play.
        if pick {
            app.ui.actions.selected = None;
            app.ui.actions.selected_step = None;
            app.ui.actions.selected_set = Some(set.clone());
        }
        // The disclosure triangle collapses or expands the set and leaves the selection alone.
        if toggle {
            match app.ui.actions.collapsed_sets.iter().position(|c| *c == set) {
                Some(i) => {
                    app.ui.actions.collapsed_sets.remove(i);
                }
                None => app.ui.actions.collapsed_sets.push(set),
            }
        }
    }
    if let Some(set) = save_set
        && let Err(e) = save_dialog(app, Some(set))
        && e != "cancelled"
    {
        app.ui.status = e;
        app.ui.status_error = true;
    }
    if let Some((index, name)) = renamed {
        rename_action(app, index, name);
    }
    if let Some((source, to)) = moved {
        move_row(app, source, to);
    }
    ui.add_space(4.0);
    ui.horizontal(|ui| {
        ui.spacing_mut().item_spacing.x = 2.0;
        let recording_now = app.session.actions.recording.is_some();
        if crate::icons::button(ui, "square", 24.0, false, tl!("Stop playing/recording")).clicked() && !playback::stop(app) && recording_now {
            let _ = app.run("actions.stop", json!({}));
        }
        let (r, rec) = ui.allocate_exact_size(vec2(24.0, 24.0), Sense::click());
        if rec.hovered() {
            ui.painter().rect_filled(r, 3.0, t.hover);
        }
        ui.painter().circle_filled(r.center(), 5.5, if recording_now { Color32::from_rgb(230, 60, 60) } else { t.icon });
        if rec.on_hover_text(tl!("Begin recording")).clicked() && !recording_now {
            begin_recording(app, true);
        }
        let play = crate::icons::button(ui, "play", 24.0, false, tl!("Play selection"));
        play.widget_info(|| egui::WidgetInfo::labeled(egui::Role::Button, true, tl!("Play selection")));
        if play.clicked() {
            play_idx = Some(playback_targets(app));
        }
        if crate::icons::button(ui, "folder", 24.0, false, tl!("Create new set")).clicked()
            && let Err(e) = new_set_dialog(app)
        {
            app.ui.status = e;
            app.ui.status_error = true;
        }
        if crate::icons::button(ui, "plus", 24.0, false, tl!("Create new action")).clicked() && !recording_now {
            begin_recording(app, false);
        }
        let can_delete = app.ui.actions.selected.is_some() && (!recording_now || app.ui.actions.selected_step.is_some());
        ui.add_enabled_ui(can_delete, |ui| {
            let response = crate::icons::button(ui, "trash", 24.0, false, tl!("Delete"));
            response.widget_info(|| egui::WidgetInfo::labeled(egui::Role::Button, can_delete, tl!("Delete")));
            if response.clicked() {
                delete_selection(app);
            }
        });
        let mode_label = if app.ui.actions.button_mode { tl!("Button Mode On") } else { tl!("Button Mode") };
        let mode_button = ui.add_enabled(!recording_now, egui::Button::new(mode_label).small()).on_hover_text(tl!("Button Mode"));
        mode_button.widget_info(|| egui::WidgetInfo::labeled(egui::Role::Button, !recording_now, mode_label));
        if mode_button.clicked() {
            app.ui.actions.button_mode = !app.ui.actions.button_mode;
        }
    });
    if let Some(targets) = play_idx {
        match play_targets(app, &targets, 0) {
            Ok(Some(v)) => report_play(app, &v),
            Ok(None) => {}
            Err(e) => {
                let template = "Action playback failed: {error}";
                app.ui.status = crate::i18n::fmt(tl!(template), &[("error", &e)]);
                app.ui.status_error = true;
            }
        }
    }
}

fn scroll_actions_during_drag(ui: &mut egui::Ui) {
    if !egui::DragAndDrop::has_payload_of_type::<DragRow>(ui.ctx()) {
        return;
    }
    let clip = ui.clip_rect();
    let Some(pointer) = ui.input(|input| input.pointer.hover_pos()).filter(|p| clip.contains(*p)) else { return };
    let delta = if pointer.y < clip.top() + 22.0 {
        8.0
    } else if pointer.y > clip.bottom() - 22.0 {
        -8.0
    } else {
        0.0
    };
    if delta == 0.0 {
        return;
    }
    ui.scroll_with_delta(vec2(0.0, delta));
    ui.ctx().request_repaint();
}

struct StepRowsContext<'a> {
    action: usize,
    x0: f32,
    steps: &'a [(String, Value)],
    disabled: &'a std::collections::BTreeSet<usize>,
    dialogs: &'a std::collections::BTreeSet<usize>,
    reveal: Option<(usize, usize)>,
    tokens: &'a Tokens,
}

#[derive(Default)]
struct StepRowEvents {
    moved: Option<(DragRow, usize)>,
    toggled: Option<(usize, usize)>,
    dialog_toggled: Option<(usize, usize)>,
}

fn draw_step_rows(app: &mut PhotocraftApp, ui: &mut egui::Ui, context: &StepRowsContext<'_>) -> StepRowEvents {
    let mut events = StepRowEvents::default();
    for (step, (id, params)) in context.steps.iter().enumerate() {
        let (rect, response) = ui.allocate_exact_size(vec2(ui.available_width(), 20.0), Sense::click_and_drag());
        if context.reveal == Some((context.action, step + 1)) {
            ui.scroll_to_rect(rect, Some(egui::Align::BOTTOM));
        }
        let label = step_label(id, params);
        draw_step_label(app, ui, rect, &response, step, &label, context);
        events.moved = drag_row(ui, &response, DragRow { action: context.action, step: Some(step) }, context.tokens).or(events.moved);
        let (check, dialog) = draw_step_controls(ui, rect, step, &label, context);
        if check.clicked() {
            events.toggled = Some((context.action, step));
        } else if dialog.clicked() {
            events.dialog_toggled = Some((context.action, step));
        } else if response.clicked() {
            app.ui.actions.select(context.action, Some(step));
        }
    }
    events
}

fn draw_step_label(app: &PhotocraftApp, ui: &egui::Ui, rect: Rect, response: &egui::Response, step: usize, label: &str, context: &StepRowsContext<'_>) {
    let selected = app.ui.actions.selected == Some(context.action) && app.ui.actions.selected_step == Some(step);
    response.widget_info(|| egui::WidgetInfo::selected(egui::Role::Button, true, selected, label));
    if selected {
        ui.painter().rect_filled(rect, 0.0, context.tokens.row_selected);
    } else if response.hovered() {
        ui.painter().rect_filled(response.rect, 0.0, context.tokens.hover.gamma_multiply(0.5));
    }
    let color = if context.disabled.contains(&step) { context.tokens.text_faint } else { context.tokens.text_dim };
    ui.painter().text(pos2(context.x0 + 62.0, rect.center().y), Align2::LEFT_CENTER, label, egui::FontId::proportional(11.5), color);
}

fn draw_step_controls(ui: &mut egui::Ui, rect: Rect, step: usize, label: &str, context: &StepRowsContext<'_>) -> (egui::Response, egui::Response) {
    let on = !context.disabled.contains(&step);
    let check = ui.interact(
        Rect::from_center_size(pos2(context.x0 + 30.0, rect.center().y), vec2(16.0, 16.0)),
        ui.scope_id().with(("action-step-check", context.action, step)),
        Sense::click(),
    );
    check.widget_info(|| egui::WidgetInfo::selected(egui::Role::CheckBox, true, on, format!("{}: {label}", tl!("Include in playback"))));
    paint_check(ui, check.rect, on, context.tokens);
    let with_dialog = context.dialogs.contains(&step);
    let dialog = ui.interact(
        Rect::from_center_size(pos2(context.x0 + 46.0, rect.center().y), vec2(16.0, 16.0)),
        ui.scope_id().with(("action-step-dialog", context.action, step)),
        Sense::click(),
    );
    dialog.widget_info(|| egui::WidgetInfo::selected(egui::Role::Button, true, with_dialog, format!("{}: {label}", tl!("Show dialog during playback"))));
    crate::icons::paint(
        ui,
        dialog.rect,
        "message-square",
        11.0,
        if with_dialog { context.tokens.icon } else { context.tokens.text_faint.gamma_multiply(0.45) },
    );
    (check.on_hover_text(tl!("Include in playback")), dialog.on_hover_text(tl!("Show dialog during playback")))
}

pub(crate) mod menu_item;
pub(crate) mod playback;
pub(crate) mod record_again;

#[cfg(test)]
mod tests;

#[cfg(test)]
mod stop_tests;

#[cfg(test)]
mod playback_tests;
