use super::*;

#[test]
fn modifier_operations() {
    let m = |shift, alt| egui::Modifiers { command: true, shift, alt, ..Default::default() };
    assert_eq!(load_operation(m(false, false)), "new");
    assert_eq!(load_operation(m(true, false)), "add");
    assert_eq!(load_operation(m(false, true)), "subtract");
    assert_eq!(load_operation(m(true, true)), "intersect");
}

#[test]
fn rename_field_interrupts_the_ime_only_when_it_takes_focus() {
    let mut app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
    app.run("file.new", json!({"width": 32, "height": 32})).unwrap();
    app.run("channel.new", json!({})).unwrap();
    let ctx = egui::Context::default();
    crate::theme::install_fonts(&ctx);
    ctx.run_ui(Default::default(), |_| {}).textures_delta.clear();
    let doc = app.session.active().unwrap().doc.id.0;
    let name = app.session.active().unwrap().doc.channels[0].name.clone();
    ctx.data_mut(|d| d.insert_temp(egui::Id::unique(("chan-rename", doc, format!("{:?}", Row::Alpha(0).reference()))), name));
    // The field takes focus on the first pass and owns the IME from the second on (#585).
    let interrupts: Vec<Option<bool>> = (0..4)
        .map(|_| {
            let mut out = ctx.run_ui(Default::default(), |ui| show(&mut app, ui));
            out.textures_delta.clear();
            out.platform_output.ime.map(|ime| ime.should_interrupt_composition)
        })
        .collect();
    assert_eq!(interrupts, [None, Some(false), Some(false), Some(false)]);
}

#[test]
fn channel_thumbs_honours_show_channels_in_color() {
    let mut app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
    app.run("file.new", json!({"width": 16, "height": 16})).unwrap();
    let ctx = egui::Context::default();
    let thumbs_gray = app.channel_thumbs(&ctx);
    assert!(!thumbs_gray.is_empty());

    app.session.execute("prefs.set", json!({"values": {"interface.showChannelsInColor": true}})).unwrap();
    let thumbs_color = app.channel_thumbs(&ctx);
    assert_eq!(thumbs_gray.len(), thumbs_color.len());
}

/// A selection-only step keeps the thumbnails; a pixel edit rebuilds them into the same
/// textures rather than new ones (#4518).
#[test]
fn channel_thumbs_skip_selection_steps_and_reuse_textures() {
    let mut app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
    app.run("file.new", json!({"width": 64, "height": 48})).unwrap();
    let ctx = egui::Context::default();
    // Texture uploads one pass makes (new textures and updates both count).
    let pass = |app: &mut PhotocraftApp| {
        ctx.begin_pass(Default::default());
        let ids = app.channel_thumbs(&ctx);
        let mut delta = ctx.end_pass().textures_delta;
        let n = delta.set.len();
        delta.clear();
        (ids, n)
    };
    let (first, uploads) = pass(&mut app);
    assert!(uploads > 0);
    app.run("select.rect", json!({"x": 4, "y": 4, "width": 20, "height": 20})).unwrap();
    assert_eq!(pass(&mut app), (first.clone(), 0), "a marquee changes no pixels");
    app.run("select.deselect", json!({})).unwrap();
    assert_eq!(pass(&mut app), (first.clone(), 0), "neither does Deselect");
    app.run("edit.fill", json!({"color": "#336699"})).unwrap();
    let (after, uploads) = pass(&mut app);
    assert!(uploads > 0, "a fill rebuilds them");
    assert_eq!(after, first, "into the same textures");
}

/// The Channels tab (the Layers card's second tab) of a 64×48 white document with a layer
/// mask on "Masked" and one alpha channel.
fn channels_harness() -> (egui_kittest::Harness<'static, PhotocraftApp>, u64) {
    let mut s = photocraft_engine::Session::new();
    s.execute("file.new", json!({"width": 64, "height": 48})).unwrap();
    let masked = s.execute("layer.new.layer", json!({"name": "Masked"})).unwrap()["layer"].as_u64().unwrap();
    s.execute("layer.layerMask.revealAll", json!({"layer": masked})).unwrap();
    s.execute("channel.new", json!({})).unwrap();
    // 60 fps steps, so two clicks a frame apart count as a double-click.
    let mut h = egui_kittest::Harness::builder().with_size(vec2(1440.0, 1000.0)).with_step_dt(1.0 / 60.0).with_max_steps(64).build_eframe(move |cc| {
        PhotocraftApp::setup_context(&cc.egui_ctx, Default::default());
        PhotocraftApp::new(s, crate::Services::default())
    });
    let ctx = h.ctx.clone();
    let (req, _rx) = crate::control::ControlRequest::new(
        "ui.set",
        json!({"dockWidth": 290.0, "dockTabs": {"layers": 1}, "dock": {"collapsed": ["color", "properties", "history", "navigator"]}}),
    );
    crate::control::handle(h.state_mut(), &ctx, &req);
    h.run_steps(8);
    (h, masked)
}

/// The centre of the row or button labelled `label` (not its tooltip, which a hover leaves open).
fn at(h: &egui_kittest::Harness<'_, PhotocraftApp>, label: &str) -> egui::Pos2 {
    use egui::accesskit::Role;
    use egui_kittest::kittest::{NodeT, Queryable};
    h.query_all_by_label(label)
        .find(|n| matches!(n.accesskit_node().role(), Role::Button | Role::ListBoxOption | Role::Label) && n.rect().height() > 20.0)
        .unwrap_or_else(|| panic!("no row or button {label}"))
        .rect()
        .center()
}

/// A real press, drag and release.
fn drag(h: &mut egui_kittest::Harness<'_, PhotocraftApp>, from: egui::Pos2, to: egui::Pos2) {
    use egui::{Modifiers, PointerButton};
    h.hover_at(from);
    h.run_steps(1);
    h.event(egui::Event::PointerButton { pos: from, button: PointerButton::Primary, pressed: true, modifiers: Modifiers::NONE });
    h.run_steps(1);
    for i in 1..=6 {
        h.hover_at(from + (to - from) * (i as f32 / 6.0));
        h.run_steps(1);
    }
    h.event(egui::Event::PointerButton { pos: to, button: PointerButton::Primary, pressed: false, modifiers: Modifiers::NONE });
    h.run_steps(3);
}

/// Drags the row or button labelled `from` onto the one labelled `to`.
fn drag_to(h: &mut egui_kittest::Harness<'_, PhotocraftApp>, from: &str, to: &str) {
    let (from, to) = (at(h, from), at(h, to));
    drag(h, from, to);
}

fn alphas(h: &egui_kittest::Harness<'_, PhotocraftApp>) -> Vec<String> {
    h.state().session.active().unwrap().doc.channels.iter().map(|c| c.name.clone()).collect()
}

/// Row selection sets the visible components; eye clicks subsequently override only the
/// view. Exercise real Shift-clicks so panel event routing and later frames keep that split.
#[test]
fn channel_selection_sets_visibility_and_eye_overrides_do_not_retarget() {
    use egui::{Event, Modifiers, PointerButton};
    for (mode, first, second, third, selected) in
        [("rgb", "Red", "Blue", "Green", vec![0, 2]), ("cmyk", "Cyan", "Magenta", "Yellow", vec![0, 1]), ("lab", "a", "b", "Lightness", vec![1, 2])]
    {
        let (mut h, _) = channels_harness();
        if mode != "rgb" {
            h.state_mut().run(&format!("image.mode.{mode}"), json!({})).unwrap();
            h.run_steps(2);
        }
        let click = |h: &mut egui_kittest::Harness<'_, PhotocraftApp>, label: &str, modifiers| {
            let pos = at(h, label);
            h.event(Event::ModifiersChanged(modifiers));
            h.hover_at(pos);
            h.run_steps(1);
            for pressed in [true, false] {
                h.event(Event::PointerButton { pos, button: PointerButton::Primary, pressed, modifiers });
                h.run_steps(1);
            }
            h.event(Event::ModifiersChanged(Modifiers::NONE));
            h.run_steps(3);
        };
        let visible = |h: &egui_kittest::Harness<'_, PhotocraftApp>| {
            let st = h.state().session.active().unwrap();
            (0..st.doc.pixel_format().mode.color_channels()).filter(|k| st.channel_view.color_visible(*k)).collect::<Vec<_>>()
        };
        let colors = |h: &egui_kittest::Harness<'_, PhotocraftApp>| {
            photocraft_engine::color_channels::selected(&h.state().session).unwrap().indices().collect::<Vec<_>>()
        };

        click(&mut h, first, Modifiers::NONE);
        assert_eq!(visible(&h), vec![selected[0]], "{mode}: clicking one row shows it alone");
        assert!(!h.state().session.active().unwrap().channel_view.alpha_shown(0));
        click(&mut h, second, Modifiers::SHIFT);
        assert_eq!(colors(&h), selected);
        assert_eq!(visible(&h), selected, "{mode}: extending the selection shows just its components");

        click(&mut h, &format!("Visibility {third}"), Modifiers::NONE);
        assert_eq!(visible(&h).len(), 3, "{mode}: the eye adds a visible component");
        assert_eq!(colors(&h), selected, "the eye does not extend the editing target");
        click(&mut h, &format!("Visibility {first}"), Modifiers::NONE);
        let manual = visible(&h);
        assert!(!manual.contains(&selected[0]));
        assert_eq!(colors(&h), selected, "a selected component can be hidden manually");
        h.state_mut().run("image.adjustments.invert", json!({})).unwrap();
        h.run_steps(3);
        assert_eq!(visible(&h), manual, "editing and rendering preserve manual visibility");

        click(&mut h, first, Modifiers::NONE);
        assert_eq!(visible(&h), vec![selected[0]], "a new row selection resets its default view");
        click(&mut h, second, Modifiers::SHIFT);
        assert_eq!(visible(&h), selected);
        click(&mut h, third, Modifiers::SHIFT);
        assert_eq!(visible(&h).len(), 3);
        if mode == "cmyk" {
            click(&mut h, "Black", Modifiers::SHIFT);
        }
        let st = h.state().session.active().unwrap();
        assert_eq!(st.channel_view.target, ChannelTarget::Composite);
        assert_eq!(visible(&h).len(), st.doc.pixel_format().mode.color_channels());
    }
}

/// #9163: alpha channels reorder by dragging, as in Photoshop: a drop in a row's upper half
/// lands above it, over the colour channels it lands first among the alphas, colour channels
/// don't move, and each reorder is one history step.
#[test]
fn alpha_channels_reorder_by_dragging() {
    let (mut h, _) = channels_harness();
    h.state_mut().run("channel.new", json!({"name": "Alpha 2"})).unwrap();
    h.state_mut().run("channel.new", json!({"name": "Alpha 3"})).unwrap();
    h.run_steps(3);
    assert_eq!(alphas(&h), ["Alpha 1", "Alpha 2", "Alpha 3"]);
    let steps = h.state().session.active().unwrap().history.past_len();

    let (from, onto) = (at(&h, "Alpha 3"), at(&h, "Alpha 1"));
    drag(&mut h, from, onto - vec2(0.0, 8.0));
    assert_eq!(alphas(&h), ["Alpha 3", "Alpha 1", "Alpha 2"]);
    assert_eq!(h.state().session.active().unwrap().history.past_len(), steps + 1, "one history step");

    // The lower half of a row: below it.
    let (from, onto) = (at(&h, "Alpha 3"), at(&h, "Alpha 1"));
    drag(&mut h, from, onto + vec2(0.0, 8.0));
    assert_eq!(alphas(&h), ["Alpha 1", "Alpha 3", "Alpha 2"]);

    // Dropped on a colour channel: first among the alphas.
    drag_to(&mut h, "Alpha 2", "Red");
    assert_eq!(alphas(&h), ["Alpha 2", "Alpha 1", "Alpha 3"]);

    // A colour channel dragged onto the alphas stays where it is.
    let before = h.state().session.active().unwrap().history.past_len();
    drag_to(&mut h, "Green", "Alpha 3");
    assert_eq!(alphas(&h), ["Alpha 2", "Alpha 1", "Alpha 3"]);
    assert_eq!(h.state().session.active().unwrap().history.past_len(), before);
}

/// #4689: as in Photoshop, a channel dropped on New is duplicated, on Delete deleted, and on
/// Load Channel as Selection loaded.
#[test]
fn rows_dropped_on_the_footer_duplicate_delete_and_load() {
    let (mut h, _) = channels_harness();
    assert_eq!(alphas(&h), ["Alpha 1"]);
    let steps = h.state().session.active().unwrap().history.past_len();

    drag_to(&mut h, "Alpha 1", "Create new channel");
    assert_eq!(alphas(&h), ["Alpha 1", "Alpha 1 copy"]);
    assert_eq!(h.state().session.active().unwrap().history.past_len(), steps + 1, "one history step");
    drag_to(&mut h, "Red", "Create new channel");
    assert_eq!(alphas(&h), ["Alpha 1", "Alpha 1 copy", "Red copy"]);
    drag_to(&mut h, "Masked Mask", "Create new channel");
    assert_eq!(alphas(&h), ["Alpha 1", "Alpha 1 copy", "Red copy", "Masked Mask copy"]);

    drag_to(&mut h, "Alpha 1 copy", "Delete current channel");
    assert_eq!(alphas(&h), ["Alpha 1", "Red copy", "Masked Mask copy"]);
    // Colour channels stay: Photoshop would turn the image into Multichannel.
    drag_to(&mut h, "Green", "Delete current channel");
    assert_eq!(alphas(&h), ["Alpha 1", "Red copy", "Masked Mask copy"]);
    assert_eq!(h.state().session.active().unwrap().doc.mode, photocraft_doc::ColorMode::Rgb);

    assert!(h.state().session.active().unwrap().doc.selection.is_none());
    drag_to(&mut h, "Red copy", "Load channel as selection");
    assert!(h.state().session.active().unwrap().doc.selection.is_some(), "the white channel selects everything");
}

/// The footer follows the targeted row shown by the panel when mask painting is active,
/// even though the engine's channel-view target remains Composite. Other channel targets
/// continue to load their own values, and each load remains one undoable selection change.
#[test]
fn footer_loads_the_selected_layer_mask_and_preserves_color_alpha_targets() {
    let (mut h, _) = channels_harness();
    h.state_mut().run("select.rect", json!({"x": 0, "y": 0, "width": 32, "height": 48})).unwrap();
    h.state_mut().run("layer.layerMask.hideAll", json!({})).unwrap();
    h.state_mut().run("layer.layerMask.revealSelection", json!({})).unwrap();
    h.state_mut().run("channel.target", json!({"channel": "composite"})).unwrap();
    h.state_mut().ui.mask_target = true;
    h.run_steps(2);

    let click_load = |h: &mut egui_kittest::Harness<'_, PhotocraftApp>| {
        use egui::{Modifiers, PointerButton};
        let p = at(h, "Load channel as selection");
        h.hover_at(p);
        h.run_steps(1);
        h.event(egui::Event::PointerButton { pos: p, button: PointerButton::Primary, pressed: true, modifiers: Modifiers::NONE });
        h.run_steps(1);
        h.event(egui::Event::PointerButton { pos: p, button: PointerButton::Primary, pressed: false, modifiers: Modifiers::NONE });
        h.run_steps(2);
    };
    let sample =
        |h: &egui_kittest::Harness<'_, PhotocraftApp>, x, y| h.state().session.active().unwrap().doc.selection.as_ref().unwrap().sample_channel(x, y, 0);

    assert_eq!(h.state().session.active().unwrap().channel_view.target, ChannelTarget::Composite);
    click_load(&mut h);
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 0.0), "mask row selection wins over the Composite engine target");
    h.state_mut().run("edit.undo", json!({})).unwrap();
    assert!(h.state().session.active().unwrap().doc.selection.is_none());
    h.state_mut().run("edit.redo", json!({})).unwrap();
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 0.0));

    h.state_mut().ui.mask_target = false;
    h.state_mut().run("channel.target", json!({"channel": "composite"})).unwrap();
    click_load(&mut h);
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 1.0), "composite luminosity remains available");
    h.state_mut().run("edit.undo", json!({})).unwrap();
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 0.0));
    h.state_mut().run("edit.redo", json!({})).unwrap();
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 1.0));

    h.state_mut().run("select.rect", json!({"x": 0, "y": 0, "width": 32, "height": 48})).unwrap();
    h.state_mut().run("channel.new", json!({"fill": "selection"})).unwrap();
    h.state_mut().run("select.deselect", json!({})).unwrap();
    h.state_mut().run("channel.target", json!({"channel": "red"})).unwrap();
    click_load(&mut h);
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 1.0), "color channel still loads its own plane");
    h.state_mut().run("edit.undo", json!({})).unwrap();
    h.state_mut().run("edit.redo", json!({})).unwrap();
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 1.0));

    h.state_mut().run("channel.target", json!({"channel": 1})).unwrap();
    click_load(&mut h);
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 0.0), "alpha channel still loads its own plane");
    h.state_mut().run("edit.undo", json!({})).unwrap();
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 1.0));
    h.state_mut().run("edit.redo", json!({})).unwrap();
    assert_eq!((sample(&h, 8, 8), sample(&h, 48, 8)), (1.0, 0.0));
}

/// A plain click on a row still targets it, and a drag released elsewhere does nothing.
#[test]
fn clicks_still_target_and_a_drop_elsewhere_does_nothing() {
    let (mut h, _) = channels_harness();
    let p = at(&h, "Alpha 1");
    h.hover_at(p);
    h.run_steps(1);
    h.event(egui::Event::PointerButton { pos: p, button: egui::PointerButton::Primary, pressed: true, modifiers: Default::default() });
    h.run_steps(1);
    h.event(egui::Event::PointerButton { pos: p, button: egui::PointerButton::Primary, pressed: false, modifiers: Default::default() });
    h.run_steps(3);
    assert_eq!(h.state().session.active().unwrap().channel_view.target, ChannelTarget::Alpha(0));

    let steps = h.state().session.active().unwrap().history.past_len();
    let (from, to) = (at(&h, "Alpha 1"), at(&h, "Blue"));
    drag(&mut h, from, to);
    drag_to(&mut h, "Alpha 1", "Save selection as channel");
    assert_eq!(alphas(&h), ["Alpha 1"]);
    assert_eq!(h.state().session.active().unwrap().history.past_len(), steps, "nothing ran");
    assert!(h.ctx.data(|d| d.get_temp::<(Row, String)>(drag_id())).is_none(), "the drag ended");
}

/// Double-clicking the layer mask's row opens Layer Mask Display Options, as in Photoshop; OK
/// sets the rubylith's colour and opacity, a view setting rather than an undo step.
#[test]
fn double_clicking_the_layer_mask_row_opens_its_display_options() {
    let (mut h, _) = channels_harness();
    let steps = h.state().session.active().unwrap().history.past_len();
    let p = at(&h, "Masked Mask");
    h.hover_at(p);
    h.run_steps(30);
    for pressed in [true, false, true, false] {
        h.event(egui::Event::PointerButton { pos: p, button: egui::PointerButton::Primary, pressed, modifiers: egui::Modifiers::NONE });
        h.step();
    }
    h.run_steps(3);
    let d = h.state().ui.dialogs.last().expect("a dialog opens");
    assert!(crate::channel_options_ui::owns(&d.fields), "{:?}", d.fields);
    assert_eq!((d.fields["channel"].clone(), d.fields["color"].clone(), d.fields["opacity"].clone()), (json!("mask"), json!("#ff0000"), json!(50.0)));
    let id = d.id;
    let d = h.state_mut().ui.dialog_mut(id).unwrap();
    d.fields.insert("color".into(), json!("#0000ff"));
    d.fields.insert("opacity".into(), json!(80.0));
    crate::dialogs::confirm(h.state_mut(), id).unwrap();
    let o = &h.state().session.prefs().layer_mask_overlay;
    assert_eq!((o.color.as_str(), o.opacity), ("#0000ff", 80.0));
    assert_eq!(h.state().session.active().unwrap().history.past_len(), steps, "no history step");
}

/// The layer mask's row asks "Apply mask to layer before removing?", like its Layers thumbnail.
#[test]
fn the_layer_mask_row_on_the_trash_asks_first() {
    let (mut h, masked) = channels_harness();
    drag_to(&mut h, "Masked Mask", "Delete current channel");
    assert!(h.state().ui.dialogs.iter().any(|d| crate::mask_trash_prompt::owns(&d.fields)), "the prompt is open");
    let st = h.state().session.active().unwrap();
    assert!(st.doc.layer(photocraft_doc::LayerId(masked)).unwrap().mask.is_some(), "nothing deleted yet");
}

/// A colour channel click recorded into an action saves as Photoshop's component select and
/// targets the same channel as the index did.
#[test]
fn recorded_colour_clicks_save_as_component_selects() {
    use photocraft_doc::ColorMode;
    for (mode, color_mode, count) in [("rgb", ColorMode::Rgb, 3), ("cmyk", ColorMode::Cmyk, 4), ("lab", ColorMode::Lab, 3)] {
        for k in 0..count {
            let mut s = photocraft_engine::Session::new();
            s.execute("file.new", json!({"width": 2, "height": 1, "mode": mode})).unwrap();
            let by_index = s.execute("channel.target", json!({"channel": Row::Color(k).reference(), "extend": false})).unwrap();
            s.execute("channel.target", json!({"channel": "composite"})).unwrap();
            let params = json!({"channel": Row::Color(k).target_reference(color_mode), "extend": false});
            assert_eq!(s.execute("channel.target", params.clone()).unwrap(), by_index, "{mode}/{k}");
            s.actions.list.push(photocraft_engine::actions_cmds::Action::new("Click", vec![("channel.target".into(), params)]));
            let saved = s.execute("actions.save", json!({"action": "Click"})).unwrap_or_else(|e| panic!("{mode}/{k}: {e}"));
            assert_eq!(saved["skipped"], json!([]));
            let loaded = s.execute("actions.load", json!({"data": saved["data"]})).unwrap();
            assert_eq!(loaded["unsupported"], json!([]), "{mode}/{k}");
            let name = photocraft_engine::channel_cmds::color_names(color_mode)[k].to_ascii_lowercase();
            assert_eq!(s.actions.list.last().unwrap().steps, vec![("channel.target".to_string(), json!({"channel": {"color": name}}))]);
        }
    }
    // Rows the colour names can't express keep their reference.
    assert_eq!(Row::Color(0).target_reference(ColorMode::Grayscale), Row::Color(0).reference());
    assert_eq!(Row::Alpha(1).target_reference(ColorMode::Rgb), json!(1));
    assert_eq!(Row::QuickMask.target_reference(ColorMode::Rgb), json!("composite"));
}

/// A real click on a colour row while recording records the colour by name, and the recorded
/// action saves strictly and reloads as the same step.
#[test]
fn recording_a_colour_row_click_saves_as_photoshop_select() {
    use egui::{Event, Modifiers, PointerButton};
    for (mode, label, name) in [("rgb", "Red", "red"), ("cmyk", "Cyan", "cyan"), ("lab", "Lightness", "lightness")] {
        let (mut h, _) = channels_harness();
        if mode != "rgb" {
            h.state_mut().run(&format!("image.mode.{mode}"), json!({})).unwrap();
            h.run_steps(2);
        }
        h.state_mut().run("actions.record", json!({"name": "Click"})).unwrap();
        let pos = at(&h, label);
        h.hover_at(pos);
        h.run_steps(1);
        for pressed in [true, false] {
            h.event(Event::PointerButton { pos, button: PointerButton::Primary, pressed, modifiers: Modifiers::NONE });
            h.run_steps(1);
        }
        h.run_steps(3);
        h.state_mut().run("actions.stop", json!({})).unwrap();
        let s = &mut h.state_mut().session;
        let recorded = s.actions.list.iter().find(|a| a.name == "Click").unwrap().steps.clone();
        let step = ("channel.target".to_string(), json!({"channel": {"color": name}, "extend": false}));
        assert_eq!(recorded, vec![step], "{mode}");
        let saved = s.execute("actions.save", json!({"action": "Click"})).unwrap_or_else(|e| panic!("{mode}: {e}"));
        assert_eq!(saved["skipped"], json!([]), "{mode}");
        let loaded = s.execute("actions.load", json!({"data": saved["data"]})).unwrap();
        assert_eq!(loaded["unsupported"], json!([]), "{mode}");
        let reloaded = &s.actions.list.last().unwrap().steps;
        assert_eq!(reloaded, &vec![("channel.target".to_string(), json!({"channel": {"color": name}}))], "{mode}");
    }
}

/// The panel menu's single-channel items act on the targeted channel (#11451): a targeted spot
/// channel can be duplicated, given options, merged or deleted; a colour channel duplicated.
#[test]
fn panel_menu_items_act_on_the_targeted_channel() {
    use egui_kittest::kittest::{NodeT, Queryable};
    let mut app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
    app.run("file.new", json!({"width": 32, "height": 24})).unwrap();
    app.run("channel.newSpot", json!({"name": "Ink", "fromSelection": false})).unwrap();
    app.run("channel.target", json!({"channel": 0})).unwrap();
    let mut h = egui_kittest::Harness::builder().with_size(vec2(260.0, 420.0)).build_ui_state(|ui, app: &mut PhotocraftApp| panel_menu(app, ui), app);
    h.run_steps(2);
    for label in ["Duplicate Channel", "Delete Channel", "Merge Spot Channel", "Channel Options…"] {
        assert!(!h.get_by_label(label).accesskit_node().is_disabled(), "{label} acts on the targeted spot channel");
    }
    h.get_by_label("Channel Options…").click();
    h.run_steps(2);
    assert!(h.state().ui.dialogs.iter().any(|d| crate::channel_options_ui::owns(&d.fields) && d.fields["channel"] == json!(0)));
    h.get_by_label("Duplicate Channel").click();
    h.run_steps(2);
    assert_eq!(alpha_names(h.state()), ["Ink", "Ink copy"]);
    h.get_by_label("Delete Channel").click();
    h.run_steps(2);
    assert_eq!(alpha_names(h.state()), ["Ink copy"], "the targeted channel is deleted");
    h.state_mut().run("channel.target", json!({"channel": {"color": 1}})).unwrap();
    h.run_steps(2);
    assert!(h.get_by_label("Delete Channel").accesskit_node().is_disabled(), "colour channels aren't deleted here");
    h.get_by_label("Duplicate Channel").click();
    h.run_steps(2);
    assert_eq!(alpha_names(h.state()), ["Ink copy", "Green copy"]);
    assert!(!h.state().ui.status_error, "{}", h.state().ui.status);
}

fn alpha_names(app: &PhotocraftApp) -> Vec<String> {
    app.session.active().unwrap().doc.channels.iter().map(|c| c.name.clone()).collect()
}

fn menu_app(mode: &str) -> PhotocraftApp {
    let mut app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
    app.run("file.new", json!({"width": 32, "height": 24, "mode": mode})).unwrap();
    app
}

fn menu_harness(app: PhotocraftApp) -> egui_kittest::Harness<'static, PhotocraftApp> {
    let mut h = egui_kittest::Harness::builder().with_size(vec2(260.0, 420.0)).build_ui_state(|ui, app: &mut PhotocraftApp| panel_menu(app, ui), app);
    h.run_steps(2);
    h
}

fn menu_disabled(h: &egui_kittest::Harness<'static, PhotocraftApp>, label: &str) -> bool {
    use egui_kittest::kittest::{NodeT, Queryable};
    h.get_by_label(label).accesskit_node().is_disabled()
}

fn menu_click(h: &mut egui_kittest::Harness<'static, PhotocraftApp>, label: &str) {
    use egui_kittest::kittest::Queryable;
    h.get_by_label(label).click();
    h.run_steps(2);
    assert!(!h.state().ui.status_error, "{label}: {}", h.state().ui.status);
}

/// A grayscale image's composite is its one channel: Duplicate Channel copies it, as the row
/// menu does; an RGB composite stays greyed.
#[test]
fn panel_menu_duplicates_the_gray_composite() {
    assert!(menu_disabled(&menu_harness(menu_app("rgb")), "Duplicate Channel"), "nothing to duplicate on the RGB composite");
    let mut h = menu_harness(menu_app("grayscale"));
    assert!(!menu_disabled(&h, "Duplicate Channel"));
    menu_click(&mut h, "Duplicate Channel");
    assert_eq!(alpha_names(h.state()), ["Gray copy"]);
}

/// Duplicate Channel copies a targeted Quick Mask or layer mask, as dropping the row on New does
/// (the mask's copy is "<layer> Mask copy").
#[test]
fn panel_menu_duplicates_quick_mask_and_layer_mask() {
    let mut app = menu_app("rgb");
    app.run("select.editInQuickMaskMode", json!({})).unwrap();
    let mut h = menu_harness(app);
    assert!(!menu_disabled(&h, "Duplicate Channel"), "the Quick Mask can be duplicated");
    menu_click(&mut h, "Duplicate Channel");
    assert_eq!(h.state().session.active().unwrap().doc.channels.len(), 1);

    let mut app = menu_app("rgb");
    app.run("layer.new.layer", json!({"name": "Masked"})).unwrap();
    app.run("layer.layerMask.revealAll", json!({})).unwrap();
    app.run("channel.target", json!({"channel": "mask"})).unwrap();
    let mut h = menu_harness(app);
    assert!(!menu_disabled(&h, "Duplicate Channel"), "the layer mask can be duplicated");
    menu_click(&mut h, "Duplicate Channel");
    assert_eq!(alpha_names(h.state()), ["Masked Mask copy"]);
}

/// In Quick Mask mode, Channel Options… on a targeted alpha channel opens that channel's options,
/// from the panel menu and the command palette (`menus::invoke`) alike; with the composite
/// targeted it is Quick Mask's.
#[test]
fn channel_options_in_quick_mask_take_the_targeted_alpha() {
    let mut app = menu_app("rgb");
    app.run("channel.new", json!({"name": "Alpha 1"})).unwrap();
    app.run("select.editInQuickMaskMode", json!({})).unwrap();
    let ctx = egui::Context::default();
    crate::menus::invoke(&mut app, &ctx, "channel.options", json!({})).unwrap();
    assert_eq!(app.ui.dialogs.last().unwrap().fields["channel"], json!("quickMask"), "the composite targeted: Quick Mask Options");
    app.ui.dialogs.clear();
    app.run("channel.target", json!({"channel": 0})).unwrap();
    crate::menus::invoke(&mut app, &ctx, "channel.options", json!({})).unwrap();
    assert_eq!(app.ui.dialogs.last().unwrap().fields["channel"], json!(0), "the dispatcher opens the alpha's options");
    app.ui.dialogs.clear();
    let mut h = menu_harness(app);
    menu_click(&mut h, "Channel Options…");
    assert_eq!(h.state().ui.dialogs.last().unwrap().fields["channel"], json!(0), "so does the panel menu");
}

/// Duplicate Channel waits for one channel: not several colour channels at once. Without a
/// document every item is greyed.
#[test]
fn panel_menu_greys_items_without_one_channel_or_a_document() {
    let mut app = menu_app("rgb");
    app.run("channel.target", json!({"channel": {"color": 0}})).unwrap();
    app.run("channel.target", json!({"channel": {"color": 1}, "extend": true})).unwrap();
    assert_eq!(app.session.active().unwrap().channel_view.selected_colors.len(), 2);
    assert!(menu_disabled(&menu_harness(app), "Duplicate Channel"), "two colour channels are targeted");
    let h = menu_harness(PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default()));
    for label in [
        "New Channel…",
        "Duplicate Channel",
        "Delete Channel",
        "New Spot Channel…",
        "Merge Spot Channel",
        "Channel Options…",
        "Split Channels",
        "Merge Channels…",
    ] {
        assert!(menu_disabled(&h, label), "{label} waits for a document");
    }
}

/// Merge Spot Channel prints the targeted spot channel into the image and removes it: a solid
/// blue ink over the left half turns those pixels blue and leaves the rest white.
#[test]
fn panel_menu_merges_the_targeted_spot_channel() {
    let mut app = menu_app("rgb");
    app.run("channel.new", json!({"name": "Alpha 1"})).unwrap();
    app.run("select.rect", json!({"x": 0, "y": 0, "width": 16, "height": 24})).unwrap();
    app.run("channel.newSpot", json!({"name": "Ink", "color": "#0000ff", "solidity": 100})).unwrap();
    app.run("select.deselect", json!({})).unwrap();
    app.run("channel.target", json!({"channel": 1})).unwrap();
    let pixel = |app: &PhotocraftApp, x: usize, y: usize| {
        let doc = &app.session.active().unwrap().doc;
        let comp = photocraft_compose::render(doc, doc.bounds());
        let p = comp.px[y * doc.size.width as usize + x];
        [p[0], p[1], p[2]].map(|v| (v * 255.0).round() as u8)
    };
    assert_eq!((pixel(&app, 4, 4), pixel(&app, 24, 4)), ([255, 255, 255], [255, 255, 255]), "the ink is not in the image yet");
    let mut h = menu_harness(app);
    menu_click(&mut h, "Merge Spot Channel");
    assert_eq!(alpha_names(h.state()), ["Alpha 1"], "the spot channel is merged, the alpha kept");
    assert_eq!(pixel(h.state(), 4, 4), [0, 0, 255], "the ink is printed where the channel had it");
    assert_eq!(pixel(h.state(), 24, 4), [255, 255, 255], "and nowhere else");
}

/// Merge Channels… asks first, as in Photoshop: the dialog picks the mode and the document for
/// each channel; nothing merges until OK. With params the command runs directly.
#[test]
fn panel_menu_merge_channels_opens_its_dialog() {
    let mut app = menu_app("grayscale");
    for _ in 0..2 {
        app.run("file.new", json!({"width": 32, "height": 24, "mode": "grayscale"})).unwrap();
    }
    let mut h = menu_harness(app);
    menu_click(&mut h, "Merge Channels…");
    assert_eq!(h.state().session.documents().len(), 3, "nothing is merged before OK");
    let d = h.state().ui.dialogs.last().expect("the Merge Channels dialog");
    assert_eq!(d.fields["__label"], json!("Merge Channels…"));
    let id = d.id;
    h.state_mut().ui.dialog_mut(id).unwrap().fields.insert("mode".into(), json!("lab"));
    crate::dialogs::confirm(h.state_mut(), id).unwrap();
    let docs = h.state().session.documents();
    assert_eq!(docs.len(), 1, "the sources close");
    assert_eq!(docs[0].doc.mode, photocraft_doc::ColorMode::Lab, "in the mode picked");

    let ctx = egui::Context::default();
    let mut app = menu_app("grayscale");
    for _ in 0..2 {
        app.run("file.new", json!({"width": 32, "height": 24, "mode": "grayscale"})).unwrap();
    }
    let r = crate::menus::invoke(&mut app, &ctx, "channel.merge", json!({})).unwrap();
    assert!(r["dialog"].is_u64() && app.session.documents().len() == 3, "the dispatcher asks too");
    app.ui.dialogs.clear();
    crate::menus::invoke(&mut app, &ctx, "channel.merge", json!({"mode": "rgb"})).unwrap();
    assert!(app.ui.dialogs.is_empty() && app.session.documents().len() == 1, "explicit params merge directly");
}

/// Two grayscale documents fill no mode: Merge Channels… is greyed in the panel menu, and the
/// dispatcher says why instead of opening the dialog; a third one enables it.
#[test]
fn merge_channels_waits_for_three_grayscale_documents() {
    let mut app = menu_app("grayscale");
    app.run("file.new", json!({"width": 32, "height": 24, "mode": "grayscale"})).unwrap();
    let ctx = egui::Context::default();
    let why = crate::menus::invoke(&mut app, &ctx, "channel.merge", json!({})).unwrap_err();
    assert!(why.contains("three") && app.ui.dialogs.is_empty(), "{why}");
    let mut h = menu_harness(app);
    assert!(menu_disabled(&h, "Merge Channels…"), "two documents are not enough");
    h.state_mut().run("file.new", json!({"width": 32, "height": 24, "mode": "grayscale"})).unwrap();
    h.run_steps(2);
    assert!(!menu_disabled(&h, "Merge Channels…"), "three are");
}
