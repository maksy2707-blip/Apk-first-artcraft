//! The phone layout (Android shell, [`Services::safe_insets`](crate::Services)).
//!
//! The desktop UI assumes a wide window and draws to the window's edges. On a phone that means
//! the status bar and the camera cutout sit on top of the menu bar, the menu titles run off the
//! screen, and the dock leaves no room for the canvas in portrait. This module holds the pieces
//! that adapt it:
//!
//! - [`apply_insets`] / [`begin`]: the system insets become egui's safe area, so everything that
//!   follows `content_rect` stays clear of them, and the layout class is recorded each pass;
//! - [`AUTO_ZOOM`]: the interface scale used for Preferences › Interface › UI Scale = Auto;
//! - [`compact`]: the menu bar collapses into one button (see `menus::bar`);
//! - [`dock_allowed`] / [`dock_toggle`]: on a narrow screen the dock is a panel the user opens.

use crate::PhotocraftApp;

/// The interface scale on a phone, relative to the system's density: Android reports 2.5 to 3.5
/// pixels per point, which makes desktop-sized controls (14 pt text, 28 pt buttons) fill the
/// screen. 0.8 keeps text at about 11 dp and leaves a landscape phone more than 1000 points.
pub(crate) const AUTO_ZOOM: f32 = 0.8;

/// Below this width (points) the menu titles do not fit in one row.
const COMPACT_BELOW: f32 = 1300.0;

/// Below this width (points) the dock and the canvas do not fit side by side (a phone in portrait).
const NARROW_BELOW: f32 = 760.0;

#[derive(Clone, Copy)]
struct Layout {
    compact: bool,
    narrow: bool,
}

fn layout_id() -> egui::Id {
    egui::Id::new("phone-layout")
}

fn insets_id() -> egui::Id {
    egui::Id::new("phone-insets")
}

fn dock_open_id() -> egui::Id {
    egui::Id::new("phone-dock-open")
}

fn layout(ctx: &egui::Context) -> Option<Layout> {
    ctx.data(|d| d.get_temp::<Layout>(layout_id()))
}

/// Whether the menu titles collapse into one menu button (phone shell, screen too narrow for the row).
pub(crate) fn compact(ctx: &egui::Context) -> bool {
    layout(ctx).is_some_and(|l| l.compact)
}

/// Whether the screen is too narrow for the dock beside the canvas (phone shell in portrait).
pub(crate) fn narrow(ctx: &egui::Context) -> bool {
    layout(ctx).is_some_and(|l| l.narrow)
}

/// Whether the frame may draw the dock: always, except on a narrow phone screen where the user
/// has not opened it with [`dock_toggle`].
pub(crate) fn dock_allowed(ctx: &egui::Context) -> bool {
    !narrow(ctx) || ctx.data(|d| d.get_temp::<bool>(dock_open_id())).unwrap_or(false)
}

/// Hands the system insets to egui as the screen's safe area, before the pass: `content_rect`
/// shrinks by them, so the panels, the floating windows and the dialogs all stay clear of the
/// status bar, the cutout, the navigation bar and the keyboard.
pub(crate) fn apply_insets(app: &mut PhotocraftApp, ctx: &egui::Context, raw_input: &mut egui::RawInput) {
    let Some(read) = app.services.safe_insets.as_mut() else { return };
    let ppp = ctx.pixels_per_point().max(0.1);
    let [left, top, right, bottom] = read();
    let points = |px: f32| if px.is_finite() { (px.max(0.0) / ppp).min(600.0) } else { 0.0 };
    let pt = [points(left), points(top), points(right), points(bottom)];
    let mut insets = raw_input.safe_area_insets.unwrap_or_default();
    insets.0.left = pt[0];
    insets.0.top = pt[1];
    insets.0.right = pt[2];
    insets.0.bottom = pt[3];
    raw_input.safe_area_insets = Some(insets);
    ctx.data_mut(|d| d.insert_temp(insets_id(), pt));
}

/// The insets of this frame, in points: `[left, top, right, bottom]`.
pub(crate) fn insets(ctx: &egui::Context) -> [f32; 4] {
    ctx.data(|d| d.get_temp::<[f32; 4]>(insets_id())).unwrap_or([0.0; 4])
}

/// Records this pass's layout class. Returns the part of the screen the UI may use (the content
/// rectangle, which excludes the insets), or `None` outside the phone shell.
pub(crate) fn begin(app: &PhotocraftApp, ctx: &egui::Context) -> Option<egui::Rect> {
    app.services.safe_insets.as_ref()?;
    let rect = ctx.content_rect();
    ctx.data_mut(|d| d.insert_temp(layout_id(), Layout { compact: rect.width() < COMPACT_BELOW, narrow: rect.width() < NARROW_BELOW }));
    Some(rect)
}

/// A button over the canvas that opens and closes the dock on a narrow phone screen, where the
/// dock does not fit beside the canvas by default. Nothing is drawn elsewhere.
pub(crate) fn dock_toggle(ctx: &egui::Context) {
    if !narrow(ctx) {
        return;
    }
    let open = ctx.data(|d| d.get_temp::<bool>(dock_open_id())).unwrap_or(false);
    let content = ctx.content_rect();
    let mut toggled = false;
    egui::Area::new(egui::Id::new("phone-dock-toggle"))
        .order(egui::Order::Foreground)
        .fixed_pos(egui::pos2(content.right() - 12.0 - 36.0, content.bottom() - 44.0 - 36.0))
        .show(ctx, |ui| {
            toggled = crate::icons::button(ui, "panel-right", 36.0, open, tl!("Layers")).clicked();
        });
    if toggled {
        ctx.data_mut(|d| d.insert_temp(dock_open_id(), !open));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Everything but the Android shell keeps the desktop layout: no insets, the full menu row and the dock.
    #[test]
    fn desktop_keeps_its_layout() {
        let ctx = egui::Context::default();
        let app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
        assert!(begin(&app, &ctx).is_none());
        assert!(!compact(&ctx));
        assert!(!narrow(&ctx));
        assert!(dock_allowed(&ctx));
    }
}
