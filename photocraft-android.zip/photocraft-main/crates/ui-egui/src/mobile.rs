//! The phone layout (Android shell, [`Services::safe_insets`](crate::Services)).
//!
//! The desktop UI assumes a wide window and draws to the window's edges. On a phone that means
//! the status bar and the camera cutout sit on top of the menu bar, the menu titles run off the
//! screen, and the dock leaves no room for the canvas in portrait. This module holds the pieces
//! that adapt it:
//!
//! - [`begin`]: reads the system insets once per UI pass and records the layout class;
//! - [`AUTO_ZOOM`]: the interface scale used for Preferences › Interface › UI Scale = Auto;
//! - [`compact`]: the menu bar collapses into one button (see `menus::bar`);
//! - [`dock_allowed`] / [`dock_toggle`]: on a narrow screen the dock is a panel the user opens.

use crate::PhotocraftApp;

/// The interface scale on a phone, relative to the system's density: Android reports 2.5 to 3.5
/// pixels per point, which makes desktop-sized controls (14 pt text, 28 pt buttons) fill the
/// screen. 0.8 keeps text at about 11 dp and leaves a landscape phone more than 1000 points.
pub(crate) const AUTO_ZOOM: f32 = 0.8;

/// Below this width (points) the menu titles do not fit in one row.
const COMPACT_BELOW: f32 = 1300.0;

/// Below this width (points) the dock and the canvas do not fit side by side (a phone in portrait).
const NARROW_BELOW: f32 = 760.0;

#[derive(Clone, Copy)]
struct Layout {
    compact: bool,
    narrow: bool,
    /// The room the system takes at the right and at the bottom, in points.
    inset_right: f32,
    inset_bottom: f32,
}

fn layout_id() -> egui::Id {
    egui::Id::new("phone-layout")
}

fn dock_open_id() -> egui::Id {
    egui::Id::new("phone-dock-open")
}

fn layout(ctx: &egui::Context) -> Option<Layout> {
    ctx.data(|d| d.get_temp::<Layout>(layout_id()))
}

/// Whether the menu titles collapse into one menu button (phone shell, screen too narrow for the row).
pub(crate) fn compact(ctx: &egui::Context) -> bool {
    layout(ctx).is_some_and(|l| l.compact)
}

/// Whether the screen is too narrow for the dock beside the canvas (phone shell in portrait).
pub(crate) fn narrow(ctx: &egui::Context) -> bool {
    layout(ctx).is_some_and(|l| l.narrow)
}

/// Whether the frame may draw the dock: always, except on a narrow phone screen where the user
/// has not opened it with [`dock_toggle`].
pub(crate) fn dock_allowed(ctx: &egui::Context) -> bool {
    !narrow(ctx) || ctx.data(|d| d.get_temp::<bool>(dock_open_id())).unwrap_or(false)
}

/// Reads the system insets and records this pass's layout class. Returns the part of the screen
/// the UI may use, or `None` outside the phone shell.
pub(crate) fn begin(app: &mut PhotocraftApp, ctx: &egui::Context) -> Option<egui::Rect> {
    let read = app.services.safe_insets.as_mut()?;
    let screen = ctx.content_rect();
    let ppp = ctx.pixels_per_point().max(0.1);
    let [left, top, right, bottom] = read();
    let points = |px: f32| if px.is_finite() { (px.max(0.0) / ppp).min(160.0) } else { 0.0 };
    let (left, top, right, bottom) = (points(left), points(top), points(right), points(bottom));
    let mut rect = egui::Rect::from_min_max(egui::pos2(screen.left() + left, screen.top() + top), egui::pos2(screen.right() - right, screen.bottom() - bottom));
    // Never lay the UI out in a sliver (a keyboard taller than the screen, odd insets).
    if rect.width() < 200.0 || rect.height() < 200.0 {
        rect = screen;
    }
    let layout = Layout { compact: rect.width() < COMPACT_BELOW, narrow: rect.width() < NARROW_BELOW, inset_right: screen.right() - rect.right(), inset_bottom: screen.bottom() - rect.bottom() };
    ctx.data_mut(|d| d.insert_temp(layout_id(), layout));
    Some(rect)
}

/// A button over the canvas that opens and closes the dock on a narrow phone screen, where the
/// dock does not fit beside the canvas by default. Nothing is drawn elsewhere.
pub(crate) fn dock_toggle(ctx: &egui::Context) {
    let Some(layout) = layout(ctx).filter(|l| l.narrow) else { return };
    let open = ctx.data(|d| d.get_temp::<bool>(dock_open_id())).unwrap_or(false);
    let mut toggled = false;
    egui::Area::new(egui::Id::new("phone-dock-toggle"))
        .order(egui::Order::Foreground)
        .anchor(egui::Align2::RIGHT_BOTTOM, egui::vec2(-(layout.inset_right + 12.0), -(layout.inset_bottom + 44.0)))
        .show(ctx, |ui| {
            toggled = crate::icons::button(ui, "panel-right", 36.0, open, tl!("Layers")).clicked();
        });
    if toggled {
        ctx.data_mut(|d| d.insert_temp(dock_open_id(), !open));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Everything but the Android shell keeps the desktop layout: no insets, the full menu row and the dock.
    #[test]
    fn desktop_keeps_its_layout() {
        let ctx = egui::Context::default();
        let mut app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
        assert!(begin(&mut app, &ctx).is_none());
        assert!(!compact(&ctx));
        assert!(!narrow(&ctx));
        assert!(dock_allowed(&ctx));
    }
}
