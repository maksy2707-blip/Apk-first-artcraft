//! The phone layout (Android shell, [`Services::safe_insets`](crate::Services)).
//!
//! The desktop UI assumes a wide window and draws to the window's edges. On a phone that means
//! the status bar and the camera cutout sit on top of the menu bar, the menu titles run off the
//! screen, and the dock leaves no room for the canvas in portrait. This module holds the pieces
//! that adapt it:
//!
//! - [`apply_insets`] / [`begin`]: the system insets become egui's safe area, so everything that
//!   follows `content_rect` stays clear of them, and the layout class is recorded each pass;
//! - [`AUTO_ZOOM`]: the interface scale used for Preferences › Interface › UI Scale = Auto;
//! - [`compact`]: the menu bar collapses into one menu button (see `menus::bar`);
//! - [`dock_allowed`] / [`dock_toggle`]: on a narrow screen the dock is a panel the user opens.
//! - Compact on-screen hotkey strip (vertical, right edge) and a clear way out of Full Screen Mode.

use crate::PhotocraftApp;

/// The interface scale on a phone, relative to the system's density: Android reports 2.5 to 3.5
/// pixels per point, which makes desktop-sized controls (14 pt text, 28 pt buttons) fill the
/// screen. 0.8 keeps text at about 11 dp and leaves a landscape phone more than 1000 points.
pub(crate) const AUTO_ZOOM: f32 = 0.8;

/// Below this width (points) the menu titles do not fit in one row.
const COMPACT_BELOW: f32 = 1300.0;

/// Below this width (points) the dock and the canvas do not fit side by side (a phone in portrait).
const NARROW_BELOW: f32 = 760.0;

/// Small touch target for the side strip (still usable, does not eat the canvas).
const BTN: f32 = 36.0;

#[derive(Clone, Copy)]
struct Layout {
    compact: bool,
    narrow: bool,
}

fn layout_id() -> egui::Id {
    egui::Id::new("phone-layout")
}

fn insets_id() -> egui::Id {
    egui::Id::new("phone-insets")
}

fn dock_open_id() -> egui::Id {
    egui::Id::new("phone-dock-open")
}

fn layout(ctx: &egui::Context) -> Option<Layout> {
    ctx.data(|d| d.get_temp::<Layout>(layout_id()))
}

/// Whether the phone / Android shell layout is active this frame.
pub(crate) fn layout_active(ctx: &egui::Context) -> bool {
    layout(ctx).is_some()
}

/// Whether the menu titles collapse into one menu button (phone shell, screen too narrow for the row).
pub(crate) fn compact(ctx: &egui::Context) -> bool {
    layout(ctx).is_some_and(|l| l.compact)
}

/// Whether the screen is too narrow for the dock beside the canvas (phone shell in portrait).
pub(crate) fn narrow(ctx: &egui::Context) -> bool {
    layout(ctx).is_some_and(|l| l.narrow)
}

/// Whether the frame may draw the dock: always, except on a narrow phone screen where the user
/// has not opened it with [`dock_toggle`].
pub(crate) fn dock_allowed(ctx: &egui::Context) -> bool {
    !narrow(ctx) || ctx.data(|d| d.get_temp::<bool>(dock_open_id())).unwrap_or(false)
}

/// Minimum content height kept when the soft keyboard is open (points).
/// Below this, egui layouts and text fields can panic or freeze on a zero-height rect.
const MIN_CONTENT_H: f32 = 120.0;

/// Hands the system insets to egui as the screen's safe area, before the pass: `content_rect`
/// shrinks by them, so the panels, the floating windows and the dialogs all stay clear of the
/// status bar, the cutout, the navigation bar and the keyboard.
///
/// When the full IME opens, the bottom inset can exceed half the screen. We clamp so the content
/// area never collapses (that used to crash the app). Combined with `adjustNothing` in the
/// Android manifest, the surface is not resized twice.
pub(crate) fn apply_insets(app: &mut PhotocraftApp, ctx: &egui::Context, raw_input: &mut egui::RawInput) {
    let Some(read) = app.services.safe_insets.as_mut() else { return };
    // The Back button is the phone's Esc: leaves Full Screen Mode, cancels dialogs, closes menus.
    if app.services.back_pressed.as_mut().is_some_and(|back| back()) {
        for pressed in [true, false] {
            raw_input.events.push(egui::Event::Key {
                key: egui::Key::Escape,
                physical_key: Some(egui::Key::Escape),
                pressed,
                repeat: false,
                modifiers: egui::Modifiers::NONE,
            });
        }
        ctx.request_repaint();
    }
    let ppp = ctx.pixels_per_point().max(0.1);
    let [left, top, right, bottom] = read();
    // Hard per-side cap (points). Keyboard height is handled relative to the screen below.
    let points = |px: f32| {
        if px.is_finite() {
            (px.max(0.0) / ppp).min(480.0)
        } else {
            0.0
        }
    };
    let mut pt = [points(left), points(top), points(right), points(bottom)];

    // Keep a usable content area when the keyboard is up (zero-height rects crash layouts).
    let (screen_w, screen_h) = raw_input
        .screen_rect
        .map(|r| (r.width(), r.height()))
        .filter(|(w, h)| w.is_finite() && h.is_finite() && *w > 1.0 && *h > 1.0)
        .unwrap_or((360.0, 640.0));
    let max_v = (screen_h - MIN_CONTENT_H).max(0.0);
    if pt[1] + pt[3] > max_v {
        // Prefer shrinking the bottom (IME) so the menu bar at the top stays visible.
        let overflow = pt[1] + pt[3] - max_v;
        pt[3] = (pt[3] - overflow).max(0.0);
        if pt[1] + pt[3] > max_v {
            pt[1] = (max_v - pt[3]).max(0.0);
        }
    }
    let max_h = (screen_w - 80.0).max(0.0);
    if pt[0] + pt[2] > max_h {
        let overflow = pt[0] + pt[2] - max_h;
        pt[2] = (pt[2] - overflow).max(0.0);
        if pt[0] + pt[2] > max_h {
            pt[0] = (max_h - pt[2]).max(0.0);
        }
    }

    let mut insets = raw_input.safe_area_insets.unwrap_or_default();
    insets.0.left = pt[0];
    insets.0.top = pt[1];
    insets.0.right = pt[2];
    insets.0.bottom = pt[3];
    raw_input.safe_area_insets = Some(insets);
    ctx.data_mut(|d| d.insert_temp(insets_id(), pt));
}

/// The insets of this frame, in points: `[left, top, right, bottom]`.
pub(crate) fn insets(ctx: &egui::Context) -> [f32; 4] {
    ctx.data(|d| d.get_temp::<[f32; 4]>(insets_id())).unwrap_or([0.0; 4])
}

/// Records this pass's layout class. Returns the part of the screen the UI may use (the content
/// rectangle, which excludes the insets), or `None` outside the phone shell.
pub(crate) fn begin(app: &PhotocraftApp, ctx: &egui::Context) -> Option<egui::Rect> {
    app.services.safe_insets.as_ref()?;
    let mut rect = ctx.content_rect();
    // Guard against a collapsed content rect (keyboard + bad insets).
    if !rect.is_finite() || rect.width() < 32.0 || rect.height() < 32.0 {
        let screen = ctx.input(|i| i.viewport_rect());
        if screen.is_finite() && screen.width() > 32.0 && screen.height() > 32.0 {
            rect = egui::Rect::from_min_size(
                screen.min + egui::vec2(0.0, 24.0),
                egui::vec2(screen.width(), (screen.height() - 24.0).max(32.0)),
            );
        } else {
            return None;
        }
    }
    ctx.data_mut(|d| {
        d.insert_temp(
            layout_id(),
            Layout {
                compact: rect.width() < COMPACT_BELOW,
                narrow: rect.width() < NARROW_BELOW,
            },
        )
    });
    Some(rect)
}

/// A button over the canvas that opens and closes the dock on a narrow phone screen, where the
/// dock does not fit beside the canvas by default. Nothing is drawn elsewhere.
pub(crate) fn dock_toggle(ctx: &egui::Context) {
    if !narrow(ctx) {
        return;
    }
    let open = ctx.data(|d| d.get_temp::<bool>(dock_open_id())).unwrap_or(false);
    let content = ctx.content_rect();
    let mut toggled = false;
    // Keep it small and out of the way, bottom-right.
    egui::Area::new(egui::Id::new("phone-dock-toggle"))
        .order(egui::Order::Foreground)
        .fixed_pos(egui::pos2(content.right() - 8.0 - BTN, content.bottom() - 8.0 - BTN))
        .show(ctx, |ui| {
            toggled = crate::icons::button(ui, "panel-right", BTN, open, tl!("Layers")).clicked();
        });
    if toggled {
        ctx.data_mut(|d| d.insert_temp(dock_open_id(), !open));
    }
}

/// Compact vertical hotkey strip + Full Screen exit controls.
///
/// The strip sits on the **right edge** and is deliberately small so it does not cover half the
/// canvas. Full Screen Mode always has a clear Exit control (and system Back also works).
pub(crate) fn overlay(app: &mut PhotocraftApp, ctx: &egui::Context, chrome: bool, home: bool) {
    if layout(ctx).is_none() {
        return;
    }
    let content = ctx.content_rect();
    let mut command: Option<&'static str> = None;

    if app.ui.view.screen_mode != "standard" {
        // ── Full Screen / "вид на фото" ──────────────────────────────────────────
        // Small top-right exit pair + one compact bottom Exit button.
        let panels_shown = app.ui.panels.full_screen_chrome;
        let bar_w = BTN * 2.0 + 12.0;
        egui::Area::new(egui::Id::new("phone-fullscreen-exit"))
            .order(egui::Order::Foreground)
            .fixed_pos(egui::pos2(content.right() - 8.0 - bar_w, content.top() + 8.0))
            .show(ctx, |ui| {
                egui::Frame::NONE
                    .fill(egui::Color32::from_black_alpha(190))
                    .corner_radius(6.0)
                    .inner_margin(egui::Margin::same(4))
                    .show(ui, |ui| {
                        ui.horizontal(|ui| {
                            if crate::icons::button(ui, "panels-top-left", BTN, panels_shown, "").clicked() {
                                command = Some("window.togglePanels");
                            }
                            if crate::icons::button(ui, "x", BTN, false, "").clicked() {
                                command = Some("view.screenMode.standard");
                            }
                        });
                    });
            });

        // Compact Exit at the bottom centre (does not stretch across the screen).
        egui::Area::new(egui::Id::new("phone-fullscreen-exit-label"))
            .order(egui::Order::Foreground)
            .fixed_pos(egui::pos2(content.center().x - 48.0, content.bottom() - 8.0 - 36.0))
            .show(ctx, |ui| {
                egui::Frame::NONE
                    .fill(egui::Color32::from_black_alpha(190))
                    .corner_radius(8.0)
                    .inner_margin(egui::Margin::symmetric(12, 6))
                    .show(ui, |ui| {
                        if ui
                            .add(
                                egui::Button::new(
                                    egui::RichText::new("✕ Exit")
                                        .size(15.0)
                                        .color(egui::Color32::WHITE),
                                )
                                .min_size(egui::vec2(96.0, 32.0))
                                .fill(egui::Color32::from_rgb(180, 40, 40)),
                            )
                            .clicked()
                        {
                            command = Some("view.screenMode.standard");
                        }
                    });
            });
    } else if chrome && !home && app.session.active().is_some() {
        // ── Normal editor: small vertical strip, draggable ───────────────────────
        // Default: right edge, vertically centred. Drag the top grip to move it.
        let t = crate::theme::Tokens::get(ctx);
        let strip_w = BTN + 8.0;
        let strip_h = 18.0 + BTN * 5.0 + 4.0 * 4.0 + 8.0; // grip + 5 buttons + gaps + pad
        let default_pos = egui::pos2(
            content.right() - 8.0 - strip_w,
            (content.center().y - strip_h / 2.0).max(content.top() + 8.0),
        );

        let pos_id = egui::Id::new("phone-quick-keys-pos");
        let mut pos: egui::Pos2 = ctx.data(|d| d.get_temp(pos_id)).unwrap_or(default_pos);
        pos.x = pos.x.clamp(content.left() + 4.0, content.right() - strip_w - 4.0);
        pos.y = pos.y.clamp(content.top() + 4.0, content.bottom() - strip_h - 4.0);

        egui::Area::new(egui::Id::new("phone-quick-keys"))
            .order(egui::Order::Foreground)
            .fixed_pos(pos)
            .show(ctx, |ui| {
                egui::Frame::NONE
                    .fill(t.chrome.gamma_multiply(0.92))
                    .corner_radius(8.0)
                    .inner_margin(egui::Margin::same(4))
                    .show(ui, |ui| {
                        ui.vertical(|ui| {
                            ui.spacing_mut().item_spacing.y = 4.0;

                            // Drag grip at the top
                            let grip = ui.allocate_response(
                                egui::vec2(BTN, 14.0),
                                egui::Sense::click_and_drag(),
                            );
                            let grip_rect = grip.rect;
                            let painter = ui.painter();
                            let col = if grip.hovered() || grip.dragged() {
                                egui::Color32::from_white_alpha(180)
                            } else {
                                egui::Color32::from_white_alpha(100)
                            };
                            for i in 0..3 {
                                let y = grip_rect.center().y - 3.0 + i as f32 * 3.0;
                                painter.hline(
                                    grip_rect.x_range().shrink(6.0),
                                    y,
                                    egui::Stroke::new(1.5, col),
                                );
                            }
                            if grip.dragged() {
                                let delta = ui.ctx().input(|i| i.pointer.delta());
                                ui.ctx().data_mut(|d| {
                                    let p: egui::Pos2 = d.get_temp(pos_id).unwrap_or(default_pos);
                                    d.insert_temp(pos_id, p + delta);
                                });
                            }

                            if crate::icons::button(ui, "undo-2", BTN, false, "").clicked() {
                                command = Some("edit.undo");
                            }
                            if crate::icons::button(ui, "redo-2", BTN, false, "").clicked() {
                                command = Some("edit.redo");
                            }
                            if crate::icons::button(ui, "panels-top-left", BTN, false, "").clicked() {
                                command = Some("window.togglePanels");
                            }
                            if crate::icons::button(ui, "maximize-2", BTN, false, "").clicked() {
                                command = Some("view.fitOnScreen");
                            }
                            if crate::icons::button(ui, "monitor", BTN, false, "").clicked() {
                                command = Some("view.screenMode.fullScreen");
                            }
                        });
                    });
            });

        // Clamp after a drag so the strip never leaves the safe area.
        if let Some(p) = ctx.data(|d| d.get_temp::<egui::Pos2>(pos_id)) {
            let clamped = egui::pos2(
                p.x.clamp(content.left() + 4.0, content.right() - strip_w - 4.0),
                p.y.clamp(content.top() + 4.0, content.bottom() - strip_h - 4.0),
            );
            if clamped != p {
                ctx.data_mut(|d| d.insert_temp(pos_id, clamped));
            }
        }
    }

    if let Some(id) = command {
        if let Err(e) = crate::menus::invoke(app, ctx, id, serde_json::json!({})) {
            app.ui.status = e;
            app.ui.status_error = true;
        }
    }

    if chrome && !home && app.ui.panels.dock {
        dock_toggle(ctx);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Everything but the Android shell keeps the desktop layout: no insets, the full menu row and the dock.
    #[test]
    fn desktop_keeps_its_layout() {
        let ctx = egui::Context::default();
        let app = PhotocraftApp::new(photocraft_engine::Session::new(), crate::Services::default());
        assert!(begin(&app, &ctx).is_none());
        assert!(!compact(&ctx));
        assert!(!narrow(&ctx));
        assert!(dock_allowed(&ctx));
    }
}
