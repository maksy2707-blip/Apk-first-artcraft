//! The crate's integration tests, linked into one test binary.

mod agent_tasks;
mod agent_tasks_extended;
mod agent_tasks_more;
mod bridge;
mod gpu_backend;
mod inactive_save;
mod krita;
mod layered_save_dirty;
mod mcp;
mod mcp_wire;
mod missing_font_warnings;
mod native_full_composite;
mod native_save_name;
mod openraster;
mod raw_defaults;
mod renderer_save;
mod smart_filter_authorization;
