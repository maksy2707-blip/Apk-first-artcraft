//! PhotoCraft for Android.
//!
//! Runs the same [`photocraft_ui_egui::PhotocraftApp`] as the desktop and web builds through
//! eframe's Android (native-activity) backend. The Rust side is a `cdylib` loaded by
//! `MainActivity` (Kotlin, `android/`), which is a `NativeActivity` subclass that adds what
//! native code cannot do alone:
//!
//! - **Open**: `MainActivity.openDocument()` shows the system file picker (Storage Access
//!   Framework) and copies the chosen files into `<files dir>/inbox/`; a watcher thread here
//!   picks them up and hands them to the app (or to a File › Open dialog that is waiting).
//! - **Save / Export**: bytes are written to `<files dir>/exports/` and `MainActivity.saveFile()`
//!   publishes the file into the device's Downloads folder (MediaStore, no permission needed).
//! - Files shared to the app from other apps (VIEW / SEND intents) use the same inbox.
//!
//! Known limits of this first port: no pen pressure feed, no clipboard images, no print, no
//! update check, no control server. The UI runs in a phone layout (`photocraft_ui_egui::mobile`:
//! scaled down, clear of the system bars, one menu button, the dock opened from a button on a narrow
//! screen); touch gestures on the canvas are not reworked yet.

#![cfg(target_os = "android")]
#![allow(unsafe_code)]

use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, OnceLock, PoisonError};
use std::time::Duration;

use android_activity::AndroidApp;
use jni::JavaVM;
use jni::objects::{JObject, JValue};
use photocraft_doc::Document;
use photocraft_engine::Session;
use photocraft_ui_egui::{ExportSettings, FileDialogAnswer, FileDialogReply, FileDialogRequest, Inbox, PhotocraftApp, Services};

/// The JavaVM and the Activity, as raw addresses (they are plain pointers owned by Android).
static JNI_HANDLES: OnceLock<(usize, usize)> = OnceLock::new();

/// A File › Open dialog that is waiting for the system picker to deliver its files.
type PendingOpen = Arc<Mutex<Option<FileDialogReply>>>;

fn lock<T>(m: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    m.lock().unwrap_or_else(PoisonError::into_inner)
}

/// Run `f` with the JNI environment of this thread and the `MainActivity` object.
fn with_activity<R>(f: impl FnOnce(&mut jni::JNIEnv, &JObject) -> Result<R, String>) -> Result<R, String> {
    let &(vm_addr, activity_addr) = JNI_HANDLES.get().ok_or("the Activity is not known yet")?;
    // SAFETY: both pointers come from android-activity (`vm_as_ptr` / `activity_as_ptr`) and stay
    // valid for the life of the process; `JObject` does not delete the activity reference.
    let vm = unsafe { JavaVM::from_raw(vm_addr as *mut jni::sys::JavaVM) }.map_err(|e| e.to_string())?;
    let mut env = vm.attach_current_thread().map_err(|e| e.to_string())?;
    let activity = unsafe { JObject::from_raw(activity_addr as jni::sys::jobject) };
    let result = f(&mut env, &activity);
    if env.exception_check().unwrap_or(false) {
        let _ = env.exception_clear();
    }
    result
}

/// `MainActivity.openDocument(multiple)`: the system file picker.
fn open_picker(multiple: bool) -> Result<(), String> {
    with_activity(|env, activity| {
        env.call_method(activity, "openDocument", "(Z)V", &[JValue::Bool(u8::from(multiple))]).map(|_| ()).map_err(|e| format!("openDocument: {e}"))
    })
}

/// `MainActivity.saveFile(path)`: publish a file from the private exports folder to Downloads.
fn publish_file(path: &Path) -> Result<(), String> {
    with_activity(|env, activity| {
        let path = env.new_string(path.to_string_lossy()).map_err(|e| e.to_string())?;
        env.call_method(activity, "saveFile", "(Ljava/lang/String;)V", &[JValue::Object(&path)]).map(|_| ()).map_err(|e| format!("saveFile: {e}"))
    })
}

/// `MainActivity.getSafeInsets()`: system bars, cutout and keyboard, `[left, top, right, bottom]` in pixels.
fn safe_insets() -> [f32; 4] {
    with_activity(|env, activity| {
        let array = env.call_method(activity, "getSafeInsets", "()[I", &[]).and_then(|v| v.l()).map_err(|e| format!("getSafeInsets: {e}"))?;
        let array = jni::objects::JIntArray::from(array);
        let mut px = [0i32; 4];
        env.get_int_array_region(&array, 0, &mut px).map_err(|e| e.to_string())?;
        Ok(px.map(|v| v.max(0) as f32))
    })
    .unwrap_or([0.0; 4])
}

/// Set by the watcher thread when the Activity reports a Back press; read by the UI as Esc.
static BACK_PRESSED: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// `MainActivity.consumeBack()`: whether Back was pressed since the last call.
fn consume_back() -> bool {
    with_activity(|env, activity| env.call_method(activity, "consumeBack", "()Z", &[]).and_then(|v| v.z()).map_err(|e| format!("consumeBack: {e}"))).unwrap_or(false)
}

/// Text file helpers for the preferences (kept in the app's private files dir).
fn load_text(path: PathBuf) -> impl FnMut() -> Option<String> {
    move || std::fs::read_to_string(&path).ok()
}

fn save_text(path: PathBuf) -> impl FnMut(&str) -> Result<(), String> {
    move |text| {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        std::fs::write(&path, text).map_err(|e| e.to_string())
    }
}

/// Watches `<files dir>/inbox/` for files the Activity copied out of the picker or a share
/// intent. A waiting File › Open dialog gets them first; otherwise they open as new documents.
fn watch_inbox(dir: PathBuf, inbox: Inbox, pending: PendingOpen, ctx: egui::Context) {
    let _ = std::fs::create_dir_all(&dir);
    std::thread::spawn(move || {
        loop {
            std::thread::sleep(Duration::from_millis(300));
            if consume_back() {
                BACK_PRESSED.store(true, std::sync::atomic::Ordering::Release);
                ctx.request_repaint();
            }
            let Ok(entries) = std::fs::read_dir(&dir) else { continue };
            let mut ready: Vec<PathBuf> = entries
                .filter_map(Result::ok)
                .map(|e| e.path())
                // The Activity writes `name.part` and renames to `name` when the copy is complete.
                .filter(|p| p.is_file() && p.extension().is_none_or(|e| e != "part"))
                .collect();
            ready.sort();
            let mut files: Vec<(String, Vec<u8>)> = Vec::new();
            let mut cancelled = false;
            for path in ready {
                let file_name = path.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
                // An empty marker the Activity leaves when the picker was cancelled or failed.
                if file_name == "!cancelled" {
                    cancelled = true;
                } else if let Ok(bytes) = std::fs::read(&path) {
                    // Files arrive as `<n>_<original name>`.
                    let name = file_name.split_once('_').map_or(file_name.clone(), |(_, rest)| rest.to_owned());
                    files.push((name, bytes));
                }
                let _ = std::fs::remove_file(&path);
            }
            if files.is_empty() {
                if cancelled && let Some(reply) = lock(&pending).take() {
                    reply.send(None);
                }
                continue;
            }
            if let Some(reply) = lock(&pending).take() {
                reply.send(Some(FileDialogAnswer::ContentsMany(files)));
            } else {
                lock(&inbox).extend(files);
                ctx.request_repaint();
            }
        }
    });
}

fn services(data_dir: &Path, inbox: Inbox, pending: PendingOpen) -> Services {
    let exports = data_dir.join("exports");
    Services {
        import: Some(Box::new(|name: &str, bytes: &[u8], opts: &photocraft_io::ImportOptions| {
            photocraft_io::import_with_options(name, bytes, opts).map(|r| (r.document, r.warnings)).map_err(|e| e.to_string())
        })),
        export: Some(Box::new(|doc: &Document, path: &str, settings: &ExportSettings| {
            photocraft_io::export(doc, path, &settings.io_options()).map(|r| (r.bytes, r.warnings)).map_err(|e| e.to_string())
        })),
        file_dialog: Some(Box::new(move |request, _frame, reply| match request {
            FileDialogRequest::Open { multiple, .. } => {
                // Answered by `watch_inbox` once the system picker has delivered the files.
                match open_picker(multiple) {
                    Ok(()) => *lock(&pending) = Some(reply),
                    Err(e) => reply.send(Some(FileDialogAnswer::Unavailable(format!("Cannot open the file picker: {e}")))),
                }
            }
            // Folders cannot be used as plain paths on Android.
            FileDialogRequest::Folder { .. } => reply.send(None),
            // No save dialog: the suggested name is used, and `write` publishes the file to Downloads.
            FileDialogRequest::Save { suggested } => {
                let name = Path::new(&suggested).file_name().map_or_else(|| suggested.clone(), |n| n.to_string_lossy().into_owned());
                reply.send(Some(FileDialogAnswer::SaveTo(name)));
            }
        })),
        write: Some(Box::new(move |path: &str, bytes: &[u8]| {
            let name = Path::new(path).file_name().map_or_else(|| path.to_owned(), |n| n.to_string_lossy().into_owned());
            std::fs::create_dir_all(&exports).map_err(|e| e.to_string())?;
            let target = exports.join(&name);
            std::fs::write(&target, bytes).map_err(|e| e.to_string())?;
            publish_file(&target)
        })),
        load_prefs: Some(Box::new(load_text(data_dir.join("prefs.json")))),
        save_prefs: Some(Box::new(save_text(data_dir.join("prefs.json")))),
        inbox: Some(inbox),
        // Switches the UI to its phone layout and keeps it clear of the system bars.
        safe_insets: Some(Box::new(safe_insets)),
        // Back is Esc: leaves Full Screen Mode, cancels, closes dialogs.
        back_pressed: Some(Box::new(|| BACK_PRESSED.swap(false, std::sync::atomic::Ordering::AcqRel))),
        ..Services::default()
    }
}

#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_max_level(log::LevelFilter::Info).with_tag("PhotoCraft"));
    std::panic::set_hook(Box::new(|info| log::error!("panic: {info}")));
    let _ = JNI_HANDLES.set((app.vm_as_ptr() as usize, app.activity_as_ptr() as usize));

    let data_dir = app.internal_data_path().unwrap_or_else(|| PathBuf::from("/data/local/tmp/photocraft"));
    log::info!("PhotoCraft {} starting, data dir {}", photocraft_engine::build_info::long_version(), data_dir.display());

    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "PhotoCraft",
        options,
        Box::new(move |cc| {
            // Floating panels would be separate OS windows on the desktop; Android has one window.
            cc.egui_ctx.set_embed_viewports(true);
            PhotocraftApp::install_type_reset_hooks(&cc.egui_ctx);

            let inbox: Inbox = Arc::default();
            let pending: PendingOpen = Arc::default();
            watch_inbox(data_dir.join("inbox"), inbox.clone(), pending.clone(), cc.egui_ctx.clone());

            let mut app = PhotocraftApp::new(Session::new(), services(&data_dir, inbox, pending));
            app.custom_titlebar = false;
            app.integrated_titlebar = false;
            // Long commands and file opens run as background jobs with progress and Cancel.
            app.background_jobs = true;
            if let Some(rs) = cc.wgpu_render_state.clone() {
                if cfg!(feature = "gpu-canvas") {
                    app.set_wgpu(rs);
                    app.start_compositor(&cc.egui_ctx);
                } else {
                    app.watch_window_device(&rs.device);
                }
            }
            Ok(Box::new(app))
        }),
    );
    if let Err(e) = result {
        log::error!("PhotoCraft stopped: {e}");
    }
}
