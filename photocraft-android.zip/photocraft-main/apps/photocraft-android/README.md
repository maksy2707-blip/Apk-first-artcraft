# PhotoCraft for Android

The same editor (`photocraft-ui-egui`) as the desktop and web builds, hosted by eframe's Android
native-activity backend. **Status: first port with touch optimizations.**

## Layout

| Path | What it is |
| --- | --- |
| `src/lib.rs` | `android_main`, the services the app needs (open, save, preferences), the JNI bridge |
| `android/` | Gradle project: manifest, icons, `MainActivity.kt` (file picker, save to Downloads, share intents) |
| `../../.github/workflows/android.yml` | Builds the APK in GitHub Actions |
| `../../crates/ui-egui/src/mobile.rs` | Phone layout, safe-area insets, on-screen hotkey replacements, Full Screen exit |

## Android / touch optimisations (this build)

- **Safe area** — status bar, notch and navigation bar never cover the UI.
- **Back button** → Escape: leaves Full Screen Mode, cancels dialogs, closes menus.
- **Full Screen Mode (“вид на фото”)** — large red **✕ Exit** button at the bottom + X in the top-right corner. One tap always returns to the normal editor. System Back does the same.
- **Quick-action bar** (bottom of the canvas when a document is open):
  - Undo / Redo
  - Show / hide panels (Tab equivalent)
  - Fit on Screen
  - Enter Full Screen
- Touch targets are ≥ 48 pt.
- Compact menu (single button) and collapsible dock on narrow portrait screens.
- UI scale Auto uses 0.8 so controls stay usable on high-density displays.

## Build the APK in the cloud (no Android Studio)

1. Put this repository on GitHub.
2. Actions › **Android APK** › *Run workflow*.
3. When it finishes (about 40–90 minutes the first time), download `photocraft-android-apk` from the run page,
   unzip it and install the `.apk` (allow "install unknown apps" for your browser or file manager).

If the run fails, open the failed step and copy the last ~50 lines of its log.

## Build it yourself

Needs Rust ≥ 1.95 with `rustup target add aarch64-linux-android`, JDK 17, Android SDK
(platform 35, build-tools 35) and NDK 27, and `cargo install cargo-ndk`.

```sh
cargo ndk -t arm64-v8a -o apps/photocraft-android/android/app/src/main/jniLibs build -p photocraft-android --release
gradle -p apps/photocraft-android/android assembleRelease   # Gradle 8.9
# APK: apps/photocraft-android/android/app/build/outputs/apk/release/
```

The release APK is signed with the debug key so it installs directly; use your own signing config for a store build.

## How files work

- **Open** shows the system picker; the chosen files are copied to the app's private `inbox/`
  and opened as new documents (or handed to the File › Open dialog that is waiting).
- **Save / Export** writes to the app's private `exports/` and publishes a copy to
  `Downloads/PhotoCraft/` (Android 10+: no permission needed).
- Images shared to PhotoCraft from other apps open the same way.

## Filters / Blur freezes

Heavy filters (large Gaussian Blur radius, big documents) can still lock the UI or crash on
low-memory phones — previews already run off the main thread, but the final Apply is full-resolution.
Workarounds: lower the radius, work on a smaller document, or enable GPU (`--features gpu-canvas`)
when building. This is a known limit of the first Android port.

## Not done yet

Pen pressure/tilt, clipboard images, printing, update checks, the control server, GPU compositor
by default (`--features gpu-canvas` turns it on). Floating panels are embedded in the window
(`set_embed_viewports`) because Android has one window.
