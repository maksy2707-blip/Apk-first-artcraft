plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.photocraft.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "org.photocraft.android"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.20.1"
        // The Rust library is built for these ABIs by `cargo ndk` (see .github/workflows/android.yml)
        // into src/main/jniLibs/<abi>/libphotocraft_android.so.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Signed with the debug key so the APK installs directly. For a Play Store build,
            // replace this with your own signing config.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { jniLibs { useLegacyPackaging = true } }
}
