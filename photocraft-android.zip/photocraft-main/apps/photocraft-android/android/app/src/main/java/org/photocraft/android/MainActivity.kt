package org.photocraft.android

import android.app.NativeActivity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.view.WindowInsets
import android.webkit.MimeTypeMap
import android.widget.Toast
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/**
 * Hosts the Rust library (libphotocraft_android.so) and does what native code cannot do alone:
 * the system file picker, saving into Downloads, and receiving shared images.
 *
 * Contract with the Rust side (apps/photocraft-android/src/lib.rs):
 *  - files to open are copied into `<filesDir>/inbox/<n>_<name>` (written as `.part`, then renamed);
 *    a cancelled picker leaves an empty marker file named `!cancelled`;
 *  - Rust calls [openDocument] and [saveFile] through JNI.
 */
class MainActivity : NativeActivity() {

    companion object {
        private const val TAG = "PhotoCraft"
        private const val REQ_OPEN = 4101
        private val counter = AtomicLong(System.currentTimeMillis())
    }

    private val inboxDir: File
        get() = File(filesDir, "inbox").also { it.mkdirs() }

    /** System bars + display cutout + keyboard, in physical pixels: left, top, right, bottom. */
    @Volatile
    private var safeInsets = intArrayOf(0, 0, 0, 0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setOnApplyWindowInsetsListener { view, insets ->
            safeInsets = computeInsets(insets)
            view.onApplyWindowInsets(insets)
        }
        window.decorView.requestApplyInsets()
        if (savedInstanceState == null) handleIncoming(intent)
    }

    private fun computeInsets(insets: WindowInsets): IntArray =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val i = insets.getInsets(
                WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime()
            )
            intArrayOf(i.left, i.top, i.right, i.bottom)
        } else {
            @Suppress("DEPRECATION")
            intArrayOf(
                insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                insets.systemWindowInsetRight, insets.systemWindowInsetBottom
            )
        }

    @Volatile
    private var backPressed = false

    /** Back acts as Esc inside the app (leave Full Screen Mode, cancel) and never closes it. */
    @Deprecated("NativeActivity has no OnBackInvokedCallback support")
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        backPressed = true
    }

    /** Called from Rust: whether Back was pressed since the last call. */
    fun consumeBack(): Boolean {
        val pressed = backPressed
        backPressed = false
        return pressed
    }

    /** Called from Rust every frame: the room the system covers, so the UI can stay clear of it. */
    fun getSafeInsets(): IntArray = safeInsets

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    /** Called from Rust: show the system file picker. */
    fun openDocument(multiple: Boolean) {
        runOnUiThread {
            val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
            }
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(picker, REQ_OPEN)
            } catch (e: Exception) {
                Log.e(TAG, "no file picker", e)
                markCancelled()
            }
        }
    }

    @Deprecated("Kept because NativeActivity has no Activity Result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_OPEN) return
        if (resultCode != RESULT_OK || data == null) {
            markCancelled()
            return
        }
        val uris = ArrayList<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) markCancelled() else copyToInbox(uris)
    }

    /** Called from Rust: publish a finished file from the private exports folder to Downloads. */
    fun saveFile(path: String) {
        val src = File(path)
        thread {
            try {
                val name = src.name
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(name))
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PhotoCraft")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IOException("the system refused to create the file")
                    contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                    toast("Saved to Downloads/PhotoCraft/$name")
                } else {
                    val dir = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "PhotoCraft").also { it.mkdirs() }
                    src.copyTo(File(dir, name), overwrite = true)
                    toast("Saved to ${dir.path}/$name")
                }
            } catch (e: Exception) {
                Log.e(TAG, "save failed", e)
                toast("Save failed: ${e.message}")
            }
        }
    }

    // --- incoming files ---------------------------------------------------------------------

    private fun handleIncoming(intent: Intent?) {
        if (intent == null) return
        val uris = ArrayList<Uri>()
        when (intent.action) {
            Intent.ACTION_VIEW -> intent.data?.let { uris.add(it) }
            Intent.ACTION_SEND -> {
                val stream: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
                stream?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) copyToInbox(uris)
    }

    private fun copyToInbox(uris: List<Uri>) {
        thread {
            for (uri in uris) {
                try {
                    val name = (displayName(uri) ?: "image").replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    val stamp = counter.incrementAndGet()
                    val part = File(inboxDir, "${stamp}_$name.part")
                    val input = contentResolver.openInputStream(uri) ?: throw IOException("cannot read $uri")
                    input.use { src -> part.outputStream().use { src.copyTo(it) } }
                    part.renameTo(File(inboxDir, "${stamp}_$name"))
                } catch (e: Exception) {
                    Log.e(TAG, "cannot copy $uri", e)
                    toast("Cannot open the file: ${e.message}")
                    markCancelled()
                }
            }
        }
    }

    private fun markCancelled() {
        try {
            File(inboxDir, "!cancelled").writeText("")
        } catch (e: Exception) {
            Log.e(TAG, "cannot write the cancel marker", e)
        }
    }

    private fun displayName(uri: Uri): String? {
        if (uri.scheme == "content") {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun mimeFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun toast(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    }
}
